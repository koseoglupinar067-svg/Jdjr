# NoxNo Client

A Minecraft Bedrock Edition MITM (Man-in-the-Middle) relay client for Android, built in Kotlin using Compose.

NoxNo works by sitting between your Minecraft app and the server as a local proxy. Your Minecraft client connects to NoxNo on `127.0.0.1:19132`, and NoxNo connects to the real server on your behalf — intercepting, injecting, and modifying packets in real time.

---

## Features

### Combat
| Module | Description |
|--------|-------------|
| KillAura | Auto-attacks nearby players with CPS control, FOV/LOS filter, friend skip |
| AuraV3 | Advanced aura with TPAura movement, crit injection, boost mode |
| Criticals | Packet-level critical hit injection (Fast / UltraFast) |
| CrystalAura | End crystal placement and detonation |
| AnchorAura | Respawn anchor PvP automation |
| BedAura | Bed explosion combat |
| TriggerBot | Attacks when crosshair is on a player |
| AutoTotem | Keeps a totem in offhand at all times |
| AutoArmor | Equips the best armor set automatically |
| AntiCrystal | Offsets your Y position to avoid crystal damage |
| AntiBed | Blocks incoming bed interaction packets |
| AutoCrystalAura | Auto Crystal Aura combined module |
| CTrap | Crystal trap placement |
| AutoTrap | Obsidian trap automation |
| SelfTrap | Self-trap for defensive play |
| SRCFight | Strafe + reach + crit combined fighter |
| ObsidianMiner | Mines obsidian blocks automatically |
| HotbarSwitch | Cycles hotbar slots on a timer |
| Hitbox | Expands entity hitboxes client-side |

### Movement
| Module | Description |
|--------|-------------|
| AirJump | Multi-jump in mid-air |
| BypassFly | Environmental-aware fly with Auto mode |
| MotionFly | Motion packet injection fly |
| ElytraFly | Elytra flight assist |
| Jetpack | Jetpack-style upward motion |
| Speed | Movement speed boost |
| Timer | PC-style Timer (position delta scaling) with PvP rubber-band protection |
| AntiKnockback | Reduces or nullifies knockback |
| NoFallDamage | Cancels fall damage packets |
| NoClip | Fly through blocks |
| TPAura | Teleport around a target during combat |

### Visual
| Module | Description |
|--------|-------------|
| TargetESP | Highlights the current attack target |
| FullBright | Forces maximum brightness |
| FOVChanger | Adjusts field of view |
| NoHurtCam | Disables the screen shake on damage |
| ArrayList | Displays active modules on screen |
| Performance | Limits overlay FPS to reduce battery usage |

### Player
| Module | Description |
|--------|-------------|
| AutoDisconnect | Disconnects automatically when health is low |
| AntiLag | Suppresses lag-inducing packets |

### Misc
| Module | Description |
|--------|-------------|
| ChatSpammer | Announces kills and logouts in chat |
| Advertiser | Sends a configurable ad message on interval |
| PopCounter | Counts totem pops in chat |
| ComboShortcut | Bind multiple modules to one toggle |
| CommandHelper | Sends server commands on module toggle |

---

## Chat Suffix

Every message you type in chat is automatically formatted as:

```
>(your message) | XXXXXX | NoxNo
```

where `XXXXXX` is a random 6-character alphanumeric string. This applies to manually typed messages only — internal module messages are exempt.

---

## Supported Versions

| Protocol | Minecraft Version |
|----------|------------------|
| 649 | 1.20.60 |
| 662 | 1.20.70 |
| 671 | 1.20.80 |
| 685 | 1.21.0 |
| 686 | 1.21.2 |
| 712 | 1.21.20 |
| 729 | 1.21.30 |
| 748 | 1.21.40 |
| 766 | 1.21.50 |
| 776 | 1.21.60 |
| 786 | 1.21.70 |
| 800 | 1.21.80 |
| 818 | 1.21.90–1.21.92 |
| 819 | 1.21.93–1.21.94 |
| 827 | 1.21.100–1.21.101 |
| 844 | 1.21.111–1.21.114 |
| 859 | 1.21.120–1.21.123 |
| 860 | 1.21.124 |
| 897 | 1.21.130–1.21.132 |
| 924 | 1.26.0–1.26.3 |
| 944 | 1.26.10–1.26.13 |
| 975 | 1.26.20–1.26.23 |
| 1001 | 1.26.30–1.26.33 |
| 2168 | 1.26.40 |

---

## Building

**Requirements**
- Android Studio Hedgehog or newer
- JDK 17
- Android SDK 34

```bash
git clone https://github.com/youruser/NoxNoClient.git
cd NoxNoClient
./gradlew assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`

**Release builds** require a signing keystore. Set the following environment variables or add them to `local.properties`:

```
KEYSTORE_FILE=path/to/keystore.jks
KEYSTORE_PASSWORD=...
KEY_ALIAS=...
KEY_PASSWORD=...
```

---

## Project Structure

```
app/src/main/kotlin/com/noxnoclient/
├── auth/           Microsoft account authentication
├── config/         Persistent module config (JSON)
├── core/
│   ├── proxy/      EntityTracker, WorldBlockTracker, ChunkParser
│   └── relay/      NoxNoRelay, NoxNoRelaySession, packet listeners, codec registry
├── events/         PacketEvent, PacketEventBus
├── module/
│   ├── combat/     Combat modules
│   ├── movement/   Movement modules
│   ├── visual/     Visual modules
│   ├── player/     Player utility modules
│   └── misc/       Miscellaneous modules
├── session/        SessionManager
├── ui/             Overlay service, dashboard, HUD
└── utils/          MathUtil, RotationUtil, PacketUtil, PlacementUtil, TimerPvP, CritLock…

relay/
├── Protocol/       CloudburstMC bedrock-codec (vendored, multi-version)
└── NBT/            CloudburstMC NBT library (vendored)
```

---

## How It Works

1. NoxNo starts a local Bedrock server on `127.0.0.1:19132`.
2. You connect Minecraft to `127.0.0.1` (LAN or manual server).
3. NoxNo forwards your connection to the real server using your Microsoft account credentials.
4. All packets in both directions pass through NoxNo's `PacketEventBus`, where modules can read, modify, cancel, or inject new packets.

---

## License

MIT — see [LICENSE](LICENSE).

---

## Disclaimer

This software is intended for educational and research purposes. Use on servers where client modifications are prohibited may result in a ban. The authors take no responsibility for how this software is used.
