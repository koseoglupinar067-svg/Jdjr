// NoxNo Client — main.cpp
// Garantili görünür ImGui menüsü (eglSwapBuffers hook)

#include <jni.h>
#include <string>
#include <pthread.h>
#include <unistd.h>
#include <android/log.h>
#include <EGL/egl.h>
#include <GLES3/gl3.h>

#include "ImGui/imgui.h"
#include "ImGui/imgui_internal.h"
#include "ImGui/backends/imgui_impl_android.h"
#include "ImGui/backends/imgui_impl_opengl3.h"

#include "Includes/Dobby/dobby.h"

#define LOG_TAG "NoxNo"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

// ─── Globals ────────────────────────────────────────────────────────────────

static bool  g_initialized  = false;
static bool  g_showMenu      = true;   // başlangıçta açık
static float g_menuX         = 60.f;
static float g_menuY         = 60.f;
static int   g_screenW       = 0;
static int   g_screenH       = 0;
static ImVec4 g_accentColor  = ImVec4(0.16f, 0.55f, 1.0f, 1.f);  // #2A8CFF

// ─── Modül toggle'ları ───────────────────────────────────────────────────────

static bool g_killAura   = false;
static bool g_esp        = false;
static bool g_speed      = false;
static bool g_fly        = false;
static bool g_noFall     = false;
static bool g_antiKB     = false;
static bool g_reach      = false;
static bool g_criticals  = false;

static float g_speedValue = 2.0f;
static float g_flySpeed   = 1.5f;
static float g_reachDist  = 4.5f;
static float g_cps        = 12.0f;

// ─── EGL hook ───────────────────────────────────────────────────────────────

typedef EGLBoolean (*eglSwapBuffers_t)(EGLDisplay, EGLSurface);
static eglSwapBuffers_t orig_eglSwapBuffers = nullptr;

static void noxno_imgui_init(EGLDisplay dpy, EGLSurface surf) {
    // Ekran boyutunu EGL'den al
    eglQuerySurface(dpy, surf, EGL_WIDTH,  &g_screenW);
    eglQuerySurface(dpy, surf, EGL_HEIGHT, &g_screenH);
    LOGI("Surface: %d x %d", g_screenW, g_screenH);

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();

    ImGuiIO& io = ImGui::GetIO();
    io.DisplaySize = ImVec2((float)g_screenW, (float)g_screenH);
    io.IniFilename = nullptr;
    io.LogFilename = nullptr;

    // Font — varsayılan, boyut ekrana göre
    float fontSize = (g_screenW > 1200) ? 28.f : 22.f;
    io.Fonts->AddFontDefault();

    // Tema
    ImGui::StyleColorsDark();
    ImGuiStyle& s = ImGui::GetStyle();
    s.WindowRounding    = 8.f;
    s.FrameRounding     = 6.f;
    s.GrabRounding      = 6.f;
    s.ScrollbarRounding = 8.f;
    s.WindowPadding     = ImVec2(12, 12);
    s.ItemSpacing       = ImVec2(8, 6);
    s.FramePadding      = ImVec2(8, 5);

    ImVec4* c = s.Colors;
    c[ImGuiCol_WindowBg]         = ImVec4(0.07f, 0.07f, 0.09f, 0.95f);
    c[ImGuiCol_TitleBg]          = ImVec4(0.10f, 0.36f, 0.65f, 1.f);
    c[ImGuiCol_TitleBgActive]    = ImVec4(0.16f, 0.55f, 1.0f, 1.f);
    c[ImGuiCol_Header]           = ImVec4(0.16f, 0.55f, 1.0f, 0.35f);
    c[ImGuiCol_HeaderHovered]    = ImVec4(0.16f, 0.55f, 1.0f, 0.55f);
    c[ImGuiCol_HeaderActive]     = ImVec4(0.16f, 0.55f, 1.0f, 0.80f);
    c[ImGuiCol_Button]           = ImVec4(0.16f, 0.55f, 1.0f, 0.40f);
    c[ImGuiCol_ButtonHovered]    = ImVec4(0.16f, 0.55f, 1.0f, 0.70f);
    c[ImGuiCol_ButtonActive]     = ImVec4(0.16f, 0.55f, 1.0f, 1.00f);
    c[ImGuiCol_FrameBg]          = ImVec4(0.14f, 0.14f, 0.18f, 1.f);
    c[ImGuiCol_FrameBgHovered]   = ImVec4(0.20f, 0.20f, 0.26f, 1.f);
    c[ImGuiCol_SliderGrab]       = ImVec4(0.16f, 0.55f, 1.0f, 0.80f);
    c[ImGuiCol_SliderGrabActive] = ImVec4(0.16f, 0.55f, 1.0f, 1.00f);
    c[ImGuiCol_CheckMark]        = ImVec4(0.16f, 0.55f, 1.0f, 1.00f);
    c[ImGuiCol_Separator]        = ImVec4(0.16f, 0.55f, 1.0f, 0.30f);
    c[ImGuiCol_ScrollbarBg]      = ImVec4(0.05f, 0.05f, 0.07f, 1.f);
    c[ImGuiCol_ScrollbarGrab]    = ImVec4(0.16f, 0.55f, 1.0f, 0.50f);

    ImGui_ImplAndroid_Init(nullptr);
    ImGui_ImplOpenGL3_Init("#version 300 es");

    g_initialized = true;
    LOGI("ImGui initialized OK");
}

static void noxno_draw_menu() {
    if (!g_showMenu) return;

    ImGuiIO& io = ImGui::GetIO();

    // Menüyü ilk açılışta ortaya yerleştir
    static bool firstTime = true;
    if (firstTime) {
        g_menuX = io.DisplaySize.x * 0.05f;
        g_menuY = io.DisplaySize.y * 0.10f;
        firstTime = false;
    }

    ImGui::SetNextWindowPos(ImVec2(g_menuX, g_menuY), ImGuiCond_Always);
    ImGui::SetNextWindowSize(ImVec2(320, 0), ImGuiCond_Always);
    ImGui::SetNextWindowSizeConstraints(ImVec2(280, 200), ImVec2(500, 700));

    ImGuiWindowFlags flags = ImGuiWindowFlags_NoScrollbar;

    if (ImGui::Begin("NoxNo Client", &g_showMenu, flags)) {
        // Sürüklenebilirlik — title bar'a dokunarak taşı
        if (ImGui::IsWindowHovered() && ImGui::IsMouseDragging(0)) {
            ImVec2 delta = ImGui::GetMouseDragDelta(0);
            g_menuX += delta.x;
            g_menuY += delta.y;
            ImGui::ResetMouseDragDelta(0);
            // Ekran sınırları
            g_menuX = std::max(0.f, std::min(g_menuX, io.DisplaySize.x - 300.f));
            g_menuY = std::max(0.f, std::min(g_menuY, io.DisplaySize.y - 100.f));
        }

        // Header
        ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.16f, 0.55f, 1.0f, 1.f));
        ImGui::Text("NoxNo"); ImGui::SameLine();
        ImGui::PopStyleColor();
        ImGui::TextDisabled("v1.0  |  26.44");
        ImGui::Separator();

        // Sekmeler
        if (ImGui::BeginTabBar("tabs")) {

            // ─── COMBAT ────────────────────────────────────────────
            if (ImGui::BeginTabItem("Combat")) {

                ImGui::Checkbox("KillAura", &g_killAura);
                if (g_killAura) {
                    ImGui::SameLine();
                    ImGui::TextDisabled("(active)");
                    ImGui::SliderFloat("CPS##ka", &g_cps, 4.f, 20.f, "%.0f");
                }

                ImGui::Spacing();
                ImGui::Checkbox("Reach", &g_reach);
                if (g_reach) {
                    ImGui::SliderFloat("Distance##r", &g_reachDist, 3.f, 8.f, "%.1f");
                }

                ImGui::Spacing();
                ImGui::Checkbox("Criticals", &g_criticals);
                if (g_criticals) {
                    ImGui::SameLine();
                    ImGui::TextDisabled("(packet)");
                }

                ImGui::EndTabItem();
            }

            // ─── MOVEMENT ──────────────────────────────────────────
            if (ImGui::BeginTabItem("Movement")) {

                ImGui::Checkbox("Speed", &g_speed);
                if (g_speed) {
                    ImGui::SliderFloat("Multiplier##s", &g_speedValue, 1.5f, 6.f, "%.1fx");
                }

                ImGui::Spacing();
                ImGui::Checkbox("Fly", &g_fly);
                if (g_fly) {
                    ImGui::SliderFloat("Speed##f", &g_flySpeed, 0.5f, 4.f, "%.1f");
                }

                ImGui::Spacing();
                ImGui::Checkbox("No Fall", &g_noFall);
                ImGui::Checkbox("Anti-KB", &g_antiKB);

                ImGui::EndTabItem();
            }

            // ─── VISUAL ────────────────────────────────────────────
            if (ImGui::BeginTabItem("Visual")) {

                ImGui::Checkbox("ESP", &g_esp);
                if (g_esp) {
                    ImGui::SameLine();
                    ImGui::TextDisabled("(players)");
                }

                ImGui::Spacing();
                ImGui::Text("Accent Color");
                ImGui::ColorEdit3("##accent", (float*)&g_accentColor,
                                  ImGuiColorEditFlags_NoInputs |
                                  ImGuiColorEditFlags_NoLabel);

                ImGui::EndTabItem();
            }

            // ─── INFO ──────────────────────────────────────────────
            if (ImGui::BeginTabItem("Info")) {
                ImGui::TextWrapped("NoxNo Client v1.0");
                ImGui::Spacing();
                ImGui::TextDisabled("MC: 26.44");
                ImGui::TextDisabled("Arch: arm64");
                ImGui::Spacing();
                ImGui::Separator();
                ImGui::TextDisabled("Aktif modüller:");
                if (g_killAura) ImGui::BulletText("KillAura");
                if (g_esp)      ImGui::BulletText("ESP");
                if (g_speed)    ImGui::BulletText("Speed");
                if (g_fly)      ImGui::BulletText("Fly");
                if (g_noFall)   ImGui::BulletText("NoFall");
                if (g_antiKB)   ImGui::BulletText("AntiKB");
                if (g_reach)    ImGui::BulletText("Reach");
                if (g_criticals)ImGui::BulletText("Criticals");
                if (!g_killAura && !g_esp && !g_speed && !g_fly &&
                    !g_noFall   && !g_antiKB && !g_reach && !g_criticals)
                    ImGui::TextDisabled("(hiçbiri)");
                ImGui::EndTabItem();
            }

            ImGui::EndTabBar();
        }
    }
    ImGui::End();
}

EGLBoolean hook_eglSwapBuffers(EGLDisplay dpy, EGLSurface surf) {
    if (!g_initialized) {
        noxno_imgui_init(dpy, surf);
    }

    // Çerçeve başlat
    ImGui_ImplOpenGL3_NewFrame();
    ImGui_ImplAndroid_NewFrame();
    ImGui::NewFrame();

    noxno_draw_menu();

    // Render
    ImGui::Render();
    ImGuiIO& io = ImGui::GetIO();
    glViewport(0, 0, (GLsizei)io.DisplaySize.x, (GLsizei)io.DisplaySize.y);
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

    return orig_eglSwapBuffers(dpy, surf);
}

// ─── Touch input hook ───────────────────────────────────────────────────────
// MC'nin kendi EGL input'u yerine doğrudan JNI'dan event inject et

extern "C"
JNIEXPORT void JNICALL
Java_com_mojang_minecraftpe_MainActivity_nativeOnTouch(
        JNIEnv*, jobject,
        jint action, jfloat x, jfloat y) {

    if (!g_initialized) return;

    ImGuiIO& io = ImGui::GetIO();
    int a = action & 0xFF;
    switch (a) {
        case 0: // DOWN
            io.AddMousePosEvent(x, y);
            io.AddMouseButtonEvent(0, true);
            break;
        case 1: // UP
            io.AddMousePosEvent(x, y);
            io.AddMouseButtonEvent(0, false);
            break;
        case 2: // MOVE
            io.AddMousePosEvent(x, y);
            break;
    }
}

// ─── Constructor — hook'ları kur ─────────────────────────────────────────────

__attribute__((constructor))
static void noxno_init() {
    LOGI("NoxNo loading...");

    // eglSwapBuffers hook
    void* sym = DobbySymbolResolver("libEGL.so", "eglSwapBuffers");
    if (!sym) {
        // fallback: dlopen + dlsym
        void* egl = dlopen("libEGL.so", RTLD_NOW | RTLD_GLOBAL);
        if (egl) sym = dlsym(egl, "eglSwapBuffers");
    }

    if (sym) {
        DobbyHook(sym, (void*)hook_eglSwapBuffers, (void**)&orig_eglSwapBuffers);
        LOGI("eglSwapBuffers hooked @ %p", sym);
    } else {
        LOGE("eglSwapBuffers bulunamadi!");
    }

    LOGI("NoxNo loaded. Menu: %s", g_showMenu ? "ON" : "OFF");
}
