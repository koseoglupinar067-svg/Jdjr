package com.noxnoclient.module.visual

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.events.PacketEvent
import com.noxnoclient.module.BaseModule
import com.noxnoclient.module.ModuleCategory
import com.noxnoclient.utils.InventoryUtil
import com.noxnoclient.utils.MathUtil
import com.noxnoclient.utils.UiUtil
import org.cloudburstmc.protocol.bedrock.data.inventory.ItemData
import org.cloudburstmc.protocol.bedrock.packet.AddItemEntityPacket
import java.util.concurrent.ConcurrentHashMap

/**
 * ESP for dropped items on the ground. EntityTracker only ever tags ground-item entities
 * with a generic "minecraft:item" identifier (the real item type/count lives in a
 * different field of AddItemEntityPacket than what EntityTracker stores), so this module
 * keeps its own small identity map populated straight from that packet.
 */
class ItemESP : BaseModule(
    name        = "ItemESP",
    category    = ModuleCategory.VISUAL,
    description = "Yerdeki eşyalar için ikon, isim, adet ve mesafe gösterir"
) {
    private val range         = float("Range",         48f, 8f, 128f)
    private val showIcon      = bool ("Icon",           true)
    private val showName      = bool ("Name",           true)
    private val showCount     = bool ("Count",          true)
    private val showDistance  = bool ("Distance",       true)
    private val highlightRare = bool ("Highlight Rare", true)
    private val maxRendered   = int  ("Max Rendered",   40, 5, 100)

    companion object {
        private val VALUABLE = setOf(
            "minecraft:diamond", "minecraft:netherite_ingot", "minecraft:netherite_scrap",
            "minecraft:emerald", "minecraft:totem_of_undying", "minecraft:ancient_debris",
            "minecraft:enchanted_golden_apple", "minecraft:golden_apple",
            "minecraft:elytra", "minecraft:trident", "minecraft:nether_star",
            "minecraft:netherite_sword", "minecraft:netherite_axe", "minecraft:netherite_pickaxe",
            "minecraft:netherite_chestplate", "minecraft:netherite_helmet",
            "minecraft:netherite_leggings", "minecraft:netherite_boots",
            "minecraft:shulker_box", "minecraft:beacon"
        )
        private val NORMAL_COLOR = Color.rgb(120, 200, 255)
        private val RARE_COLOR   = Color.rgb(255, 200, 60)
    }

    private val itemById = ConcurrentHashMap<Long, ItemData>()

    private val iconRect = Rect()
    private val boxPaint = Paint().apply { style = Paint.Style.STROKE; strokeWidth = 2.5f; isAntiAlias = true }
    private val textPaint = Paint().apply {
        isAntiAlias = true; textSize = 24f; textAlign = Paint.Align.CENTER
        setShadowLayer(3f, 0f, 0f, Color.BLACK)
    }

    override fun onPacket(event: PacketEvent) {
        if (!isEnabled) return
        val p = event.packet
        if (p is AddItemEntityPacket) {
            itemById[p.runtimeEntityId] = p.itemInHand
        }
    }

    fun render(canvas: Canvas, screenW: Int, screenH: Int) {
        val selfX = EntityTracker.selfX; val selfY = EntityTracker.selfY; val selfZ = EntityTracker.selfZ
        val yaw = EntityTracker.selfYaw; val pitch = EntityTracker.selfPitch
        val fov = UiUtil.currentFov

        val targets = EntityTracker.getEntitiesInRange(range.value) { it.type == EntityTracker.EntityType.ITEM }
        if (targets.isEmpty()) {
            itemById.clear()
            return
        }

        // Artık takip edilmeyen (toplanmış/despawn olmuş) item'ları haritadan temizle -
        // aksi halde bu harita sonsuza kadar büyür.
        val activeIds = targets.mapTo(HashSet()) { it.runtimeId }
        itemById.keys.retainAll(activeIds)

        val sorted = targets.sortedBy { MathUtil.dist3(it.x, it.y, it.z, selfX, selfY, selfZ) }
        var rendered = 0

        for (t in sorted) {
            if (rendered >= maxRendered.value) break
            val screen = MathUtil.worldToScreen(t.x, t.y + 0.15f, t.z, selfX, selfY, selfZ, yaw, pitch, screenW, screenH, fov)
                ?: continue
            if (screen.first < -40 || screen.first > screenW + 40 || screen.second < -40 || screen.second > screenH + 40) continue

            val item = itemById[t.runtimeId]
            val identifier = item?.let { InventoryUtil.resolveIdentifier(it) } ?: "minecraft:item"
            val isRare = highlightRare.value && identifier in VALUABLE
            val color = if (isRare) RARE_COLOR else NORMAL_COLOR
            val dist = MathUtil.dist3(t.x, t.y, t.z, selfX, selfY, selfZ)

            val (sx, sy) = screen
            var cursorY = sy

            if (showIcon.value) {
                val icon = UiUtil.getIcon(identifier)
                val size = if (isRare) 34 else 26
                if (icon != null) {
                    iconRect.set((sx - size / 2).toInt(), (sy - size).toInt(), (sx + size / 2).toInt(), sy.toInt())
                    canvas.drawBitmap(icon, null, iconRect, null)
                } else {
                    boxPaint.color = color
                    canvas.drawRect(sx - size / 2f, sy - size, sx + size / 2f, sy, boxPaint)
                }
                cursorY = sy + 20f
            } else {
                boxPaint.color = color
                canvas.drawCircle(sx, sy, 5f, boxPaint)
                cursorY = sy + 24f
            }

            if (showName.value || showCount.value || showDistance.value) {
                val name = identifier.removePrefix("minecraft:").replace('_', ' ')
                    .replaceFirstChar { it.uppercase() }
                val count = item?.count?.takeIf { it > 1 && showCount.value }
                val parts = buildList {
                    if (showName.value) add(if (count != null) "${count}x $name" else name)
                    if (showDistance.value) add("${dist.toInt()}m")
                }
                if (parts.isNotEmpty()) {
                    textPaint.color = if (isRare) RARE_COLOR else Color.WHITE
                    canvas.drawText(parts.joinToString("  "), sx, cursorY, textPaint)
                }
            }

            rendered++
        }
    }
}
