package com.noxnoclient.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// ---- Deep navy / black base ----
val NoxNoBackground     = Color(0xFF05070D)
val NoxNoSurface        = Color(0xFF0D1420)
val NoxNoSurfaceVar     = Color(0xFF131C2E)
val NoxNoSurfaceRaised  = Color(0xFF1A263C)

// ---- Electric blue accent ----
val NoxNoAccent         = Color(0xFF3B7CFF)
val NoxNoAccentLight    = Color(0xFF8FB8FF)
val NoxNoAccentDark     = Color(0xFF15306B)

val NoxNoOnBackground   = Color(0xFFEAF1FF)
val NoxNoOnSurface      = Color(0xFFD3DEF2)
val NoxNoOnSurfaceDim   = Color(0xFF7688AA)

val NoxNoOutline        = Color(0xFF1B2740)
val NoxNoOutlineStrong  = Color(0xFF2C3C5C)

val NoxNoError          = Color(0xFFFF5470)
val NoxNoSuccess        = Color(0xFF34D399)
val NoxNoWarning        = Color(0xFFFFB020)

val NoxNoConnectIdle    = Color(0xFF18223A)

val NoxNoSkinTone       = Color(0xFFF1D7B8)

val NoxNoModuleActive       = Color(0xFF122759)
val NoxNoModuleActiveBorder = Color(0xFF3B7CFF)
val NoxNoModuleExpanded     = Color(0xFF17398C)
val NoxNoModuleActiveText   = Color(0xFFEAF1FF)

// Kept as aliases so anything still referencing the old "purple" names keeps
// compiling - they now point at the blue accent instead of purple.
val NoxNoPurple      = NoxNoAccent
val NoxNoPurpleLight = NoxNoAccentLight
val NoxNoPurpleDark  = NoxNoAccentDark

private val Scheme = darkColorScheme(
    primary          = NoxNoAccent,
    onPrimary        = Color.White,
    primaryContainer = NoxNoAccentDark,
    secondary        = NoxNoAccentLight,
    background       = NoxNoBackground,
    surface          = NoxNoSurface,
    surfaceVariant   = NoxNoSurfaceVar,
    onBackground     = NoxNoOnBackground,
    onSurface        = NoxNoOnSurface,
    outline          = NoxNoOutline,
    error            = NoxNoError
)

@Composable
fun NoxNoClientTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}
