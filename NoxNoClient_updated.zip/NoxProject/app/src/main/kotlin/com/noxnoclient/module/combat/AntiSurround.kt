package com.noxnoclient.module.combat

import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.events.PacketEvent
import com.noxnoclient.events.PacketEventBus
import com.noxnoclient.module.BaseModule
import com.noxnoclient.module.ModuleCategory
import com.noxnoclient.utils.CombatUtil
import com.noxnoclient.utils.InventoryUtil
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.cloudburstmc.math.vector.Vector3i
import org.cloudburstmc.protocol.bedrock.data.inventory.transaction.InventoryTransactionType
import org.cloudburstmc.protocol.bedrock.data.inventory.transaction.ItemUseTransaction
import org.cloudburstmc.protocol.bedrock.packet.InventoryTransactionPacket
import org.cloudburstmc.math.vector.Vector3f

/**
 * AntiSurround — Picks up the pickaxe from hotbar and breaks the 4 optimal
 * surrounding blocks around the nearest enemy (cPvP anti-surround style).
 */
class AntiSurround : BaseModule(
    name        = "AntiSurround",
    category    = ModuleCategory.COMBAT,
    description = "Equips pickaxe and breaks enemy's surrounding blocks (cPvP)"
) {
    private val range      = float("Range", 5f, 2f, 8f)
    private val breakDelay = int  ("Break Delay (ms)", 50, 0, 300)
    private val shortcut   = bool ("Shortcut", false)

    private val PICK_IDS = setOf(
        "minecraft:netherite_pickaxe", "minecraft:diamond_pickaxe",
        "minecraft:iron_pickaxe", "minecraft:stone_pickaxe", "minecraft:wooden_pickaxe",
        "minecraft:golden_pickaxe"
    )

    // Break the 4 horizontal positions around the enemy
    private val BREAK_OFFSETS = listOf(
        Triple( 0, 0, -1), Triple( 0, 0,  1),
        Triple( 1, 0,  0), Triple(-1, 0,  0)
    )

    private var breakJob: Job? = null

    override fun onEnable() {
        super.onEnable()
        breakJob = scope.launch { runAntiSurround() }
    }

    override fun onDisable() {
        breakJob?.cancel(); breakJob = null
        super.onDisable()
    }

    override fun onPacket(event: PacketEvent) {}

    private suspend fun runAntiSurround() {
        val session = PacketEventBus.currentSession ?: return
        val target = EntityTracker.getNearestPlayer(range.value) ?: run { setEnabled(false); return }

        val pickSlot = findPickaxeInHotbar() ?: run { setEnabled(false); return }
        val originalSlot = EntityTracker.selfHotbarSlot

        InventoryUtil.sendHotbarSelect(session, pickSlot)
        EntityTracker.selfHotbarSlot = pickSlot

        val tx = target.x.toInt(); val ty = target.y.toInt(); val tz = target.z.toInt()

        for ((dx, dy, dz) in BREAK_OFFSETS) {
            val bx = tx + dx; val by = ty + dy; val bz = tz + dz

            // Send block break (destroy) packet
            val heldItem = EntityTracker.getInventoryItem(pickSlot) ?: break
            val blockDef = InventoryUtil.getBlockDefinition(session, "minecraft:obsidian") ?: continue

            val playerPos = Vector3f.from(EntityTracker.selfX, EntityTracker.selfY, EntityTracker.selfZ)

            session.serverBound(InventoryTransactionPacket().apply {
                transactionType = InventoryTransactionType.ITEM_USE
                actionType = 2 // Destroy
                blockPosition = Vector3i.from(bx, by, bz)
                blockFace = 1
                hotbarSlot = pickSlot
                itemInHand = heldItem
                playerPosition = playerPos
                clickPosition = Vector3f.from(0.5f, 0.5f, 0.5f)
                blockDefinition = blockDef
                triggerType = ItemUseTransaction.TriggerType.PLAYER_INPUT
                clientInteractPrediction = ItemUseTransaction.PredictedResult.SUCCESS
            })
            delay(breakDelay.value.toLong())
        }

        InventoryUtil.sendHotbarSelect(session, originalSlot)
        EntityTracker.selfHotbarSlot = originalSlot
        setEnabled(false)
    }

    private fun findPickaxeInHotbar(): Int? {
        for (slot in 0..8) {
            val item = EntityTracker.getInventoryItem(slot) ?: continue
            if (item.count <= 0) continue
            val id = InventoryUtil.resolveIdentifier(item) ?: continue
            if (id in PICK_IDS) return slot
        }
        return null
    }
}
