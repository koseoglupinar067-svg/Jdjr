package com.noxnoclient.module.movement

import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.events.PacketEvent
import com.noxnoclient.module.*
import org.cloudburstmc.protocol.bedrock.packet.SetEntityMotionPacket

class AntiKnockback : BaseModule(
    name        = "Velocity",
    category    = ModuleCategory.MOVEMENT,
    description = "Completely blocks incoming knockback"
) {
    private val shortcut = bool("Shortcut", false)

    override fun onPacket(event: PacketEvent) {
        if (!isEnabled) return
        if (event.direction != PacketEvent.Direction.SERVER_TO_CLIENT) return

        val pkt = event.packet
        if (pkt !is SetEntityMotionPacket) return
        if (pkt.runtimeEntityId != EntityTracker.selfRuntimeId) return

        event.cancel()
    }
}
