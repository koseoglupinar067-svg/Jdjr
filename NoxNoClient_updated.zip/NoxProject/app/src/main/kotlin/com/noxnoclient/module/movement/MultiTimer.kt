package com.noxnoclient.module.movement

import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.core.relay.NoxNoRelaySession
import com.noxnoclient.events.PacketEvent
import com.noxnoclient.events.PacketEventBus
import com.noxnoclient.module.*
import com.noxnoclient.utils.CombatUtil
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.cloudburstmc.protocol.bedrock.data.PlayerActionType
import org.cloudburstmc.protocol.bedrock.data.inventory.transaction.InventoryTransactionType
import org.cloudburstmc.protocol.bedrock.packet.InventoryTransactionPacket
import org.cloudburstmc.protocol.bedrock.packet.PlayerActionPacket
import org.cloudburstmc.protocol.bedrock.packet.PlayerAuthInputPacket

/**
 * MultiTimer - a TPS-based timer, not a raw speed multiplier.
 *
 * Instead of "send movement N times faster" (see the older Timer.kt, which
 * works off a plain multiplier), every knob here is a target ticks-per-second
 * value. Vanilla Bedrock ticks at 20 TPS; setting a profile to e.g. 26 TPS
 * means "make the server perceive 26 ticks of you happening per real
 * second" - which is the actual mechanism real Timer cheats use, and it
 * naturally covers slowing down too (anything under 20 TPS), which a plain
 * ">= 1.0x" multiplier can't express.
 *
 * Engine: each real incoming tick (PlayerAuthInputPacket) advances a
 * real-time accumulator. We convert the *current effective TPS* into a
 * virtual-tick interval (1000ms / TPS) and compare against real elapsed
 * time:
 *  - TPS > 20 (speed up): once enough real time has accumulated for more
 *    than one virtual tick, the extra ticks are injected as interpolated
 *    MovePlayerPacket steps after the real one (same duplication technique
 *    Timer.kt already uses, just driven by a TPS target instead of a
 *    multiplier).
 *  - TPS <= 20 (slow down / vanilla): the real tick is withheld
 *    (event.cancel()) until enough virtual-tick time has actually elapsed,
 *    so the server perceives fewer ticks per second than the real client is
 *    sending - the real screen is unaffected since it already rendered the
 *    tick locally before the relay ever saw it.
 *
 * On top of the always-on "Base TPS", three stackable context profiles
 * (Combat / Mining / Placing) each contribute their own TPS delta on top of
 * the base while active - AUTO mode detects the context from the last
 * matching real packet within "Context Hold", ALWAYS forces it on
 * regardless of context, OFF disables it. Multiple active profiles add
 * together rather than one overriding another.
 */
class MultiTimer : BaseModule(
    name        = "MultiTimer",
    category    = ModuleCategory.MOVEMENT,
    description = "TPS-based timer (target ticks-per-second, not a multiplier) with stackable combat/mining/placing profiles"
), PacketEventBus.PacketListener {

    enum class ProfileMode { OFF, AUTO, ALWAYS }

    private companion object {
        const val VANILLA_TPS         = 20f
        const val MIN_EFFECTIVE_TPS   = 2f
        const val MAX_EFFECTIVE_TPS   = 200f
        const val TPS_EPSILON         = 0.05f
    }

    // ---- Base ----
    private val baseTps          = float("Base TPS", 20f, 5f, 60f)
    private val stepDelayMs      = int  ("Step Delay (ms)", 12, 2, 50)
    private val minMoveThreshold = float("Min Move Threshold", 0.02f, 0f, 0.5f)
    private val maxInjectedTicks = int  ("Max Injected Ticks", 4, 1, 10)
    private val contextHoldMs    = int  ("Context Hold (ms)", 250, 50, 2000)
    private val shortcut         = bool ("Shortcut", false)

    // ---- Combat profile ----
    private val combatMode       = enum ("Combat Mode", ProfileMode.AUTO)
    private val combatTps        = float("Combat TPS", 26f, 5f, 60f)
    private val duplicateAttacks = bool ("Duplicate Attacks", true)

    // ---- Mining profile ----
    private val miningMode = enum ("Mining Mode", ProfileMode.AUTO)
    private val miningTps  = float("Mining TPS", 24f, 5f, 60f)

    // ---- Placing profile ----
    private val placingMode = enum ("Placing Mode", ProfileMode.AUTO)
    private val placingTps  = float("Placing TPS", 22f, 5f, 60f)

    @Volatile private var lastAttackPacketMs  = 0L
    @Volatile private var lastMiningPacketMs  = 0L
    @Volatile private var lastPlacingPacketMs = 0L

    @Volatile private var lastRealTickNs = 0L
    @Volatile private var hasLastReal    = false
    @Volatile private var accumulatorMs  = 0.0
    @Volatile private var deficitMs      = 0.0

    @Volatile private var lastRealX = 0f
    @Volatile private var lastRealY = 0f
    @Volatile private var lastRealZ = 0f

    override fun onEnable() {
        super.onEnable()
        lastRealTickNs = 0L
        hasLastReal    = false
        accumulatorMs  = 0.0
        deficitMs      = 0.0
        lastAttackPacketMs  = 0L
        lastMiningPacketMs  = 0L
        lastPlacingPacketMs = 0L
        PacketEventBus.register(this)
    }

    override fun onDisable() {
        PacketEventBus.unregister(this)
        hasLastReal = false
        super.onDisable()
    }

    override fun onPacket(event: PacketEvent) {
        if (!isEnabled) return
        if (event.direction != PacketEvent.Direction.CLIENT_TO_SERVER) return
        val session = event.session
        val now = System.currentTimeMillis()

        when (val pkt = event.packet) {
            is InventoryTransactionPacket -> {
                when (pkt.transactionType) {
                    InventoryTransactionType.ITEM_USE_ON_ENTITY -> {
                        lastAttackPacketMs = now
                        if (duplicateAttacks.value) handleAttackDuplication(session, pkt.runtimeEntityId, now)
                    }
                    InventoryTransactionType.ITEM_USE -> lastPlacingPacketMs = now
                    else -> {}
                }
            }
            is PlayerActionPacket -> {
                if (pkt.action == PlayerActionType.START_BREAK ||
                    pkt.action == PlayerActionType.CONTINUE_BREAK ||
                    pkt.action == PlayerActionType.BLOCK_CONTINUE_DESTROY ||
                    pkt.action == PlayerActionType.BLOCK_PREDICT_DESTROY
                ) {
                    lastMiningPacketMs = now
                }
            }
            is PlayerAuthInputPacket -> handleTick(event, session, pkt, now)
            else -> {}
        }
    }

    private fun isProfileActive(mode: ProfileMode, lastPacketMs: Long, now: Long): Boolean = when (mode) {
        ProfileMode.OFF    -> false
        ProfileMode.ALWAYS -> true
        ProfileMode.AUTO   -> now - lastPacketMs <= contextHoldMs.value
    }

    /** Base TPS plus every currently-active profile's delta from vanilla - profiles stack, they don't override. */
    private fun effectiveTps(now: Long): Float {
        var tps = baseTps.value
        if (isProfileActive(combatMode.value, lastAttackPacketMs, now))    tps += (combatTps.value - VANILLA_TPS)
        if (isProfileActive(miningMode.value, lastMiningPacketMs, now))    tps += (miningTps.value - VANILLA_TPS)
        if (isProfileActive(placingMode.value, lastPlacingPacketMs, now))  tps += (placingTps.value - VANILLA_TPS)
        return tps.coerceIn(MIN_EFFECTIVE_TPS, MAX_EFFECTIVE_TPS)
    }

    private fun handleTick(event: PacketEvent, session: NoxNoRelaySession, pkt: PlayerAuthInputPacket, nowMs: Long) {
        val nowNs = System.nanoTime()
        val x = pkt.position.x; val y = pkt.position.y; val z = pkt.position.z
        val yaw = pkt.rotation.y; val pitch = pkt.rotation.x

        if (!hasLastReal) {
            lastRealTickNs = nowNs
            lastRealX = x; lastRealY = y; lastRealZ = z
            hasLastReal = true
            return
        }

        val realDeltaMs = (nowNs - lastRealTickNs) / 1_000_000.0
        lastRealTickNs = nowNs

        val targetTps = effectiveTps(nowMs)
        val intervalMs = 1000.0 / targetTps

        if (targetTps <= VANILLA_TPS + TPS_EPSILON) {
            // ---- Vanilla or slower: withhold this real tick until enough virtual-tick time has passed ----
            deficitMs += realDeltaMs
            if (deficitMs + 0.001 < intervalMs) {
                lastRealX = x; lastRealY = y; lastRealZ = z
                event.cancel()
                return
            }
            deficitMs -= intervalMs
            // A lag spike (app briefly frozen, etc.) shouldn't let a burst of
            // withheld ticks all through back-to-back once it resumes.
            if (deficitMs > intervalMs) deficitMs = 0.0
            lastRealX = x; lastRealY = y; lastRealZ = z
            return
        }

        // ---- Faster than vanilla: this one real tick may represent several virtual ticks ----
        val dx = x - lastRealX; val dy = y - lastRealY; val dz = z - lastRealZ
        accumulatorMs += realDeltaMs

        var virtualTicks = 0
        while (accumulatorMs >= intervalMs && virtualTicks <= maxInjectedTicks.value) {
            accumulatorMs -= intervalMs
            virtualTicks++
        }
        if (accumulatorMs > intervalMs) accumulatorMs = 0.0

        // The real packet already leaving this tick counts as one virtual tick.
        val extraTicks = (virtualTicks - 1).coerceIn(0, maxInjectedTicks.value)

        lastRealX = x; lastRealY = y; lastRealZ = z

        if (extraTicks > 0 && dx * dx + dz * dz > minMoveThreshold.value * minMoveThreshold.value) {
            val onGround = EntityTracker.selfOnGround
            scope.launch {
                var cx = x; var cy = y; var cz = z
                repeat(extraTicks) {
                    cx += dx; cy += dy; cz += dz
                    CombatUtil.sendMove(session, cx, cy, cz, yaw, pitch, onGround)
                    EntityTracker.selfX = cx; EntityTracker.selfY = cy; EntityTracker.selfZ = cz
                    delay(stepDelayMs.value.toLong())
                }
            }
        }
    }

    private fun handleAttackDuplication(session: NoxNoRelaySession, targetRid: Long, now: Long) {
        if (targetRid == 0L) return
        if (!isProfileActive(combatMode.value, lastAttackPacketMs, now)) return

        val extra = ((combatTps.value / VANILLA_TPS) - 1f).toInt().coerceIn(0, maxInjectedTicks.value)
        if (extra <= 0) return

        val slot = EntityTracker.selfHotbarSlot.coerceIn(0, 8)
        scope.launch {
            repeat(extra) {
                delay(stepDelayMs.value.toLong())
                CombatUtil.sendSwing(session)
                CombatUtil.sendAttack(session, targetRid, slot)
            }
        }
    }
}
