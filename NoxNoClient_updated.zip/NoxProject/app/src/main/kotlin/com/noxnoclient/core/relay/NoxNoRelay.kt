
package com.noxnoclient.core.relay

import com.noxnoclient.core.relay.codec.CodecRegistry
import io.netty.bootstrap.ServerBootstrap
import io.netty.channel.Channel
import io.netty.channel.nio.NioEventLoopGroup
import io.netty.channel.socket.nio.NioDatagramChannel
import org.cloudburstmc.netty.channel.raknet.RakChannelFactory
import org.cloudburstmc.netty.channel.raknet.config.RakChannelOption
import org.cloudburstmc.protocol.bedrock.BedrockPeer
import org.cloudburstmc.protocol.bedrock.BedrockPong
import org.cloudburstmc.protocol.bedrock.PacketDirection
import org.cloudburstmc.protocol.bedrock.codec.BedrockCodec
import org.cloudburstmc.protocol.bedrock.netty.initializer.BedrockChannelInitializer
import java.net.InetSocketAddress
import java.util.concurrent.CopyOnWriteArrayList

class NoxNoRelay(
    private val localPort: Int = 19150
) {
    companion object {
        private const val PONG_MOTD     = "noxno"
        private const val PONG_SUB_MOTD = "NoxNoClient"

        val RELAY_CODEC: BedrockCodec by lazy { CodecRegistry.getLatestCodec() }
    }

    @Volatile private var running      = false
    private var bossGroup    : NioEventLoopGroup? = null
    private var workerGroup  : NioEventLoopGroup? = null
    private var serverChannel: Channel?           = null

    val sessions = CopyOnWriteArrayList<NoxNoRelaySession>()

    @Volatile var remoteHost: String = ""
        internal set
    @Volatile var remotePort: Int = 19132
        internal set

    val boundLocalPort: Int get() = localPort

    fun capture(
        remoteHost       : String,
        remotePort       : Int = 19132,
        onSessionCreated : ((NoxNoRelaySession) -> Unit)? = null
    ) {

        if (running) { stop() }

        this.remoteHost = remoteHost
        this.remotePort = remotePort

        bossGroup   = NioEventLoopGroup(1)
        workerGroup = NioEventLoopGroup(4)

        try {
            val pong = buildPong(RELAY_CODEC.protocolVersion, RELAY_CODEC.minecraftVersion ?: "1.21.60")

            val future = ServerBootstrap()
                .channelFactory(RakChannelFactory.server(NioDatagramChannel::class.java))
                .option(RakChannelOption.RAK_ADVERTISEMENT, pong.toByteBuf())
                .group(bossGroup, workerGroup)
                .childHandler(object : BedrockChannelInitializer<NoxNoRelaySession.ServerSession>() {

                    override fun createSession0(peer: BedrockPeer, subClientId: Int): NoxNoRelaySession.ServerSession {

                        // "Already Connected" fix: Minecraft "Save and Quit" yaptığında
                        // önceki session sunucu tarafında hâlâ open kalıyor. Yeni bir
                        // Bedrock client geldiğinde RakNet "Already Connected" reddeder.
                        // Çözüm: yeni bağlantı gelmeden önce önceki tüm sessionları
                        // sessizce kapat — client zaten ayrılmış durumda.
                        sessions.toList().forEach { old ->
                            try { old.disconnect("New connection incoming") } catch (_: Exception) {}
                        }
                        sessions.clear()

                        val session = NoxNoRelaySession(
                            peer        = peer,
                            subClientId = subClientId,
                            remoteHost  = this@NoxNoRelay.remoteHost,
                            remotePort  = this@NoxNoRelay.remotePort,
                            relay       = this@NoxNoRelay
                        )

                        sessions.add(session)

                        ConnectionManager.setupSession(session, this@NoxNoRelay)

                        session.init()

                        try {
                            onSessionCreated?.invoke(session)
                        } catch (e: Exception) {
                        }

                        return session.clientSession
                    }

                    override fun initSession(session: NoxNoRelaySession.ServerSession) {
                    }

                    override fun preInitChannel(channel: Channel) {
                        channel.attr(PacketDirection.ATTRIBUTE).set(PacketDirection.CLIENT_BOUND)
                        super.preInitChannel(channel)
                    }
                })
                .bind(InetSocketAddress("0.0.0.0", localPort))
                .syncUninterruptibly()

            serverChannel = future.channel()
            running = true

            LanBroadcaster.start(
                relayPort       = localPort,
                motd            = PONG_MOTD,
                subMotd         = PONG_SUB_MOTD,
                protocolVersion = RELAY_CODEC.protocolVersion,
                mcVersion       = RELAY_CODEC.minecraftVersion ?: "1.21.60",
                maxPlayers      = 10
            )

        } catch (e: Exception) {
            shutdownGroups()
            throw e
        }
    }

    suspend fun captureRealm(
        realmId          : Long,
        onSessionCreated : ((NoxNoRelaySession) -> Unit)? = null
    ) {
        val addr = com.noxnoclient.core.relay.realms.RealmsApi.joinRealm(realmId)
        capture(addr.host, addr.port, onSessionCreated)
    }

    fun updateRemoteTarget(host: String, port: Int) {
        remoteHost = host
        remotePort = port
    }

    fun updatePong(protocolVersion: Int, minecraftVersion: String) {
        if (!running) return
        val pong = buildPong(protocolVersion, minecraftVersion)
        try {
            serverChannel?.config()?.setOption(RakChannelOption.RAK_ADVERTISEMENT, pong.toByteBuf())
        } catch (e: Exception) {
        }
        LanBroadcaster.updateInfo(
            protocolVersion = protocolVersion,
            mcVersion       = minecraftVersion,
            motd            = PONG_MOTD
        )
    }

    fun stop() {
        if (!running) return
        running = false
        LanBroadcaster.stop()
        sessions.toList().forEach { it.disconnect("Relay closed") }
        sessions.clear()
        shutdownGroups()
        ConnectionManager.onDisconnected("Relay durduruldu")
    }

    internal fun removeSession(session: NoxNoRelaySession) = sessions.remove(session)

    private fun shutdownGroups() {

        val boss   = bossGroup
        val worker = workerGroup
        bossGroup     = null
        workerGroup   = null
        serverChannel = null

        try { boss?.shutdownGracefully(0, 1, java.util.concurrent.TimeUnit.SECONDS) } catch (_: Exception) {}
        try { worker?.shutdownGracefully(0, 1, java.util.concurrent.TimeUnit.SECONDS) } catch (_: Exception) {}
    }

    val isRunning: Boolean get() = running

    private fun buildPong(protocol: Int, mc: String) = BedrockPong()
        .edition("MCPE")
        .motd(PONG_MOTD)
        .subMotd(PONG_SUB_MOTD)
        .playerCount(0)
        .maximumPlayerCount(10)
        .gameType("Survival")
        .nintendoLimited(false)
        .protocolVersion(protocol)
        .version(mc)
        .ipv4Port(localPort)
        .ipv6Port(localPort)
}
