package com.noxnoclient.module.combat

import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.events.PacketEvent
import com.noxnoclient.events.PacketEventBus
import com.noxnoclient.module.BaseModule
import com.noxnoclient.module.ModuleCategory
import com.noxnoclient.utils.InventoryUtil
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.cloudburstmc.math.vector.Vector3i

/**
 * AutoTrap — surrounds the nearest enemy player in an obsidian box
 * using obsidian already in the hotbar. Disables itself after placing.
 */
class AutoTrap : BaseModule(
    name        = "AutoTrap",
    category    = ModuleCategory.COMBAT,
    description = "Traps nearest enemy in an obsidian box using hotbar obsidian"
) {
    private val range       = float("Range", 5f, 2f, 10f)
    private val blockDelay  = int  ("Block Delay (ms)", 40, 0, 200)
    private val shortcut    = bool ("Shortcut", false)

    private val BLOCK_ID = "minecraft:obsidian"

    private val BOX_OFFSETS = listOf(
        Triple( 0, 0, -1), Triple( 0, 0,  1),
        Triple( 1, 0,  0), Triple(-1, 0,  0),
        Triple( 0, 1, -1), Triple( 0, 1,  1),
        Triple( 1, 1,  0), Triple(-1, 1,  0),
        Triple( 0, 2,  0)
    )

    private var trapJob: Job? = null

    override fun onEnable() {
        super.onEnable()
        trapJob = scope.launch { runTrap() }
    }

    override fun onDisable() {
        trapJob?.cancel(); trapJob = null
        super.onDisable()
    }

    override fun onPacket(event: PacketEvent) {}

    private suspend fun runTrap() {
        val session = PacketEventBus.currentSession ?: return
        val target = EntityTracker.getNearestPlayer(range.value) ?: run { setEnabled(false); return }

        val tx = target.x.toInt(); val ty = target.y.toInt(); val tz = target.z.toInt()
        val obsidianSlot = findObsidianInHotbar() ?: run { setEnabled(false); return }
        val originalSlot = EntityTracker.selfHotbarSlot

        InventoryUtil.sendHotbarSelect(session, obsidianSlot)
        EntityTracker.selfHotbarSlot = obsidianSlot

        for ((dx, dy, dz) in BOX_OFFSETS) {
            val bx = tx + dx; val by = ty + dy; val bz = tz + dz
            if (isPlayerAt(bx, by, bz)) continue

            val neighbor = InventoryUtil.findClickableNeighbor(bx, by, bz) ?: continue
            val (_, adjId, face) = neighbor
            val item = EntityTracker.getInventoryItem(obsidianSlot) ?: break
            if (item.count <= 0) break

            val prepared = InventoryUtil.PreparedItem(obsidianSlot, item, null)
            InventoryUtil.sendPlacementUseRaw(
                session, prepared,
                Vector3i.from(bx, by, bz), adjId, face
            )
            delay(blockDelay.value.toLong())
        }

        InventoryUtil.sendHotbarSelect(session, originalSlot)
        EntityTracker.selfHotbarSlot = originalSlot
        setEnabled(false)
    }

    private fun findObsidianInHotbar(): Int? {
        for (slot in 0..8) {
            val item = EntityTracker.getInventoryItem(slot) ?: continue
            if (item.count <= 0) continue
            val id = InventoryUtil.resolveIdentifier(item) ?: continue
            if (id == BLOCK_ID) return slot
        }
        return null
    }

    private fun isPlayerAt(x: Int, y: Int, z: Int): Boolean {
        val px = EntityTracker.selfX.toInt()
        val py = EntityTracker.selfY.toInt()
        val pz = EntityTracker.selfZ.toInt()
        return x == px && (y == py || y == py + 1) && z == pz
    }
}
