package com.noxnoclient.module.visual

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.module.BaseModule
import com.noxnoclient.module.ModuleCategory
import com.noxnoclient.module.social.isFriendEntity
import com.noxnoclient.utils.MathUtil
import com.noxnoclient.utils.UiUtil

/**
 * Full ESP for other players: perspective-correct bounding box (8 world-space corners
 * projected individually, not a single flattened box - this stays accurate up close and
 * at odd angles where cheaper single-point ESPs distort), health bar, name/distance/gear
 * summary, and an optional tracer. Friends are colour-separated from enemies automatically.
 */
class PlayerESP : BaseModule(
    name        = "PlayerESP",
    category    = ModuleCategory.VISUAL,
    description = "Diğer oyuncular için kutu, can barı, isim ve tracer gösterir"
) {
    private val range        = float("Range",        128f, 8f,   256f)
    private val box          = bool ("Box",           true)
    private val fill         = bool ("Fill",          true)
    private val healthBar    = bool ("Health Bar",    true)
    private val nameTag      = bool ("Name",          true)
    private val distanceTag  = bool ("Distance",      true)
    private val gearTag      = bool ("Gear Summary",  true)
    private val tracer       = bool ("Tracer",        false)
    private val hideFriends  = bool ("Hide Friends",  false)
    private val distanceFade = bool ("Distance Fade", true)

    companion object {
        private const val HALF_WIDTH  = 0.35f
        private const val HEIGHT      = 1.85f
        private const val SNEAK_TRIM  = 0.15f
    }

    private val boxPaint = Paint().apply { style = Paint.Style.STROKE; strokeWidth = 3.5f; isAntiAlias = true }
    private val fillPaint = Paint().apply { style = Paint.Style.FILL; isAntiAlias = true }
    private val tracerPaint = Paint().apply { style = Paint.Style.STROKE; strokeWidth = 2.5f; isAntiAlias = true }
    private val textPaint = Paint().apply {
        isAntiAlias = true; textSize = 30f; textAlign = Paint.Align.CENTER
        setShadowLayer(3f, 0f, 0f, Color.BLACK)
    }
    private val hpBg = Paint().apply { color = Color.argb(180, 20, 20, 20); style = Paint.Style.FILL }
    private val hpFg = Paint().apply { style = Paint.Style.FILL }

    fun render(canvas: Canvas, screenW: Int, screenH: Int) {
        val selfX = EntityTracker.selfX; val selfY = EntityTracker.selfY; val selfZ = EntityTracker.selfZ
        val yaw = EntityTracker.selfYaw; val pitch = EntityTracker.selfPitch
        val fov = UiUtil.currentFov

        val targets = EntityTracker.getEntitiesInRange(range.value) {
            it.isPlayer && it.runtimeId != EntityTracker.selfRuntimeId && !it.isInvisible
        }
        if (targets.isEmpty()) return

        for (t in targets) {
            if (hideFriends.value && t.isFriendEntity) continue

            val dist = MathUtil.dist3(t.x, t.y, t.z, selfX, selfY, selfZ)
            val alpha = if (distanceFade.value) fadeAlpha(dist, range.value) else 255

            val rect = projectBox(t, selfX, selfY, selfZ, yaw, pitch, screenW, screenH, fov) ?: continue

            val color = if (t.isFriendEntity) Color.rgb(70, 220, 90) else enemyColor(t.healthPercent)

            if (box.value) {
                if (fill.value) {
                    fillPaint.color = Color.argb((alpha * 0.14f).toInt(), Color.red(color), Color.green(color), Color.blue(color))
                    canvas.drawRect(rect, fillPaint)
                }
                boxPaint.color = Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color))
                canvas.drawRect(rect, boxPaint)
            }

            if (healthBar.value) drawHealthBar(canvas, rect, t.healthPercent, alpha)

            var textY = rect.top - 8f
            if (nameTag.value) {
                val label = if (distanceTag.value) "${t.name.ifBlank { "Player" }} (${dist.toInt()}m)"
                            else t.name.ifBlank { "Player" }
                textPaint.color = Color.argb(alpha, 255, 255, 255)
                canvas.drawText(label, rect.centerX(), textY, textPaint)
                textY -= textPaint.textSize + 4f
            } else if (distanceTag.value) {
                textPaint.color = Color.argb(alpha, 255, 255, 255)
                canvas.drawText("${dist.toInt()}m", rect.centerX(), textY, textPaint)
                textY -= textPaint.textSize + 4f
            }

            if (gearTag.value) {
                val gear = gearSummary(t)
                if (gear.isNotEmpty()) {
                    textPaint.textSize = 22f
                    textPaint.color = Color.argb(alpha, 235, 235, 120)
                    canvas.drawText(gear, rect.centerX(), rect.bottom + 26f, textPaint)
                    textPaint.textSize = 30f
                }
            }

            if (tracer.value) {
                tracerPaint.color = Color.argb((alpha * 0.6f).toInt(), Color.red(color), Color.green(color), Color.blue(color))
                canvas.drawLine(screenW / 2f, screenH.toFloat(), rect.centerX(), rect.bottom, tracerPaint)
            }
        }
    }

    private fun enemyColor(healthPct: Float): Int {
        // Can barından bağımsız, ekstra bir görsel ipucu: kutu rengi de cana göre
        // yeşile kayar (düşük canlı = kırmızıya yakın, tam can = turuncuya yakın).
        val r = 235
        val g = (60 + 120 * healthPct).toInt().coerceIn(60, 180)
        val b = 55
        return Color.rgb(r, g, b)
    }

    private fun fadeAlpha(dist: Float, range: Float): Int {
        val t = (1f - (dist / range)).coerceIn(0.35f, 1f)
        return (255 * t).toInt()
    }

    private fun drawHealthBar(canvas: Canvas, rect: RectF, pct: Float, alpha: Int) {
        val barW = 6f
        val barX = rect.left - barW - 4f
        hpBg.alpha = (alpha * 0.7f).toInt()
        canvas.drawRect(barX, rect.top, barX + barW, rect.bottom, hpBg)
        val fillTop = rect.bottom - (rect.height() * pct.coerceIn(0f, 1f))
        hpFg.color = Color.rgb((255 * (1f - pct)).toInt(), (200 * pct).toInt(), 40)
        hpFg.alpha = alpha
        canvas.drawRect(barX, fillTop, barX + barW, rect.bottom, hpFg)
    }

    private fun gearSummary(t: EntityTracker.TrackedEntity): String {
        val pieces = listOf(t.helmetItem, t.chestplateItem, t.leggingsItem, t.bootsItem)
        val armorCount = pieces.count { it != null && it.count > 0 && !isAirLike(it) }
        val hand = t.mainHandItem
        val handName = hand?.takeIf { it.count > 0 && !isAirLike(it) }
            ?.let { com.noxnoclient.utils.InventoryUtil.resolveIdentifier(it)?.removePrefix("minecraft:") }
        return buildString {
            if (armorCount > 0) append("Armor $armorCount/4")
            if (handName != null) { if (isNotEmpty()) append("  "); append(handName) }
        }
    }

    private fun isAirLike(item: org.cloudburstmc.protocol.bedrock.data.inventory.ItemData): Boolean =
        com.noxnoclient.utils.InventoryUtil.resolveIdentifier(item)?.let { it == "minecraft:air" } ?: true

    /**
     * Perspective-correct box: projects all 8 corners of the entity's world-space AABB
     * individually and takes the screen-space min/max, instead of estimating a flat
     * width/height in screen pixels from distance alone - stays accurate up close, at
     * steep angles, and when partially out of frame.
     */
    private fun projectBox(
        t: EntityTracker.TrackedEntity,
        selfX: Float, selfY: Float, selfZ: Float,
        yaw: Float, pitch: Float,
        screenW: Int, screenH: Int, fov: Float
    ): RectF? {
        val hw = HALF_WIDTH
        val h  = if (t.isSneaking) HEIGHT - SNEAK_TRIM else HEIGHT
        val corners = arrayOf(
            floatArrayOf(t.x - hw, t.y,     t.z - hw), floatArrayOf(t.x + hw, t.y,     t.z - hw),
            floatArrayOf(t.x - hw, t.y,     t.z + hw), floatArrayOf(t.x + hw, t.y,     t.z + hw),
            floatArrayOf(t.x - hw, t.y + h, t.z - hw), floatArrayOf(t.x + hw, t.y + h, t.z - hw),
            floatArrayOf(t.x - hw, t.y + h, t.z + hw), floatArrayOf(t.x + hw, t.y + h, t.z + hw)
        )

        var minX = Float.MAX_VALUE; var maxX = -Float.MAX_VALUE
        var minY = Float.MAX_VALUE; var maxY = -Float.MAX_VALUE
        var hits = 0

        for (c in corners) {
            val s = MathUtil.worldToScreen(c[0], c[1], c[2], selfX, selfY, selfZ, yaw, pitch, screenW, screenH, fov) ?: continue
            hits++
            if (s.first < minX) minX = s.first
            if (s.first > maxX) maxX = s.first
            if (s.second < minY) minY = s.second
            if (s.second > maxY) maxY = s.second
        }

        if (hits < 4) return null
        if (maxX < -50 || minX > screenW + 50 || maxY < -50 || minY > screenH + 50) return null
        return RectF(minX, minY, maxX, maxY)
    }
}
