package com.noxnoclient.session

import com.noxnoclient.auth.AccountManager
import com.noxnoclient.config.ServerConfig
import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.core.relay.ConnectionManager
import com.noxnoclient.core.relay.LanBroadcaster
import com.noxnoclient.core.relay.NoxNoRelay
import com.noxnoclient.core.relay.NoxNoRelaySession
import com.noxnoclient.events.PacketEventBus
import com.noxnoclient.module.ModuleManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

object SessionManager {

    private const val TAG = "SessionManager"

    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _isActive       = MutableStateFlow(false)
    val isActive: StateFlow<Boolean> = _isActive.asStateFlow()

    private val _connectedHost  = MutableStateFlow("")
    val connectedHostFlow: StateFlow<String> = _connectedHost.asStateFlow()

    private val _connectedPort  = MutableStateFlow(0)
    val connectedPortFlow: StateFlow<Int> = _connectedPort.asStateFlow()

    private val _statusMessage  = MutableStateFlow("Disconnected")
    val statusMessage: StateFlow<String> = _statusMessage.asStateFlow()

    private val _sessionCount   = MutableStateFlow(0)
    val sessionCount: StateFlow<Int> = _sessionCount.asStateFlow()

    val connectedHost: String get() = _connectedHost.value
    val connectedPort: Int    get() = _connectedPort.value

    private var relay: NoxNoRelay? = null

    fun start() {
        if (_isActive.value) { return }

        val account = AccountManager.getRelayReadyAccount()
        if (account == null) {
            _statusMessage.value = "No account found"
            return
        }

        val host      = ServerConfig.getHostBlocking()
        val port      = ServerConfig.getPortBlocking()
        val localPort = ServerConfig.LOCAL_PROXY_PORT

        _statusMessage.value = "Connecting..."

        try {
            EntityTracker.init()

            val r = NoxNoRelay(localPort = localPort)

            r.capture(remoteHost = host, remotePort = port) { session ->
                onSessionCreated(session)
            }

            relay                = r
            _isActive.value      = true
            _connectedHost.value = host
            _connectedPort.value = port
            _statusMessage.value = "Aktif — $host:$port"
            _sessionCount.value  = 0

        } catch (e: Exception) {
            _isActive.value      = false
            _statusMessage.value = "Hata: ${e.message}"
            relay                = null
        }
    }

    fun stop() {
        if (!_isActive.value) return

        val relayToStop      = relay
        relay                = null
        _isActive.value      = false
        _connectedHost.value = ""
        _connectedPort.value = 0
        _statusMessage.value = "Disconnected"
        _sessionCount.value  = 0
        PacketEventBus.setSession(null)
        EntityTracker.reset()
        ConnectionManager.onDisconnected("Relay durduruldu")

        ioScope.launch {
            try {
                ModuleManager.disableAll()
                relayToStop?.stop()
            } catch (e: Exception) {
            }
        }
    }

    private fun onSessionCreated(session: NoxNoRelaySession) {
        _sessionCount.value++
        _statusMessage.value = "Session #${_sessionCount.value} — ${session.clientAddress}"

        LanBroadcaster.updateInfo(
            protocolVersion = NoxNoRelay.RELAY_CODEC.protocolVersion,
            mcVersion       = NoxNoRelay.RELAY_CODEC.minecraftVersion ?: "1.21.60",
            playerCount     = 0
        )

        installSessionCloseListener(session)
    }

    private fun installSessionCloseListener(session: NoxNoRelaySession) {
        try {
            session.clientSession.peer.channel
                .closeFuture()
                .addListener { onSessionEnded(session, "channel closed") }
        } catch (e: Exception) {
        }
    }

    private fun onSessionEnded(session: NoxNoRelaySession, reason: String) {
        PacketEventBus.setSession(null)
        EntityTracker.reset()

        _sessionCount.value = maxOf(0, _sessionCount.value - 1)

        if (_isActive.value) {
            _statusMessage.value = "Session closed — waiting to reconnect"
            ConnectionManager.onDisconnected(reason)
        }
    }

    fun onSessionStart(host: String, port: Int) = start()
    fun onSessionStop() = stop()
}
