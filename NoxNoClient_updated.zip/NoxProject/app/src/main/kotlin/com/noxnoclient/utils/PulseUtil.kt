package com.noxnoclient.utils

import android.graphics.Color
import kotlin.math.sin

object PulseUtil {
    private const val DEFAULT_PERIOD_MS = 1800L
    private val GREEN = Color.rgb(0, 230, 90)
    private val BLACK = Color.rgb(0, 0, 0)

    fun color(periodMs: Long = DEFAULT_PERIOD_MS): Int {
        val phase = (System.currentTimeMillis() % periodMs).toDouble() / periodMs
        val t = ((sin(phase * 2 * Math.PI) + 1.0) / 2.0).toFloat()
        return blend(BLACK, GREEN, t)
    }

    private fun blend(a: Int, b: Int, f: Float): Int {
        val ar = Color.red(a); val ag = Color.green(a); val ab = Color.blue(a)
        val br = Color.red(b); val bg = Color.green(b); val bb = Color.blue(b)
        return Color.rgb(
            (ar + (br - ar) * f).toInt().coerceIn(0, 255),
            (ag + (bg - ag) * f).toInt().coerceIn(0, 255),
            (ab + (bb - ab) * f).toInt().coerceIn(0, 255)
        )
    }
}
