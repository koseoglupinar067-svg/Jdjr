package com.noxnoclient.module.misc

import com.noxnoclient.events.PacketEvent
import com.noxnoclient.module.BaseModule
import com.noxnoclient.module.ModuleCategory
import org.cloudburstmc.protocol.bedrock.packet.TextPacket
import kotlin.random.Random

/**
 * Appends a fixed-shape suffix to every chat message the player sends:
 *
 *     <original message> | NoxNo | <6-char random>
 *
 * The 6-char tail is a single concatenated alphanumeric string (letters+digits,
 * no separators inside it) generated fresh per message, so no two messages ever
 * produce an identical suffix.
 */
class ChatSuffixModule : BaseModule(
    name        = "ChatSuffix",
    category    = ModuleCategory.MISC,
    description = "Appends \"| NoxNo | <6-char random>\" to every chat message you type"
) {
    companion object {
        private const val TAG = "NoxNo"
        private const val RANDOM_LEN = 6
        private const val CHARS = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"

        // Bir mesajın zaten bizim eklediğimiz kalıbı taşıyıp taşımadığını anlamak için -
        // rastgele kısım her seferinde değiştiği için tam eşleşme yerine sabit kalıbı arıyoruz.
        private val MARKER = " | $TAG | "
    }

    private val shortcut = bool("Shortcut", false)

    override fun onPacket(event: PacketEvent) {
        if (!isEnabled) return
        if (event.direction != PacketEvent.Direction.CLIENT_TO_SERVER) return

        val out = event.packet
        if (out !is TextPacket) return
        if (out.type != TextPacket.Type.CHAT) return
        if (out.sourceName == InternalChat.MARKER) return

        val original = out.message
        if (original.isBlank() || original.contains(MARKER)) return

        event.cancelAndReplace(TextPacket().apply {
            type               = TextPacket.Type.CHAT
            isNeedsTranslation = false
            sourceName         = out.sourceName
            xuid               = out.xuid
            platformChatId     = out.platformChatId
            setMessage("$original$MARKER${randomSuffix()}")
            setFilteredMessage("")
        })
    }

    private fun randomSuffix(): String =
        buildString(RANDOM_LEN) { repeat(RANDOM_LEN) { append(CHARS[Random.nextInt(CHARS.length)]) } }
}
