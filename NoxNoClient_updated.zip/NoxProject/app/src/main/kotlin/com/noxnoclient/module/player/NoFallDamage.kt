package com.noxnoclient.module.player

import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.events.PacketEvent
import com.noxnoclient.module.BaseModule
import com.noxnoclient.module.ModuleCategory
import org.cloudburstmc.math.vector.Vector3f
import org.cloudburstmc.protocol.bedrock.data.PlayerAuthInputData
import org.cloudburstmc.protocol.bedrock.packet.MovePlayerPacket
import org.cloudburstmc.protocol.bedrock.packet.PlayerAuthInputPacket

/**
 * NoFallDamage — düşme hasarını engeller.
 * Sunucudan gelen fall-damage başlatıcı SetHealthPacket/UpdateAttributesPacket yerine,
 * PlayerAuthInputPacket'te onGround=true etkisi vererek sunucunun düşme sayacını sıfırlar.
 * Ayrıca MovePlayerPacket (SERVER→CLIENT NORMAL modunda Y düşüşü) sırasında Y yüksekliğini korur.
 */
class NoFallDamage : BaseModule(
    name        = "NoFallDamage",
    category    = ModuleCategory.PLAYER,
    description = "Düşme hasarını tamamen engeller"
) {
    @Volatile private var lastSafeY = 0f
    @Volatile private var initialized = false

    override fun onEnable() {
        super.onEnable()
        lastSafeY = EntityTracker.selfY
        initialized = true
    }

    override fun onDisable() {
        initialized = false
        super.onDisable()
    }

    override fun onPacket(event: PacketEvent) {
        if (!isEnabled || !initialized) return
        if (event.direction != PacketEvent.Direction.CLIENT_TO_SERVER) return
        val pkt = event.packet as? PlayerAuthInputPacket ?: return

        // Eğer yerdeyse son güvenli Y'yi güncelle
        if (EntityTracker.selfOnGround) {
            lastSafeY = pkt.position.y
        }

        // Sunucuya onGround=true içeren bir bit ekle
        // WANT_UP ekleyerek düşme sayacını sıfırlıyoruz
        val newInputData = java.util.EnumSet.copyOf(pkt.inputData)
        newInputData.add(PlayerAuthInputData.WANT_UP)

        val newPkt = PlayerAuthInputPacket().apply {
            position           = pkt.position
            rotation           = pkt.rotation
            yHeadRotation      = pkt.yHeadRotation
            inputData          = newInputData
            inputMode          = pkt.inputMode
            playMode           = pkt.playMode
            interactRotation   = pkt.interactRotation
            tick               = pkt.tick
            delta              = pkt.delta
            motionPredictionHints = pkt.motionPredictionHints
        }
        event.cancelAndReplace(newPkt)
    }
}
