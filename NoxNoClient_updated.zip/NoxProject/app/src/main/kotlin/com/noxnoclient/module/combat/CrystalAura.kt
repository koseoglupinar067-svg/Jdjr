package com.noxnoclient.module.combat

import com.noxnoclient.utils.CombatUtil
import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.core.relay.NoxNoRelaySession
import com.noxnoclient.events.PacketEvent
import com.noxnoclient.events.PacketEventBus
import com.noxnoclient.module.*
import com.noxnoclient.utils.InventoryUtil
import com.noxnoclient.utils.MathUtil
import com.noxnoclient.utils.WorldBlockTracker
import kotlinx.coroutines.*
import org.cloudburstmc.math.vector.Vector3i
import org.cloudburstmc.protocol.bedrock.data.LevelEvent
import org.cloudburstmc.protocol.bedrock.packet.*
import kotlin.math.floor

class CrystalAura : BaseModule(
    name        = "CrystalAura",
    category    = ModuleCategory.COMBAT,
    description = "Places/breaks crystals at the best spot based on damage simulation - burst explode/place with retry-on-failure"
) {

    companion object {
        private const val EXPLOSION_SIZE   = 6f
        private const val TICK_INTERVAL_MS = 25L
        private const val CRYSTAL_ID       = "minecraft:end_crystal"
        private const val OBSIDIAN_ID      = "minecraft:obsidian"
        private const val PENDING_TIMEOUT_MS = 450L
        private const val PENDING_MATCH_RADIUS = 1.5f
        private const val BASE_VERTICAL_RANGE = 3
        private const val BASE_PLACE_TIMEOUT_MS = 400L
        private const val MAX_PREDICT_SECONDS = 0.15f
        private const val QUEUE_REFRESH_MS = 250L

        private val NON_SOLID = setOf(
            "minecraft:air", "minecraft:water", "minecraft:flowing_water",
            "minecraft:lava", "minecraft:flowing_lava",
            "minecraft:void_air", "minecraft:cave_air"
        )
    }

    private val range           = float("Range",           10f,  3f,  10f)
    private val suicide         = bool ("Suicide",         false)
    private val place           = bool ("Place",           true)
    private val placeCount      = int  ("PlaceCount",      8,    1,   8)
    private val placeDelayMs    = int  ("PlaceDelay",      20,   20,  500)
    private val explodeDelayMs  = int  ("ExplodeDelay",    10,   10,  300)
    private val removeParticles = bool ("RemoveParticles", true)
    private val predictMovement = bool ("Predict Movement", true)
    private val autoBase        = bool ("Auto Base",        true)

    private val maxExplodesPerTick = int  ("Max Explodes Per Tick", 3, 1, 6)
    private val explodeRetryMs     = int  ("Explode Retry (ms)", 120, 40, 500)
    private val maxExplodeRetries  = int  ("Max Explode Retries", 2, 0, 4)
    private val burstPlaceCount    = int  ("Burst Place Count", 2, 1, 4)
    private val panicHealth        = float("Panic Health", 6f, 0f, 20f)
    private val maxSelfDamage      = float("Max Self Damage", 8f, 0f, 40f)
    private val fastMode           = bool ("Fast Mode", false)

    private val shortcut        = bool ("Shortcut",        false)

    @Volatile private var lastExplodeMs = 0L
    @Volatile private var lastPlaceMs   = 0L

    private var tickJob: Job? = null

    private data class PendingPlace(
        val x: Float, val y: Float, val z: Float,
        val sentAt: Long,
        val blockId: String,
        val itemNetId: Int,
        val hotbarSlot: Int
    )

    private data class PendingBase(val x: Int, val y: Int, val z: Int, val sentAt: Long)

    private data class PendingExplode(val runtimeId: Long, val hitAt: Long, val retries: Int)

    private val pendingPlaces   = java.util.concurrent.CopyOnWriteArrayList<PendingPlace>()
    private val pendingBases    = java.util.concurrent.CopyOnWriteArrayList<PendingBase>()
    private val pendingExplodes = java.util.concurrent.CopyOnWriteArrayList<PendingExplode>()

    private data class ExplosionResult(val mostDamage: Float, val selfDamage: Float)

    private fun effectiveMs(ms: Int): Long = if (fastMode.value) (ms / 2).coerceAtLeast(10).toLong() else ms.toLong()

    private fun panicPaused(): Boolean =
        panicHealth.value > 0f && EntityTracker.selfHealth <= panicHealth.value && !suicide.value

    private fun isSelfSafe(dmg: ExplosionResult): Boolean {
        if (suicide.value) return true
        if (dmg.selfDamage >= EntityTracker.selfHealth) return false
        return dmg.selfDamage <= maxSelfDamage.value
    }

    override fun onEnable() {
        super.onEnable()
        lastExplodeMs = 0L
        lastPlaceMs   = 0L
        placeQueueBuiltMs = 0L
        pendingExplodes.clear()
        PacketEventBus.register(this)
        tickJob = scope.launch { tickLoop() }
    }

    override fun onDisable() {
        tickJob?.cancel()
        PacketEventBus.unregister(this)
        placeQueue.clear()
        pendingPlaces.clear()
        pendingBases.clear()
        pendingExplodes.clear()
        super.onDisable()
    }

    override fun onPacket(event: PacketEvent) {
        if (!isEnabled) return
        when (val pkt = event.packet) {
            is AddEntityPacket -> {
                if (!pkt.identifier.contains("crystal", ignoreCase = true)) return
                val now = System.currentTimeMillis()
                val cx = pkt.position.x; val cy = pkt.position.y; val cz = pkt.position.z

                val matched = pendingPlaces.filter {
                    MathUtil.dist3(it.x, it.y, it.z, cx, cy, cz) <= PENDING_MATCH_RADIUS
                }
                if (matched.isNotEmpty()) {
                    pendingPlaces.removeAll(matched)
                }

                val distToSelf = MathUtil.dist3(cx, cy, cz, EntityTracker.selfX, EntityTracker.selfY, EntityTracker.selfZ)
                if (now - lastExplodeMs < explodeDelayMs.value) {
                    return
                }
                if (distToSelf > range.value) {
                    return
                }

                val dmg = simulateExplosionDamage(cx, cy, cz)
                val hasRealTarget = dmg.mostDamage > 0f
                if ((hasRealTarget && isSelfSafe(dmg)) || suicide.value) {
                    val session = PacketEventBus.currentSession ?: return
                    explodeCrystal(session, pkt.runtimeEntityId)
                    lastExplodeMs = now
                }
            }
            is LevelEventPacket -> {
                if (removeParticles.value && pkt.type == LevelEvent.PARTICLE_EXPLOSION) event.cancel()
            }
            else -> {}
        }
    }

    private suspend fun tickLoop() {
        while (currentCoroutineContext().isActive) {
            if (isEnabled) tick()
            delay(TICK_INTERVAL_MS)
        }
    }

    private fun tick() {
        val session = PacketEventBus.currentSession ?: return
        val now = System.currentTimeMillis()
        checkTimedOutPlacements(session, now)
        checkPendingBases(now)
        checkPendingExplodeRetries(session, now)
        if (now - lastExplodeMs >= effectiveMs(explodeDelayMs.value)) tryExplodeBurst(session, now)
        if (place.value && now - lastPlaceMs >= effectiveMs(placeDelayMs.value) && !panicPaused()) tryPlaceBurst(session, now)
    }

    private fun checkTimedOutPlacements(session: NoxNoRelaySession, now: Long) {
        if (pendingPlaces.isEmpty()) return
        val timedOut = pendingPlaces.filter { now - it.sentAt > PENDING_TIMEOUT_MS }
        if (timedOut.isEmpty()) return
        pendingPlaces.removeAll(timedOut)
    }

    private fun checkPendingBases(now: Long) {
        if (pendingBases.isEmpty()) return
        val confirmed = ArrayList<PendingBase>()
        val expired = ArrayList<PendingBase>()
        for (b in pendingBases) {
            val id = WorldBlockTracker.getBlockIdentifier(b.x, b.y, b.z)
            when {
                id == OBSIDIAN_ID -> confirmed.add(b)
                now - b.sentAt > BASE_PLACE_TIMEOUT_MS -> expired.add(b)
            }
        }
        if (confirmed.isNotEmpty()) {
            pendingBases.removeAll(confirmed)
            for (b in confirmed) placeQueue.add(0, Triple(b.x, b.y, b.z))
        }
        if (expired.isNotEmpty()) pendingBases.removeAll(expired)
    }

    private fun checkPendingExplodeRetries(session: NoxNoRelaySession, now: Long) {
        if (pendingExplodes.isEmpty()) return
        val resolved = ArrayList<PendingExplode>()
        val retryNow = ArrayList<PendingExplode>()

        for (p in pendingExplodes) {
            val stillAlive = EntityTracker.getById(p.runtimeId) != null
            if (!stillAlive) {
                resolved.add(p)
                continue
            }
            if (now - p.hitAt >= effectiveMs(explodeRetryMs.value)) {
                if (p.retries >= maxExplodeRetries.value) {
                    resolved.add(p)
                } else {
                    retryNow.add(p)
                }
            }
        }

        if (resolved.isNotEmpty()) pendingExplodes.removeAll(resolved)
        if (retryNow.isNotEmpty()) {
            pendingExplodes.removeAll(retryNow)
            for (p in retryNow) {
                CombatUtil.sendSwing(session)
                CombatUtil.sendAttack(session, p.runtimeId)
                pendingExplodes.add(p.copy(hitAt = now, retries = p.retries + 1))
            }
        }
    }

    private fun predictedPos(target: EntityTracker.TrackedEntity): Triple<Float, Float, Float> {
        if (!predictMovement.value) return Triple(target.x, target.y, target.z)
        val t = (target.pingMs / 2000f).coerceIn(0f, MAX_PREDICT_SECONDS)
        return target.predictedPosition(t)
    }

    private fun tryExplodeBurst(session: NoxNoRelaySession, now: Long) {
        val crystals = EntityTracker.getCrystals(range.value)
        if (crystals.isEmpty()) return

        val alreadyPending = pendingExplodes.mapTo(HashSet()) { it.runtimeId }

        val worthwhile = crystals.asSequence()
            .filter { it.runtimeId !in alreadyPending }
            .mapNotNull { c ->
                val dmg = simulateExplosionDamage(c.x, c.y, c.z)
                val effective = if (!isSelfSafe(dmg)) -1f else dmg.mostDamage
                if (effective > 0f) Pair(c, effective) else null
            }
            .sortedByDescending { it.second }
            .take(maxExplodesPerTick.value)
            .toList()

        if (worthwhile.isEmpty()) return

        for ((c, _) in worthwhile) {
            explodeCrystal(session, c.runtimeId)
        }
        lastExplodeMs = now
    }

    private var placeQueue: MutableList<Triple<Int, Int, Int>> = mutableListOf()
    @Volatile private var placeQueueBuiltMs = 0L

    private fun tryPlaceBurst(session: NoxNoRelaySession, now: Long) {
        if (placeQueue.isEmpty() || now - placeQueueBuiltMs >= QUEUE_REFRESH_MS) {
            placeQueue = buildPlaceQueue()
            placeQueueBuiltMs = now
            if (placeQueue.isEmpty()) {
                tryAutoPlaceBase(session, now)
                return
            }
        }

        var placedThisPass = 0

        while (placeQueue.isNotEmpty() && placedThisPass < burstPlaceCount.value) {
            val pos = placeQueue.removeAt(0)

            val blockId = WorldBlockTracker.getBlockIdentifier(pos.first, pos.second, pos.third) ?: continue
            if (blockId != "minecraft:obsidian" && blockId != "minecraft:bedrock") continue

            val spotId = WorldBlockTracker.getBlockIdentifier(pos.first, pos.second + 1, pos.third)
            if (spotId != null && spotId !in NON_SOLID) continue

            val cx = pos.first + 0.5f
            val cy = pos.second + 2f
            val cz = pos.third + 0.5f

            val dmg = simulateExplosionDamage(cx, cy, cz)
            val eff = if (!isSelfSafe(dmg)) -1f else dmg.mostDamage
            if (eff <= 0f && !suicide.value) continue

            val placeDist = MathUtil.dist3(
                EntityTracker.selfX, EntityTracker.selfY, EntityTracker.selfZ,
                cx, pos.second + 1f, cz
            )
            if (placeDist > range.value) continue

            val prepared = InventoryUtil.prepareItemForUse(session, CRYSTAL_ID) ?: run {
                placeQueue.clear()
                return
            }

            val blockPos = Vector3i.from(pos.first, pos.second, pos.third)
            val ok = InventoryUtil.sendPlacementUseRaw(
                session   = session,
                prepared  = prepared,
                blockPos  = blockPos,
                blockId   = blockId,
                blockFace = 1
            )
            InventoryUtil.revert(session, prepared)

            if (ok) {
                pendingPlaces.add(PendingPlace(
                    x = cx, y = pos.second + 1f, z = cz,
                    sentAt = now,
                    blockId = blockId,
                    itemNetId = prepared.item.netId,
                    hotbarSlot = prepared.slot
                ))
                lastPlaceMs = now
                placedThisPass++
            }
        }

        if (placedThisPass == 0) {

            tryAutoPlaceBase(session, now)
        }
    }

    private fun tryAutoPlaceBase(session: NoxNoRelaySession, now: Long) {
        if (!autoBase.value) return
        if (pendingBases.isNotEmpty()) return

        InventoryUtil.findItemInInventory(OBSIDIAN_ID) ?: return

        val target = EntityTracker.getPlayers(range.value)
            .filter { it.runtimeId != EntityTracker.selfRuntimeId }
            .minByOrNull {
                MathUtil.dist3sq(it.x, it.y, it.z, EntityTracker.selfX, EntityTracker.selfY, EntityTracker.selfZ)
            } ?: return

        val (pos, belowId) = findAutoBaseSpot(target) ?: return

        val dist = MathUtil.dist3(
            pos.x + 0.5f, pos.y + 0.5f, pos.z + 0.5f,
            EntityTracker.selfX, EntityTracker.selfY + 1.62f, EntityTracker.selfZ
        )
        if (dist > range.value) return

        val prepared = InventoryUtil.prepareItemForUse(session, OBSIDIAN_ID) ?: return
        val belowPos = Vector3i.from(pos.x, pos.y - 1, pos.z)
        val ok = InventoryUtil.sendPlacementUseRaw(session, prepared, belowPos, belowId, blockFace = 1)
        InventoryUtil.revert(session, prepared)
        if (!ok) return

        pendingBases.add(PendingBase(pos.x, pos.y, pos.z, now))
    }

    private fun findAutoBaseSpot(target: EntityTracker.TrackedEntity): Pair<Vector3i, String>? {
        val (px, py, pz) = predictedPos(target)
        val tx = floor(px).toInt()
        val ty = floor(py).toInt()
        val tz = floor(pz).toInt()

        var best: Pair<Vector3i, String>? = null
        var bestDistSq = Float.MAX_VALUE

        for (dy in -1..1) {
            for (dx in -1..1) {
                for (dz in -1..1) {
                    if (dx == 0 && dz == 0 && dy == 0) continue
                    val bx = tx + dx; val by = ty + dy; val bz = tz + dz
                    if (!WorldBlockTracker.hasData(bx, by, bz)) continue
                    val id = WorldBlockTracker.getBlockIdentifier(bx, by, bz) ?: "minecraft:air"
                    if (id !in NON_SOLID) continue
                    val belowId = WorldBlockTracker.getBlockIdentifier(bx, by - 1, bz) ?: continue
                    if (belowId in NON_SOLID) continue

                    val distSq = MathUtil.dist3sq(bx + 0.5f, by + 0.5f, bz + 0.5f, px, py, pz)
                    if (distSq < bestDistSq) {
                        bestDistSq = distSq
                        best = Vector3i.from(bx, by, bz) to belowId
                    }
                }
            }
        }
        return best
    }

    private fun buildPlaceQueue(): MutableList<Triple<Int, Int, Int>> {
        if (!WorldBlockTracker.hasAnyTerrainData()) return mutableListOf()

        val bases = LinkedHashSet<Triple<Int, Int, Int>>()
        bases.addAll(searchPlaceBase())

        val players = EntityTracker.getPlayers(range.value)
        for (target in players) {
            val (px, py, pz) = predictedPos(target)
            val tx = floor(px).toInt()
            val tz = floor(pz).toInt()
            val groundY = floor(py).toInt() - 1

            for (dy in -1..1) {
                val ty = groundY + dy
                for (dx in -2..2) {
                    for (dz in -2..2) {
                        if (dx == 0 && dz == 0) continue
                        val bx = tx + dx
                        val bz = tz + dz
                        val id = WorldBlockTracker.getBlockIdentifier(bx, ty, bz) ?: continue
                        if (id != "minecraft:obsidian" && id != "minecraft:bedrock") continue
                        val above = WorldBlockTracker.getBlockIdentifier(bx, ty + 1, bz)
                        if (above != null && above !in NON_SOLID) continue
                        bases.add(Triple(bx, ty, bz))
                    }
                }
            }
        }

        if (bases.isEmpty()) return mutableListOf()

        val scored = bases.mapNotNull { pos ->
            val cx = pos.first + 0.5f
            val cy = pos.second + 2f
            val cz = pos.third + 0.5f
            val dmg = simulateExplosionDamage(cx, cy, cz)
            val eff = if (!isSelfSafe(dmg)) -1f else dmg.mostDamage
            if (eff >= 0f || suicide.value) Pair(pos, eff) else null
        }

        val topPositions = scored
            .sortedByDescending { it.second }
            .take(placeCount.value)
            .map { it.first }

        val finalPositions = topPositions.ifEmpty { bases.take(placeCount.value) }
        return finalPositions.toMutableList()
    }

    private fun simulateExplosionDamage(cx: Float, cy: Float, cz: Float): ExplosionResult {
        val diameter = EXPLOSION_SIZE * 2f
        var selfDamage = 0f
        var mostDamage = 0f

        val selfDist = MathUtil.dist3(cx, cy, cz, EntityTracker.selfX, EntityTracker.selfY + 0.9f, EntityTracker.selfZ)
        if (selfDist <= diameter) {
            val exposure = exposureTo(cx, cy, cz, EntityTracker.selfX, EntityTracker.selfY, EntityTracker.selfZ)
            selfDamage = explosionDamage(selfDist, diameter, exposure)
        }

        for (p in EntityTracker.getPlayers(diameter)) {
            if (p.runtimeId == EntityTracker.selfRuntimeId) continue
            val dist = MathUtil.dist3(cx, cy, cz, p.x, p.y + 0.9f, p.z)
            if (dist > diameter) continue
            val exposure = exposureTo(cx, cy, cz, p.x, p.y, p.z)
            val dmg = explosionDamage(dist, diameter, exposure)
            if (dmg > mostDamage) mostDamage = dmg
        }

        return ExplosionResult(mostDamage, selfDamage)
    }

    private fun explosionDamage(distance: Float, diameter: Float, exposure: Float): Float {
        if (distance > diameter) return 0f
        val impact = (1f - distance / diameter) * exposure
        return (impact * impact + impact) / 2f * 7f * diameter + 1f
    }

    private fun exposureTo(cx: Float, cy: Float, cz: Float, tx: Float, ty: Float, tz: Float): Float {
        if (!WorldBlockTracker.hasAnyTerrainData()) return 1f
        val samples = arrayOf(
            Triple(tx, ty + 0.1f, tz),
            Triple(tx, ty + 0.9f, tz),
            Triple(tx, ty + 1.6f, tz),
            Triple(tx + 0.3f, ty + 0.9f, tz),
            Triple(tx - 0.3f, ty + 0.9f, tz)
        )
        var clear = 0
        for ((sx, sy, sz) in samples) {
            if (!isRayBlocked(cx, cy, cz, sx, sy, sz)) clear++
        }
        return clear.toFloat() / samples.size
    }

    private fun isRayBlocked(x0: Float, y0: Float, z0: Float, x1: Float, y1: Float, z1: Float): Boolean {
        val dist = MathUtil.dist3(x0, y0, z0, x1, y1, z1)
        if (dist < 0.01f) return false
        val steps = (dist * 2f).toInt().coerceIn(1, 40)
        for (i in 1 until steps) {
            val t = i.toFloat() / steps
            val bx = floor(x0 + (x1 - x0) * t).toInt()
            val by = floor(y0 + (y1 - y0) * t).toInt()
            val bz = floor(z0 + (z1 - z0) * t).toInt()
            val id = WorldBlockTracker.getBlockIdentifier(bx, by, bz) ?: continue
            if (id !in NON_SOLID) return true
        }
        return false
    }

    private fun searchPlaceBase(): List<Triple<Int, Int, Int>> {
        if (!WorldBlockTracker.hasAnyTerrainData()) return emptyList()
        val r  = floor(range.value).toInt()
        val vr = BASE_VERTICAL_RANGE
        val cx = floor(EntityTracker.selfX).toInt()
        val cy = floor(EntityTracker.selfY).toInt()
        val cz = floor(EntityTracker.selfZ).toInt()
        val bases = ArrayList<Triple<Int, Int, Int>>()
        for (x in cx - r..cx + r) {
            for (y in cy - vr..cy + vr) {
                for (z in cz - r..cz + r) {
                    val id = WorldBlockTracker.getBlockIdentifier(x, y, z) ?: continue
                    if (id != "minecraft:obsidian" && id != "minecraft:bedrock") continue
                    val above = WorldBlockTracker.getBlockIdentifier(x, y + 1, z)
                    if (above != null && above !in NON_SOLID) continue
                    bases.add(Triple(x, y, z))
                }
            }
        }
        return bases
    }

    private fun explodeCrystal(session: NoxNoRelaySession, runtimeId: Long) {
        CombatUtil.sendSwing(session)
        CombatUtil.sendAttack(session, runtimeId)
        pendingExplodes.add(PendingExplode(runtimeId, System.currentTimeMillis(), 0))
    }
}
