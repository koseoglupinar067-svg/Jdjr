package com.noxnoclient.module.movement

import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.events.PacketEvent
import com.noxnoclient.events.PacketEventBus
import com.noxnoclient.module.BaseModule
import com.noxnoclient.module.ModuleCategory
import com.noxnoclient.utils.CombatUtil
import kotlinx.coroutines.Job
import org.cloudburstmc.math.vector.Vector3f
import org.cloudburstmc.protocol.bedrock.data.PlayerAuthInputData
import org.cloudburstmc.protocol.bedrock.packet.MovePlayerPacket
import org.cloudburstmc.protocol.bedrock.packet.PlayerAuthInputPacket
import kotlin.math.cos
import kotlin.math.sin

/**
 * FreeCam — kamerayı oyuncudan bağımsız hareket ettirir.
 * Sunucuya gerçek pozisyon yerine kameranın sanal pozisyonu gönderilir.
 * İstemciye sunucudan gelen teleport/hareket paketleri bloklanır.
 */
class FreeCam : BaseModule(
    name        = "FreeCam",
    category    = ModuleCategory.MOVEMENT,
    description = "Kamerayı oyuncudan bağımsız hareket ettirmenizi sağlar"
) {
    private val speed = float("Speed", 0.5f, 0.05f, 5.0f)

    @Volatile var camX = 0f
    @Volatile var camY = 0f
    @Volatile var camZ = 0f
    @Volatile private var initialized = false

    private var tickJob: Job? = null

    override fun onEnable() {
        super.onEnable()
        camX = EntityTracker.selfX
        camY = EntityTracker.selfY
        camZ = EntityTracker.selfZ
        initialized = true
    }

    override fun onDisable() {
        tickJob?.cancel(); tickJob = null
        initialized = false
        // Restore real position
        val session = PacketEventBus.currentSession ?: return
        CombatUtil.sendMove(
            session,
            EntityTracker.selfX, EntityTracker.selfY, EntityTracker.selfZ,
            EntityTracker.selfYaw, EntityTracker.selfPitch,
            onGround = true, teleport = false, mirrorToClient = true
        )
        super.onDisable()
    }

    override fun onPacket(event: PacketEvent) {
        if (!isEnabled || !initialized) return

        when (event.direction) {
            PacketEvent.Direction.CLIENT_TO_SERVER -> {
                val pkt = event.packet as? PlayerAuthInputPacket ?: return
                val yaw   = Math.toRadians(EntityTracker.selfYaw.toDouble())
                val pitch = Math.toRadians(EntityTracker.selfPitch.toDouble())
                val s = speed.value
                val forward = pkt.inputData.contains(PlayerAuthInputData.UP)
                val back    = pkt.inputData.contains(PlayerAuthInputData.DOWN)
                val left    = pkt.inputData.contains(PlayerAuthInputData.LEFT)
                val right   = pkt.inputData.contains(PlayerAuthInputData.RIGHT)
                val jump    = pkt.inputData.contains(PlayerAuthInputData.JUMPING)
                val sneak   = pkt.inputData.contains(PlayerAuthInputData.SNEAKING)

                if (forward) { camX -= (sin(yaw) * s).toFloat(); camZ += (cos(yaw) * s).toFloat() }
                if (back)    { camX += (sin(yaw) * s).toFloat(); camZ -= (cos(yaw) * s).toFloat() }
                if (left)    { camX -= (cos(yaw) * s).toFloat(); camZ -= (sin(yaw) * s).toFloat() }
                if (right)   { camX += (cos(yaw) * s).toFloat(); camZ += (sin(yaw) * s).toFloat() }
                if (jump)    camY += s
                if (sneak)   camY -= s

                val newPkt = PlayerAuthInputPacket().apply {
                    position           = Vector3f.from(camX, camY, camZ)
                    rotation           = pkt.rotation
                    yHeadRotation      = pkt.yHeadRotation
                    inputData          = pkt.inputData
                    inputMode          = pkt.inputMode
                    playMode           = pkt.playMode
                    interactRotation   = pkt.interactRotation
                    tick               = pkt.tick
                    delta              = pkt.delta
                    motionPredictionHints = pkt.motionPredictionHints
                }
                event.cancelAndReplace(newPkt)
            }
            PacketEvent.Direction.SERVER_TO_CLIENT -> {
                // Block server position corrections
                if (event.packet is MovePlayerPacket) {
                    val mp = event.packet as MovePlayerPacket
                    if (mp.runtimeEntityId == EntityTracker.selfRuntimeId &&
                        mp.mode == MovePlayerPacket.Mode.TELEPORT) {
                        event.cancel()
                    }
                }
            }
        }
    }
}
