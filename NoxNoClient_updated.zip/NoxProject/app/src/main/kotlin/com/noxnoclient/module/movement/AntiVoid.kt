package com.noxnoclient.module.movement

import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.events.PacketEvent
import com.noxnoclient.events.PacketEventBus
import com.noxnoclient.module.BaseModule
import com.noxnoclient.module.ModuleCategory
import com.noxnoclient.utils.CombatUtil
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/** AntiVoid — teleports the player back if they fall below a threshold. */
class AntiVoid : BaseModule(
    name        = "AntiVoid",
    category    = ModuleCategory.MOVEMENT,
    description = "Teleports you back when falling into the void"
) {
    private val threshold = float("Void Y Threshold", -40f, -200f, 0f)
    private val shortcut  = bool ("Shortcut", false)

    @Volatile private var safeX = 0f
    @Volatile private var safeY = 0f
    @Volatile private var safeZ = 0f
    @Volatile private var hasSafe = false
    @Volatile private var cooldownMs = 0L

    private var antiVoidJob: Job? = null

    override fun onEnable() {
        super.onEnable()
        hasSafe = false
        antiVoidJob = launchTickLoop(50L) { checkVoid() }
    }

    override fun onDisable() {
        antiVoidJob?.cancel(); antiVoidJob = null
        super.onDisable()
    }

    override fun onPacket(event: PacketEvent) {}

    private fun checkVoid() {
        val y = EntityTracker.selfY
        val x = EntityTracker.selfX
        val z = EntityTracker.selfZ
        val now = System.currentTimeMillis()

        if (y > threshold.value && y > -60f) {
            // Update safe position when above threshold and on solid ground
            if (EntityTracker.selfOnGround) {
                safeX = x; safeY = y; safeZ = z; hasSafe = true
            }
            return
        }

        if (now - cooldownMs < 3000L) return
        cooldownMs = now

        if (!hasSafe) return
        val session = PacketEventBus.currentSession ?: return

        // Teleport back to last safe position
        CombatUtil.sendMove(
            session, safeX, safeY, safeZ,
            EntityTracker.selfYaw, EntityTracker.selfPitch,
            onGround = true, teleport = true, mirrorToClient = true
        )
    }
}
