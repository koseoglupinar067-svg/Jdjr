package com.noxnoclient.module.visual

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import com.noxnoclient.events.PacketEvent
import com.noxnoclient.module.BaseModule
import com.noxnoclient.module.ModuleCategory
import com.noxnoclient.utils.HudAnchor
import com.noxnoclient.utils.HudPosition
import org.cloudburstmc.protocol.bedrock.data.inventory.transaction.InventoryTransactionType
import org.cloudburstmc.protocol.bedrock.packet.InventoryTransactionPacket
import java.util.ArrayDeque

class CpsHud : BaseModule(
    name        = "CpsHud",
    category    = ModuleCategory.VISUAL,
    description = "Shows your real clicks-per-second"
) {
    private val anchor   = enum ("Anchor",   HudAnchor.TopRight)
    private val offsetX  = float("Offset X", 12f, 0f, 800f)
    private val offsetY  = float("Offset Y", 46f, 0f, 800f)
    private val shortcut = bool ("Shortcut", false)

    private val clickTimes = ArrayDeque<Long>()

    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 26f
        typeface = android.graphics.Typeface.DEFAULT_BOLD
        setShadowLayer(3f, 1f, 1f, Color.BLACK)
    }

    override fun onEnable() {
        super.onEnable()
        clickTimes.clear()
    }

    override fun onPacket(event: PacketEvent) {
        if (!isEnabled) return
        if (event.direction != PacketEvent.Direction.CLIENT_TO_SERVER) return
        val pkt = event.packet as? InventoryTransactionPacket ?: return
        if (pkt.transactionType != InventoryTransactionType.ITEM_USE_ON_ENTITY) return
        synchronized(clickTimes) { clickTimes.addLast(System.currentTimeMillis()) }
    }

    private fun currentCps(): Int {
        val now = System.currentTimeMillis()
        synchronized(clickTimes) {
            while (clickTimes.isNotEmpty() && now - clickTimes.peekFirst() > 1000L) clickTimes.pollFirst()
            return clickTimes.size
        }
    }

    fun render(canvas: Canvas, screenW: Int, screenH: Int) {
        if (!isEnabled) return
        val text = "${currentCps()} CPS"
        val w = textPaint.measureText(text)
        val h = textPaint.textSize
        val (px, py) = HudPosition.resolve(anchor.value, offsetX.value, offsetY.value, w, h, screenW, screenH)
        canvas.drawText(text, px, py + h, textPaint)
    }
}
