package com.noxnoclient.module.misc

import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.core.relay.NoxNoRelaySession
import com.noxnoclient.events.PacketEvent
import com.noxnoclient.module.BaseModule
import com.noxnoclient.module.ModuleCategory
import com.noxnoclient.module.social.isFriendEntity
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.cloudburstmc.protocol.bedrock.packet.EntityEventPacket
import org.cloudburstmc.protocol.bedrock.packet.TextPacket
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentLinkedQueue
import kotlin.random.Random

class ChatSpammer : BaseModule(
    name        = "ChatSpammer",
    category    = ModuleCategory.MISC,
    description = "Drops a PVP message into chat on nearby kill/logout events"
) {
    companion object {
        private const val QUEUE_DELAY_MS = 700L
        private const val MAX_QUEUE_SIZE = 20
        private const val POLL_INTERVAL_MS = 500L
        private const val KILL_RANGE   = 8f
        private const val LOGOUT_RANGE = 12f
        private const val DEBOUNCE_MS  = 1000L

        private val JUNK_CHARS = "abcdefghjklmnopqrstuvwxyz0123456789"
        private val JUNK_RANGE = 10..18
        private const val INTERNAL_SOURCE = InternalChat.MARKER
    }

    private val announceKills   = bool  ("Announce Kills",   true)
    private val announceLogouts = bool  ("Announce Logouts", false)
    private val killMessage     = string("Kill Message",   ">(@here {name} ez clapped) | {junk} | NoxNo")
    private val logoutMessage   = string("Logout Message", ">({name} logged out, gg) | {junk} | NoxNo")
    private val shortcut        = bool  ("Shortcut", false)

    private val messageQueue = ConcurrentLinkedQueue<String>()
    private val lastEventMs  = ConcurrentHashMap<Long, Long>()
    private val knownNearby  = ConcurrentHashMap<Long, String>()

    private var flushJob: Job? = null
    private var pollJob: Job? = null
    @Volatile private var activeSession: NoxNoRelaySession? = null

    override fun onEnable() {
        super.onEnable()
        messageQueue.clear()
        lastEventMs.clear()
        knownNearby.clear()

        flushJob = scope.launch {
            while (currentCoroutineContext().isActive) {
                flushQueue()
                delay(QUEUE_DELAY_MS)
            }
        }
        pollJob = scope.launch {
            while (currentCoroutineContext().isActive) {
                pollLogouts()
                delay(POLL_INTERVAL_MS)
            }
        }
    }

    override fun onDisable() {
        flushJob?.cancel(); flushJob = null
        pollJob?.cancel(); pollJob = null
        messageQueue.clear()
        lastEventMs.clear()
        knownNearby.clear()
        super.onDisable()
    }

    override fun onPacket(event: PacketEvent) {
        if (!isEnabled) return
        activeSession = event.session

        if (event.direction != PacketEvent.Direction.SERVER_TO_CLIENT) return
        if (!announceKills.value) return

        val p = event.packet
        if (p !is EntityEventPacket) return
        if (p.runtimeEntityId == EntityTracker.selfRuntimeId) return

        val typeStr = runCatching { p.type?.toString()?.uppercase() ?: "" }.getOrElse { "" }
        if (!typeStr.contains("DEATH")) return

        val entity = EntityTracker.getById(p.runtimeEntityId) ?: return
        if (!entity.isPlayer || entity.isFriendEntity) return
        if (EntityTracker.distanceTo(entity) > KILL_RANGE) return
        if (!shouldFire(entity.runtimeId)) return

        val name = entity.name.takeIf { it.isNotEmpty() } ?: "unknown"
        enqueue(killMessage.value.replace("{name}", name).replace("{junk}", randomJunk()))
    }

    private fun pollLogouts() {
        if (!isEnabled) return

        // Refresh/track anyone currently within range.
        EntityTracker.getPlayers(LOGOUT_RANGE).forEach { e ->
            if (e.runtimeId == EntityTracker.selfRuntimeId) return@forEach
            if (e.isFriendEntity) return@forEach
            knownNearby[e.runtimeId] = e.name.takeIf { it.isNotEmpty() } ?: "unknown"
        }

        // A real logout is when the entity is gone from EntityTracker entirely
        // (server sent RemoveEntityPacket) - NOT just outside LOGOUT_RANGE, which
        // happens constantly from normal movement and doesn't mean they disconnected.
        val iterator = knownNearby.entries.iterator()
        while (iterator.hasNext()) {
            val (runtimeId, name) = iterator.next()
            if (EntityTracker.getById(runtimeId) != null) continue // still connected, just out of range

            if (announceLogouts.value && shouldFire(runtimeId)) {
                enqueue(logoutMessage.value.replace("{name}", name).replace("{junk}", randomJunk()))
            }
            iterator.remove()
        }
    }

    private fun shouldFire(runtimeId: Long): Boolean {
        val now = System.currentTimeMillis()
        val last = lastEventMs[runtimeId]
        if (last != null && now - last < DEBOUNCE_MS) return false
        lastEventMs[runtimeId] = now
        return true
    }

    private fun flushQueue() {
        val session = activeSession ?: return
        if (!session.isServerReady) return
        val msg = messageQueue.poll() ?: return
        runCatching { session.sendToServer(buildTextPacket(msg)) }
    }

    private fun enqueue(message: String) {
        if (messageQueue.size >= MAX_QUEUE_SIZE) messageQueue.poll()
        messageQueue.offer(message)
    }

    private fun buildTextPacket(
        message: String,
        sourceName: String = INTERNAL_SOURCE,
        xuid: String = "",
        platformChatId: String = ""
    ): TextPacket = TextPacket().apply {
        type               = TextPacket.Type.CHAT
        isNeedsTranslation = false
        this.sourceName    = sourceName
        this.xuid          = xuid
        this.platformChatId = platformChatId
        setMessage(message)
        setFilteredMessage("")
    }

    private fun randomJunk(): String {
        val len = Random.nextInt(JUNK_RANGE.first, JUNK_RANGE.last + 1)
        return buildString(len) { repeat(len) { append(JUNK_CHARS[Random.nextInt(JUNK_CHARS.length)]) } }
    }
}
