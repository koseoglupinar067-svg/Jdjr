package com.noxnoclient.module.movement

import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.events.PacketEvent
import com.noxnoclient.module.BaseModule
import com.noxnoclient.module.ModuleCategory
import org.cloudburstmc.protocol.bedrock.data.PlayerAuthInputData
import org.cloudburstmc.protocol.bedrock.packet.PlayerAuthInputPacket
import org.cloudburstmc.math.vector.Vector3f

/** HighJump — multiplies the player's jump velocity. */
class HighJump : BaseModule(
    name        = "HighJump",
    category    = ModuleCategory.MOVEMENT,
    description = "Multiplies jump height by a configurable factor"
) {
    private val multiplier = float("Multiplier", 2.0f, 1.0f, 10.0f)
    private val shortcut   = bool ("Shortcut", false)

    @Volatile private var wasOnGround = true
    @Volatile private var injected    = false

    override fun onPacket(event: PacketEvent) {
        if (!isEnabled) return
        if (event.direction != PacketEvent.Direction.CLIENT_TO_SERVER) return
        val pkt = event.packet as? PlayerAuthInputPacket ?: return

        val nowOnGround = EntityTracker.selfOnGround
        val jumping = pkt.inputData.contains(PlayerAuthInputData.JUMPING) ||
                      pkt.inputData.contains(PlayerAuthInputData.JUMP_DOWN)

        if (jumping && wasOnGround && !injected) {
            injected = true
            // Replace the Y component of the move with the boosted one
            val boostedY = pkt.position.y + 0.42f * (multiplier.value - 1f)
            val newPacket = PlayerAuthInputPacket().apply {
                position           = Vector3f.from(pkt.position.x, boostedY, pkt.position.z)
                rotation           = pkt.rotation
                yHeadRotation      = pkt.yHeadRotation
                inputData          = pkt.inputData
                inputMode          = pkt.inputMode
                playMode           = pkt.playMode
                interactRotation   = pkt.interactRotation
                tick               = pkt.tick
                delta              = pkt.delta
                motionPredictionHints = pkt.motionPredictionHints
            }
            event.cancelAndReplace(newPacket)
        } else if (!jumping) {
            injected = false
        }

        wasOnGround = nowOnGround
    }
}
