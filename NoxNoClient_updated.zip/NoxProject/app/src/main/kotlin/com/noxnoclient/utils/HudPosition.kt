package com.noxnoclient.utils

enum class HudAnchor { TopLeft, TopRight, BottomLeft, BottomRight }

object HudPosition {
    fun resolve(
        anchor: HudAnchor,
        offsetX: Float,
        offsetY: Float,
        elementW: Float,
        elementH: Float,
        screenW: Int,
        screenH: Int
    ): Pair<Float, Float> = when (anchor) {
        HudAnchor.TopLeft     -> offsetX to offsetY
        HudAnchor.TopRight    -> (screenW - elementW - offsetX) to offsetY
        HudAnchor.BottomLeft  -> offsetX to (screenH - elementH - offsetY)
        HudAnchor.BottomRight -> (screenW - elementW - offsetX) to (screenH - elementH - offsetY)
    }
}
