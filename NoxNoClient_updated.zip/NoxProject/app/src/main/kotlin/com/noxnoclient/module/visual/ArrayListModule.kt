package com.noxnoclient.module.visual

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import com.noxnoclient.module.BaseModule
import com.noxnoclient.module.ModuleCategory
import com.noxnoclient.module.ModuleManager
import com.noxnoclient.utils.PulseUtil
import kotlin.math.min

class ArrayListModule : BaseModule(
    name = "ArrayList",
    category = ModuleCategory.VISUAL,
    description = "Shows active modules as a vivid rainbow-animated list"
) {
    enum class Corner { TOP_RIGHT, TOP_LEFT, BOTTOM_RIGHT, BOTTOM_LEFT }

    private val corner        = enum("Corner", Corner.TOP_RIGHT)
    private val margin        = float("Margin", 16f, 0f, 64f)
    private val bgOpacity     = float("BG Opacity", 0.58f, 0f, 1f)
    private val pulse         = bool("Pulse", false)
    private val shortcut      = bool("Shortcut", false)

    private val activationTimestamps = HashMap<String, Long>()
    private val slideProgress        = HashMap<String, Float>()
    private var lastFrameTimeNs      = 0L
    private var rainbowScrollPx      = 0f

    companion object {
        private val RAINBOW_STOPS = intArrayOf(
            Color.rgb(255, 0, 0), Color.rgb(255, 140, 0), Color.rgb(255, 235, 0),
            Color.rgb(0, 230, 90), Color.rgb(0, 210, 210), Color.rgb(40, 90, 255),
            Color.rgb(180, 0, 255), Color.rgb(255, 0, 130), Color.rgb(255, 0, 0)
        )
        private const val RAINBOW_SPAN_PX      = 240f
        private const val RAINBOW_SCROLL_SPEED = 160f
        private const val RAINBOW_ITEM_SKEW_PX = 34f
    }

    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 27f
        typeface = Typeface.create(Typeface.DEFAULT_BOLD, Typeface.BOLD)
        setShadowLayer(4f, 0f, 0f, Color.argb(200, 0, 0, 0))
    }
    private val bgPaint     = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val accentPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2.4f }
    private val reusableRect = RectF()

    private val rainbowShader = LinearGradient(0f, 0f, RAINBOW_SPAN_PX, 0f, RAINBOW_STOPS, null, Shader.TileMode.MIRROR)
    private val rainbowMatrix = Matrix()

    private var cachedVersion   = -1
    private var cachedSorted: List<BaseModule> = emptyList()
    private var cachedActiveNames: Set<String> = emptySet()

    private val textWidthCache     = HashMap<String, Float>()
    private val categoryCache      = HashMap<String, ModuleCategory>()
    private val reusableFadingOut  = ArrayList<String>()
    private val reusableToRemove   = ArrayList<String>()
    private val reusableDrawNames  = ArrayList<String>()
    private val reusableDrawCats   = ArrayList<ModuleCategory>()

    private val fm    = textPaint.fontMetrics
    private val lineH = (fm.descent - fm.ascent) + 12f

    override fun onEnable() {
        super.onEnable()
        activationTimestamps.clear(); slideProgress.clear()
        lastFrameTimeNs = 0L; rainbowScrollPx = 0f
    }

    private fun trackActivations() {
        val now = System.currentTimeMillis()
        for (m in ModuleManager.modules) {
            if (m === this) continue
            if (m.name !in categoryCache) categoryCache[m.name] = m.category
            if (m.isEnabled) activationTimestamps.putIfAbsent(m.name, now)
            else activationTimestamps.remove(m.name)
        }
    }

    private fun textWidth(name: String) = textWidthCache.getOrPut(name) { textPaint.measureText(name) }

    private fun rainbowShaderFor(index: Int): LinearGradient {
        rainbowMatrix.setTranslate(-(rainbowScrollPx + index * RAINBOW_ITEM_SKEW_PX), 0f)
        rainbowShader.setLocalMatrix(rainbowMatrix)
        return rainbowShader
    }

    fun render(canvas: Canvas, screenW: Int, screenH: Int) {
        if (!isEnabled) return
        trackActivations()

        val version = ModuleManager.version.value
        if (version != cachedVersion) {
            cachedVersion = version
            val active = ModuleManager.modules.filter { it.isEnabled && it !== this }
            cachedSorted      = active.sortedBy { it.name }
            cachedActiveNames = cachedSorted.mapTo(HashSet()) { it.name }
        }

        val nowNs = System.nanoTime()
        val dt    = if (lastFrameTimeNs == 0L) 0.016f else ((nowNs - lastFrameTimeNs) / 1_000_000_000f).coerceIn(0f, 0.1f)
        lastFrameTimeNs  = nowNs
        val step         = (0.8f * dt * 60f).coerceIn(0f, 1f)
        rainbowScrollPx  = (rainbowScrollPx + dt * RAINBOW_SCROLL_SPEED).mod(RAINBOW_SPAN_PX)

        for (m in cachedSorted) { val c = slideProgress[m.name] ?: 0f; slideProgress[m.name] = min(1f, c + step) }

        reusableToRemove.clear()
        for (key in slideProgress.keys) {
            if (key !in cachedActiveNames) {
                val next = ((slideProgress[key] ?: 0f) - step).coerceAtLeast(0f)
                if (next <= 0f) reusableToRemove.add(key) else slideProgress[key] = next
            }
        }
        reusableToRemove.forEach { slideProgress.remove(it) }
        if (slideProgress.isEmpty()) return

        reusableFadingOut.clear()
        slideProgress.keys.filterTo(reusableFadingOut) { it !in cachedActiveNames }

        reusableDrawNames.clear(); reusableDrawCats.clear()
        cachedSorted.forEach { reusableDrawNames.add(it.name); reusableDrawCats.add(it.category) }
        reusableFadingOut.forEach { n -> categoryCache[n]?.let { reusableDrawNames.add(n); reusableDrawCats.add(it) } }

        val m       = margin.value
        val isRight  = corner.value == Corner.TOP_RIGHT || corner.value == Corner.BOTTOM_RIGHT
        val isBottom = corner.value == Corner.BOTTOM_RIGHT || corner.value == Corner.BOTTOM_LEFT

        val totalItems = reusableDrawNames.size
        val totalH     = totalItems * lineH

        for (i in reusableDrawNames.indices) {
            val name     = reusableDrawNames[i]
            val progress = slideProgress[name] ?: continue
            val textW    = textWidth(name)
            val accentW  = 5f
            val boxW     = textW + 20f + accentW

            val slideDir   = if (isRight) 1f else -1f
            val slideOff   = (1f - progress) * (boxW + 24f) * slideDir
            val alpha      = (255 * progress).toInt().coerceIn(0, 255)
            val bgAlpha    = (255f * bgOpacity.value * progress).toInt().coerceIn(0, 255)

            // rowIndex from the appropriate edge
            val rowIndex  = if (isBottom) (totalItems - 1 - i) else i
            val rowY      = if (isBottom) screenH - m - rowIndex * lineH - lineH
                            else m + rowIndex * lineH

            val boxLeft   = if (isRight) screenW - m - boxW + slideOff else m - slideOff
            val boxRight  = boxLeft + boxW
            val boxTop    = rowY
            val boxBottom = rowY + lineH - 6f

            val shader = if (pulse.value) null else rainbowShaderFor(i)
            val pulseColor = if (pulse.value) PulseUtil.color() else 0

            reusableRect.set(boxLeft, boxTop, boxRight, boxBottom)
            bgPaint.color = Color.argb(bgAlpha, 8, 8, 12)
            canvas.drawRoundRect(reusableRect, 7f, 7f, bgPaint)

            borderPaint.shader = shader; borderPaint.alpha = alpha
            if (pulse.value) borderPaint.color = pulseColor
            canvas.drawRoundRect(reusableRect, 7f, 7f, borderPaint)

            val axL = if (isRight) boxLeft else boxRight - accentW
            val axR = if (isRight) boxLeft + accentW else boxRight
            reusableRect.set(axL, boxTop, axR, boxBottom)
            accentPaint.shader = shader; accentPaint.alpha = alpha
            if (pulse.value) accentPaint.color = pulseColor
            canvas.drawRoundRect(reusableRect, 2.2f, 2.2f, accentPaint)

            textPaint.shader = shader; textPaint.alpha = alpha
            if (pulse.value) textPaint.color = pulseColor
            textPaint.textAlign = if (isRight) Paint.Align.RIGHT else Paint.Align.LEFT
            val textX = if (isRight) boxRight - 13f else boxLeft + accentW + 10f
            canvas.drawText(name, textX, boxTop + 5f - fm.ascent, textPaint)
        }
    }
}
