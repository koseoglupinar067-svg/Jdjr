package com.noxnoclient.module.player

import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.events.PacketEvent
import com.noxnoclient.module.BaseModule
import com.noxnoclient.module.ModuleCategory
import org.cloudburstmc.protocol.bedrock.packet.MobEffectPacket

class AntiBlind : BaseModule(
    name        = "AntiBlind",
    category    = ModuleCategory.PLAYER,
    description = "Blocks the Blindness effect from being applied to you"
) {
    companion object {
        private const val EFFECT_BLINDNESS = 15
    }

    private val shortcut = bool("Shortcut", false)

    override fun onPacket(event: PacketEvent) {
        if (!isEnabled) return
        if (event.direction != PacketEvent.Direction.SERVER_TO_CLIENT) return
        val pkt = event.packet as? MobEffectPacket ?: return
        if (pkt.runtimeEntityId != EntityTracker.selfRuntimeId) return
        if (pkt.effectId != EFFECT_BLINDNESS) return
        if (pkt.event == MobEffectPacket.Event.ADD || pkt.event == MobEffectPacket.Event.MODIFY) {
            event.cancel()
        }
    }
}
