package com.noxnoclient.module.misc

import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.core.relay.NoxNoRelaySession
import com.noxnoclient.events.PacketEvent
import com.noxnoclient.events.PacketEventBus
import com.noxnoclient.module.BaseModule
import com.noxnoclient.module.ModuleCategory
import com.noxnoclient.utils.CombatUtil
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.cos
import kotlin.math.sin

/**
 * AntiAFK — AFK atmamak için periyodik hareket paketi gönderir.
 */
class AntiAFK : BaseModule(
    name        = "AntiAFK",
    category    = ModuleCategory.MISC,
    description = "AFK atılmamak için periyodik hareket paketi gönderir"
) {
    private val intervalSec = float("Interval (s)", 10f, 1f, 60f)
    private val rotate      = bool ("Rotate",       true)
    private val swing       = bool ("Swing Arm",    false)

    @Volatile private var activeSession: NoxNoRelaySession? = null
    @Volatile private var tickCount = 0
    private var afkJob: Job? = null

    override fun onEnable() {
        super.onEnable()
        tickCount = 0
        afkJob = scope.launch {
            while (currentCoroutineContext().isActive) {
                delay((intervalSec.value * 1000f).toLong().coerceAtLeast(2000L))
                val session = activeSession ?: PacketEventBus.currentSession ?: continue
                if (!session.isServerReady) continue
                performAction(session)
            }
        }
    }

    override fun onDisable() {
        afkJob?.cancel(); afkJob = null
        super.onDisable()
    }

    override fun onPacket(event: PacketEvent) {
        if (!isEnabled) return
        activeSession = event.session
    }

    private fun performAction(session: NoxNoRelaySession) {
        tickCount++
        val x = EntityTracker.selfX
        val y = EntityTracker.selfY
        val z = EntityTracker.selfZ
        val baseYaw = EntityTracker.selfYaw
        val pitch   = EntityTracker.selfPitch

        if (rotate.value) {
            // Küçük açı sallama
            val deltaYaw = if (tickCount % 2 == 0) 5f else -5f
            val newYaw = (baseYaw + deltaYaw) % 360f
            runCatching {
                CombatUtil.sendMove(session, x, y, z, newYaw, pitch, onGround = true, teleport = false, mirrorToClient = false)
            }
        } else {
            runCatching {
                CombatUtil.sendMove(session, x, y, z, baseYaw, pitch, onGround = true, teleport = false, mirrorToClient = false)
            }
        }

        if (swing.value) {
            runCatching { CombatUtil.sendSwing(session) }
        }
    }
}
