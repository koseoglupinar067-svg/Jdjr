package com.noxnoclient.module.combat

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.module.BaseModule
import com.noxnoclient.module.ModuleCategory
import com.noxnoclient.module.social.isFriendEntity
import com.noxnoclient.utils.CombatUtil
import com.noxnoclient.utils.MathUtil
import com.noxnoclient.utils.UiUtil
import com.noxnoclient.utils.WorldBlockTracker
import org.cloudburstmc.math.vector.Vector3i
import kotlin.math.floor
import kotlin.math.roundToInt

class AnchorHelper : BaseModule(
    name        = "AnchorHelper",
    category    = ModuleCategory.COMBAT,
    description = "Highlights the best respawn-anchor spot(s) near your target(s) without placing anything"
) {
    companion object {
        private const val ANCHOR_EXPLOSION_POWER = 5f
        private const val SEARCH_RADIUS_XZ = 2

        private val NON_SOLID = setOf(
            "minecraft:air", "minecraft:water", "minecraft:flowing_water",
            "minecraft:lava", "minecraft:flowing_lava",
            "minecraft:void_air", "minecraft:cave_air"
        )
    }

    private val targetRange   = int  ("Target Range",  16, 2, 16)
    private val friendSkip    = bool ("Friend Skip",   true)
    private val minDamage     = float("Min Damage",    0f, 0f, 40f)
    private val placeRange    = float("Place Range",   16f, 2f, 16f)
    private val updateMs      = int  ("Update Rate (ms)", 100, 30, 500)
    private val boxColor      = enum ("Box Color", HelperColor.GOLD)
    private val showTopN      = int  ("Show Top N", 1, 1, 3)
    private val multiTarget   = bool ("Multi Target", false)
    private val avoidSuicide  = bool ("Avoid Suicide", true)
    private val lethalOnly    = bool ("Lethal Only", false)
    private val showSelfDamage = bool("Show Self Damage", true)
    private val shortcut      = bool ("Shortcut", false)

    enum class HelperColor { GOLD, RED, CYAN, GREEN }

    private val boxPaint  = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2.5f }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val dashEffect = DashPathEffect(floatArrayOf(10f, 8f), 0f)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL; color = Color.WHITE; textSize = 24f
        typeface = Typeface.create(Typeface.DEFAULT_BOLD, Typeface.BOLD)
        textAlign = Paint.Align.CENTER; setShadowLayer(3f, 1f, 1f, Color.BLACK)
    }
    private val reusableRect = RectF()

    private data class Candidate(
        val pos: Vector3i,
        val damage: Float,
        val selfDamage: Float,
        val inRange: Boolean
    )

    @Volatile private var candidates: List<Candidate> = emptyList()
    @Volatile private var lastScanMs = 0L

    private fun colorArgb(): Int = when (boxColor.value) {
        HelperColor.GOLD -> Color.argb(255, 255, 200, 40)
        HelperColor.RED  -> Color.argb(255, 255, 60, 60)
        HelperColor.CYAN -> Color.argb(255, 60, 220, 255)
        HelperColor.GREEN -> Color.argb(255, 80, 255, 100)
    }

    private fun targets(): List<EntityTracker.TrackedEntity> {
        if (EntityTracker.selfRuntimeId <= 0L) return emptyList()
        val selfX = EntityTracker.selfX; val selfY = EntityTracker.selfY; val selfZ = EntityTracker.selfZ
        val all = EntityTracker.getPlayers(targetRange.value.toFloat())
            .asSequence()
            .filter { it.runtimeId != EntityTracker.selfRuntimeId }
            .filter { !friendSkip.value || !it.isFriendEntity }
        return if (multiTarget.value) {
            all.sortedBy { MathUtil.dist3sq(it.x, it.y, it.z, selfX, selfY, selfZ) }.toList()
        } else {
            listOfNotNull(all.minByOrNull { MathUtil.dist3sq(it.x, it.y, it.z, selfX, selfY, selfZ) })
        }
    }

    private fun spotsNear(target: EntityTracker.TrackedEntity): List<Candidate> {
        val targetX = floor(target.x).toInt()
        val targetY = floor(target.y).toInt()
        val targetZ = floor(target.z).toInt()

        val found = ArrayList<Candidate>()

        for (dy in -2..2) {
            for (dx in -SEARCH_RADIUS_XZ..SEARCH_RADIUS_XZ) {
                for (dz in -SEARCH_RADIUS_XZ..SEARCH_RADIUS_XZ) {
                    val px = targetX + dx; val py = targetY + dy; val pz = targetZ + dz
                    if (!WorldBlockTracker.hasData(px, py, pz)) continue
                    val spotId = WorldBlockTracker.getBlockIdentifier(px, py, pz) ?: "minecraft:air"
                    if (spotId !in NON_SOLID) continue

                    var belowId: String? = null
                    var belowDepth = 0
                    for (depth in 1..4) {
                        val by = py - depth
                        if (!WorldBlockTracker.hasData(px, by, pz)) continue
                        val id = WorldBlockTracker.getBlockIdentifier(px, by, pz) ?: continue
                        if (id in NON_SOLID) continue
                        belowId = id; belowDepth = depth; break
                    }
                    if (belowId == null) continue

                    val anchorY = py - belowDepth + 1
                    val cx = px + 0.5f; val cy = anchorY + 0.5f; val cz = pz + 0.5f
                    val explosion = CombatUtil.simulateExplosion(cx, cy, cz, ANCHOR_EXPLOSION_POWER)
                    if (explosion.mostDamage < minDamage.value) continue
                    if (avoidSuicide.value && explosion.selfDamage > explosion.mostDamage) continue
                    if (lethalOnly.value && explosion.mostDamage < target.health) continue

                    val dist = MathUtil.dist3(
                        cx, cy, cz,
                        EntityTracker.selfX, EntityTracker.selfY + 1.62f, EntityTracker.selfZ
                    )
                    found.add(Candidate(Vector3i.from(px, anchorY, pz), explosion.mostDamage, explosion.selfDamage, dist <= placeRange.value))
                }
            }
        }
        return found
    }

    private fun scan() {
        val list = targets().flatMap { spotsNear(it) }
        candidates = list.sortedByDescending { it.damage }
            .distinctBy { it.pos }
            .take(showTopN.value)
    }

    fun render(canvas: Canvas, screenW: Int, screenH: Int) {
        if (!isEnabled) return

        val now = System.currentTimeMillis()
        if (now - lastScanMs >= updateMs.value) {
            lastScanMs = now
            scan()
        }

        val list = candidates
        if (list.isEmpty()) return

        val selfX = EntityTracker.selfX; val selfY = EntityTracker.selfY; val selfZ = EntityTracker.selfZ
        val yaw = EntityTracker.selfYaw; val pitch = EntityTracker.selfPitch
        val baseColor = colorArgb()

        list.forEachIndexed { rank, c -> drawCandidate(canvas, screenW, screenH, selfX, selfY, selfZ, yaw, pitch, baseColor, rank, c) }
    }

    private fun drawCandidate(
        canvas: Canvas, screenW: Int, screenH: Int,
        selfX: Float, selfY: Float, selfZ: Float, yaw: Float, pitch: Float,
        baseColor: Int, rank: Int, c: Candidate
    ) {
        val pos = c.pos
        val corners = arrayOf(
            Triple(pos.x.toFloat(), pos.y.toFloat(), pos.z.toFloat()),
            Triple(pos.x + 1f, pos.y.toFloat(), pos.z.toFloat()),
            Triple(pos.x + 1f, pos.y.toFloat(), pos.z + 1f),
            Triple(pos.x.toFloat(), pos.y.toFloat(), pos.z + 1f),
            Triple(pos.x.toFloat(), pos.y + 1f, pos.z.toFloat()),
            Triple(pos.x + 1f, pos.y + 1f, pos.z.toFloat()),
            Triple(pos.x + 1f, pos.y + 1f, pos.z + 1f),
            Triple(pos.x.toFloat(), pos.y + 1f, pos.z + 1f)
        )

        var minX = Float.MAX_VALUE; var maxX = -Float.MAX_VALUE
        var minY = Float.MAX_VALUE; var maxY = -Float.MAX_VALUE
        var visible = 0
        for ((wx, wy, wz) in corners) {
            val p = MathUtil.worldToScreen(wx, wy, wz, selfX, selfY, selfZ, yaw, pitch, screenW, screenH, UiUtil.currentFov) ?: continue
            if (p.first < minX) minX = p.first; if (p.first > maxX) maxX = p.first
            if (p.second < minY) minY = p.second; if (p.second > maxY) maxY = p.second
            visible++
        }
        if (visible == 0) return

        val rankFade = (255 - rank * 70).coerceIn(90, 255)

        boxPaint.color = baseColor; boxPaint.alpha = rankFade
        boxPaint.pathEffect = if (c.inRange) null else dashEffect
        fillPaint.color = baseColor; fillPaint.alpha = (rankFade * 0.25f).toInt()

        reusableRect.set(minX, minY, maxX, maxY)
        canvas.drawRoundRect(reusableRect, 3f, 3f, fillPaint)
        canvas.drawRoundRect(reusableRect, 3f, 3f, boxPaint)

        val lethalMark = if (c.damage >= 20f) " \u2620" else ""
        val label = if (showSelfDamage.value) {
            "#${rank + 1} ${c.damage.roundToInt()} dmg (self ${c.selfDamage.roundToInt()})$lethalMark"
        } else {
            "#${rank + 1} ${c.damage.roundToInt()} dmg$lethalMark"
        }
        textPaint.color = if (c.inRange) Color.WHITE else Color.argb(255, 210, 210, 210)
        canvas.drawText(label, (minX + maxX) / 2f, minY - 10f, textPaint)
    }
}
