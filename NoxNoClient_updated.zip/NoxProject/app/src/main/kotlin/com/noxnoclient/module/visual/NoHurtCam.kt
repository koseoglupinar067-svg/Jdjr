package com.noxnoclient.module.visual

import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.events.PacketEvent
import com.noxnoclient.module.BaseModule
import com.noxnoclient.module.ModuleCategory
import org.cloudburstmc.protocol.bedrock.data.entity.EntityEventType
import org.cloudburstmc.protocol.bedrock.packet.CameraShakePacket
import org.cloudburstmc.protocol.bedrock.packet.EntityEventPacket

class NoHurtCam : BaseModule(
    name        = "NoHurtCam",
    category    = ModuleCategory.VISUAL,
    description = "Removes the head-tilt hurt animation and camera shake caused by taking damage"
) {
    private val removeTilt  = bool("Remove Hurt Tilt",   true)
    private val removeShake = bool("Remove Camera Shake", true)
    private val shortcut    = bool("Shortcut", false)

    override fun onPacket(event: PacketEvent) {
        if (!isEnabled) return
        if (event.direction != PacketEvent.Direction.SERVER_TO_CLIENT) return

        when (val pkt = event.packet) {
            is EntityEventPacket -> {
                if (!removeTilt.value) return
                if (pkt.runtimeEntityId != EntityTracker.selfRuntimeId) return
                if (pkt.type == EntityEventType.HURT) event.cancel()
            }
            is CameraShakePacket -> {
                if (removeShake.value) event.cancel()
            }
            else -> {}
        }
    }
}
