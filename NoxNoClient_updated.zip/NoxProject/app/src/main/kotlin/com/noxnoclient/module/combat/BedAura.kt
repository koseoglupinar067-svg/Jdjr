package com.noxnoclient.module.combat

import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.core.relay.NoxNoRelaySession
import com.noxnoclient.events.PacketEvent
import com.noxnoclient.events.PacketEventBus
import com.noxnoclient.module.BaseModule
import com.noxnoclient.module.ModuleCategory
import com.noxnoclient.module.social.isFriendEntity
import com.noxnoclient.utils.CombatUtil
import com.noxnoclient.utils.InventoryUtil
import com.noxnoclient.utils.MathUtil
import com.noxnoclient.utils.WorldBlockTracker
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import org.cloudburstmc.math.vector.Vector3f
import org.cloudburstmc.math.vector.Vector3i
import org.cloudburstmc.protocol.bedrock.packet.PlayerAuthInputPacket
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.math.floor

class BedAura : BaseModule(
    name        = "BedAura",
    category    = ModuleCategory.COMBAT,
    description = "Places beds next to the target and detonates them (Nether/End) - tracks several attempts in parallel so one failed spot doesn't stall the module"
) {
    companion object {
        private const val VERIFY_CHECK_EVERY_MS = 20L

        private val NEIGHBOR_OFFSETS = listOf(
            Triple(1, 0, 0), Triple(-1, 0, 0),
            Triple(0, 0, 1), Triple(0, 0, -1)
        )
    }

    private val targetRange        = int ("Target Range", 8, 2, 16)
    private val placeRange         = int ("Place Range", 6, 2, 12)
    private val friendSkip         = bool("Friend Skip", true)
    private val noSwitch           = bool("No Switch", true)
    private val requireNetherOrEnd = bool("Require Nether/End", true)
    private val shortcut           = bool("Shortcut", false)

    private val maxBeds    = int ("Max Beds", 2, 1, 4)
    private val forceMode  = bool("Force Mode", false)

    private val fastMode         = bool("Fast Mode", false)
    private val cooldownMs       = int ("Cooldown (ms)", 150, 50, 3000)
    private val packetGapMs      = int ("Min Packet Gap (ms)", 40, 10, 300)
    private val minBreakDelayMs  = int ("Min Break Delay (ms)", 70, 30, 500)

    private val confirmPlacement    = bool("Confirm Placement", true)
    private val verifyRetryWindowMs = int ("Verify Retry Window (ms)", 150, 50, 800)

    private val NON_SOLID = setOf(
        "minecraft:air", "minecraft:water", "minecraft:flowing_water",
        "minecraft:lava", "minecraft:flowing_lava",
        "minecraft:void_air", "minecraft:cave_air"
    )

    private data class Attempt(
        val bedPos: Vector3i,
        val armedAt: Long,
        val verifyDeadline: Long,
        val bedIdentifier: String,
        val nextCheckAt: Long = 0L
    )

    private enum class VerifyResult { CONFIRMED, REJECTED, PENDING }

    private val activeAttempts = CopyOnWriteArrayList<Attempt>()

    @Volatile private var lastAttemptMs = 0L
    @Volatile private var lastPacketSentMs = 0L
    @Volatile private var tickJob: Job? = null
    @Volatile private var pendingYawOverride: Float? = null

    private fun effectiveCooldownMs(): Long =
        if (fastMode.value) (cooldownMs.value / 2).coerceAtLeast(40) else cooldownMs.value.toLong()

    private fun effectivePacketGapMs(): Long =
        if (fastMode.value) (packetGapMs.value / 2).coerceAtLeast(10) else packetGapMs.value.toLong()

    private fun tryConsumePacketSlot(): Boolean {
        val now = System.currentTimeMillis()
        if (now - lastPacketSentMs < effectivePacketGapMs()) return false
        lastPacketSentMs = now
        return true
    }

    override fun onEnable() {
        super.onEnable()
        activeAttempts.clear()
        lastAttemptMs = 0L
        lastPacketSentMs = 0L
        pendingYawOverride = null
        tickJob?.cancel()
        tickJob = launchTickLoop(30L) { tick() }
    }

    override fun onDisable() {
        tickJob?.cancel(); tickJob = null
        super.onDisable()
        activeAttempts.clear()
        pendingYawOverride = null
    }

    override fun onPacket(event: PacketEvent) {

        val override = pendingYawOverride
        if (override != null &&
            event.packet is PlayerAuthInputPacket &&
            event.direction == PacketEvent.Direction.CLIENT_TO_SERVER
        ) {
            val p = event.packet as PlayerAuthInputPacket
            p.rotation = Vector3f.from(p.rotation.x, override, override)
            pendingYawOverride = null
        }
    }

    private suspend fun tick() {
        if (requireNetherOrEnd.value && EntityTracker.selfDimension == 0) return
        val session = PacketEventBus.currentSession ?: return
        val now = System.currentTimeMillis()

        for (attempt in activeAttempts) {
            if (now - attempt.armedAt < minBreakDelayMs.value) continue
            if (now < attempt.nextCheckAt) continue

            when (verifyPlaced(attempt)) {
                VerifyResult.CONFIRMED -> {
                    if (!tryConsumePacketSlot()) continue
                    // Prefer the actual identifier seen in the world (any bed color),
                    // fall back to whatever we placed (still works since all beds share legacy ID 26).
                    val interactId = WorldBlockTracker.getBlockIdentifier(
                        attempt.bedPos.x, attempt.bedPos.y, attempt.bedPos.z
                    )?.takeIf { it !in NON_SOLID } ?: attempt.bedIdentifier
                    InventoryUtil.sendInteract(session, attempt.bedPos, interactId)
                    activeAttempts.remove(attempt)
                }
                VerifyResult.REJECTED -> {
                    activeAttempts.remove(attempt)
                }
                VerifyResult.PENDING -> {
                    activeAttempts.remove(attempt)
                    activeAttempts.add(attempt.copy(nextCheckAt = now + VERIFY_CHECK_EVERY_MS))
                }
            }
        }

        if (activeAttempts.size >= maxBeds.value) return
        if (now - lastAttemptMs < effectiveCooldownMs()) return

        val target = nearestEnemy() ?: return
        attemptPlace(session, target)
    }

    private fun verifyPlaced(attempt: Attempt): VerifyResult {
        if (forceMode.value || !confirmPlacement.value) return VerifyResult.CONFIRMED

        val now = System.currentTimeMillis()
        val pos = attempt.bedPos

        if (!WorldBlockTracker.hasData(pos.x, pos.y, pos.z)) {

            return if (now < attempt.verifyDeadline) VerifyResult.PENDING else VerifyResult.CONFIRMED
        }

        val id = WorldBlockTracker.getBlockIdentifier(pos.x, pos.y, pos.z)
        // Any non-air block at the position means the bed (or something) was placed — confirm it.
        // We don't filter by specific bed identifier so all bed colors work correctly.
        if (id != null && id !in NON_SOLID) return VerifyResult.CONFIRMED

        if (id == null || id in NON_SOLID) {
            return if (now < attempt.verifyDeadline) VerifyResult.PENDING else VerifyResult.CONFIRMED
        }

        return VerifyResult.REJECTED
    }

    private fun nearestEnemy(): EntityTracker.TrackedEntity? {
        if (EntityTracker.selfRuntimeId <= 0L) return null
        val sx = EntityTracker.selfX; val sy = EntityTracker.selfY; val sz = EntityTracker.selfZ
        return EntityTracker.getPlayers(targetRange.value.toFloat())
            .asSequence()
            .filter { it.runtimeId != EntityTracker.selfRuntimeId }
            .filter { !friendSkip.value || !it.isFriendEntity }
            .minByOrNull { MathUtil.dist3sq(it.x, it.y, it.z, sx, sy, sz) }
    }

    private fun isFreeSpot(pos: Vector3i, occupied: Set<Vector3i>): Boolean {
        if (pos in occupied) return false
        if (!WorldBlockTracker.hasData(pos.x, pos.y, pos.z)) return true
        val id = WorldBlockTracker.getBlockIdentifier(pos.x, pos.y, pos.z) ?: return true
        return id in NON_SOLID
    }

    private fun hasSolidBelow(pos: Vector3i): String? {
        val belowPos = Vector3i.from(pos.x, pos.y - 1, pos.z)
        if (!WorldBlockTracker.hasData(belowPos.x, belowPos.y, belowPos.z)) return null
        val below = WorldBlockTracker.getBlockIdentifier(belowPos.x, belowPos.y, belowPos.z)
        if (below == null || below in NON_SOLID) return null
        return below
    }

    private fun groundSnappedY(target: EntityTracker.TrackedEntity): Int {
        val fx = floor(target.x).toInt(); val fz = floor(target.z).toInt()
        val startY = floor(target.y + 0.1f).toInt()
        for (dy in 0..2) {
            val y = startY - dy
            val below = WorldBlockTracker.getBlockIdentifier(fx, y - 1, fz)
            if (below != null && below !in NON_SOLID) return y
        }
        return startY
    }

    private fun findCandidate(
        tx: Int, ty: Int, tz: Int, occupied: Set<Vector3i>
    ): Triple<Vector3i, String, Float>? {
        val centerCandidate = Vector3i.from(tx, ty, tz)

        for ((dx, _, dz) in orderedByFacing(NEIGHBOR_OFFSETS)) {
            val candidate = Vector3i.from(tx + dx, ty, tz + dz)
            if (!isFreeSpot(candidate, occupied)) continue
            val below = hasSolidBelow(candidate) ?: continue

            val secondHalf = orderedByFacing(NEIGHBOR_OFFSETS).firstOrNull { (ndx, _, ndz) ->
                val second = Vector3i.from(candidate.x + ndx, candidate.y, candidate.z + ndz)
                isFreeSpot(second, occupied) && hasSolidBelow(second) != null
            } ?: continue

            return Triple(candidate, below, yawToward(secondHalf.first, secondHalf.third))
        }

        if (isFreeSpot(centerCandidate, occupied)) {
            val below = hasSolidBelow(centerCandidate)
            val secondHalf = orderedByFacing(NEIGHBOR_OFFSETS).firstOrNull { (ndx, _, ndz) ->
                val second = Vector3i.from(centerCandidate.x + ndx, centerCandidate.y, centerCandidate.z + ndz)
                isFreeSpot(second, occupied) && hasSolidBelow(second) != null
            }
            if (below != null && secondHalf != null) {
                return Triple(centerCandidate, below, yawToward(secondHalf.first, secondHalf.third))
            }
        }

        return null
    }

    private fun findFallbackCandidate(
        tx: Int, ty: Int, tz: Int, occupied: Set<Vector3i>
    ): Triple<Vector3i, String, Float>? {
        val fallbackBelow = "minecraft:stone"
        for ((dx, _, dz) in orderedByFacing(NEIGHBOR_OFFSETS)) {
            val candidate = Vector3i.from(tx + dx, ty, tz + dz)
            if (!isFreeSpot(candidate, occupied)) continue
            return Triple(candidate, fallbackBelow, yawToward(dx, dz))
        }
        return null
    }

    private suspend fun attemptPlace(session: NoxNoRelaySession, target: EntityTracker.TrackedEntity) {
        val tx = floor(target.x).toInt()
        val ty = groundSnappedY(target)
        val tz = floor(target.z).toInt()

        val occupied = activeAttempts.mapTo(HashSet()) { it.bedPos }
        val hasData = WorldBlockTracker.hasAnyTerrainData()

        val (bedPos, belowBlock, facingYaw) =
            (if (hasData) findCandidate(tx, ty, tz, occupied) else null)
                ?: findFallbackCandidate(tx, ty, tz, occupied)
                ?: return

        val cx = bedPos.x + 0.5f
        val cy = bedPos.y + 0.5f
        val cz = bedPos.z + 0.5f

        if (MathUtil.dist3(cx, cy, cz, EntityTracker.selfX, EntityTracker.selfY + 1.62f, EntityTracker.selfZ) > placeRange.value) return
        if (!tryConsumePacketSlot()) return

        val prepared = InventoryUtil.prepareAnyBedForUse(session, noSwitch.value) ?: return
        lastAttemptMs = System.currentTimeMillis()

        pendingYawOverride = facingYaw
        var waited = 0L
        while (pendingYawOverride != null && waited < 160L) {
            delay(10L)
            waited += 10L
        }
        pendingYawOverride = null
        EntityTracker.selfYaw = facingYaw

        CombatUtil.sendMove(
            session = session,
            x = EntityTracker.selfX, y = EntityTracker.selfY, z = EntityTracker.selfZ,
            yaw = facingYaw, pitch = EntityTracker.selfPitch,
            onGround = EntityTracker.selfOnGround, teleport = false, mirrorToClient = false
        )

        val belowPos = Vector3i.from(bedPos.x, bedPos.y - 1, bedPos.z)
        val ok = InventoryUtil.sendPlacementUseRaw(session, prepared, belowPos, belowBlock, blockFace = 1)
        InventoryUtil.revert(session, prepared)
        if (!ok) return

        val armedAt = System.currentTimeMillis()
        activeAttempts.add(
            Attempt(
                bedPos         = bedPos,
                armedAt        = armedAt,
                verifyDeadline = armedAt + minBreakDelayMs.value + verifyRetryWindowMs.value,
                bedIdentifier  = prepared.identifier ?: "minecraft:red_bed",
                nextCheckAt    = armedAt + minBreakDelayMs.value
            )
        )
    }

    private fun yawToward(dx: Int, dz: Int): Float =
        Math.toDegrees(kotlin.math.atan2(-dx.toDouble(), dz.toDouble())).toFloat()

    private fun orderedByFacing(offsets: List<Triple<Int, Int, Int>>): List<Triple<Int, Int, Int>> {
        val selfYaw = EntityTracker.selfYaw
        return offsets.sortedBy { (dx, _, dz) ->
            var diff = yawToward(dx, dz) - selfYaw
            diff = ((diff % 360f) + 540f) % 360f - 180f
            kotlin.math.abs(diff)
        }
    }
}
