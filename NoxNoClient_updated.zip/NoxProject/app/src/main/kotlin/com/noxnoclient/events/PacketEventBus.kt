package com.noxnoclient.events

import com.noxnoclient.core.relay.NoxNoRelaySession
import java.util.concurrent.CopyOnWriteArrayList

object PacketEventBus {

    private val listeners = CopyOnWriteArrayList<PacketListener>()

    @Volatile private var snapshot: Array<PacketListener> = emptyArray()

    private fun rebuildSnapshot() {
        snapshot = listeners.toTypedArray()
    }

    @Volatile var currentSession: NoxNoRelaySession? = null
        private set

    fun setSession(session: NoxNoRelaySession?) {
        currentSession = session
    }

    fun register(l: PacketListener) {
        if (listeners.contains(l)) return
        listeners.add(l)
        listeners.sortBy { it.priority }
        rebuildSnapshot()
    }

    fun unregister(l: PacketListener) {
        listeners.remove(l)
        rebuildSnapshot()
    }

    fun clear() {
        listeners.clear()
        rebuildSnapshot()
        currentSession = null
    }

    fun publish(event: PacketEvent) {
        val snap = snapshot
        for (l in snap) {
            try { l.onPacket(event) } catch (_: Exception) {}

            if (event.isCancelled) break
        }
    }

    fun post(event: PacketEvent) = publish(event)

    val listenerCount: Int get() = listeners.size

    fun getListeners(): List<PacketListener> = listeners.toList()

    interface PacketListener {
        val priority: Int get() = 100
        fun onPacket(event: PacketEvent)
    }
}
