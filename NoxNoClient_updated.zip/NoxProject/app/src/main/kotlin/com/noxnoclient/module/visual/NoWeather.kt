package com.noxnoclient.module.visual

import com.noxnoclient.events.PacketEvent
import com.noxnoclient.events.PacketEventBus
import com.noxnoclient.module.BaseModule
import com.noxnoclient.module.ModuleCategory
import org.cloudburstmc.protocol.bedrock.data.LevelEvent
import org.cloudburstmc.protocol.bedrock.packet.LevelEventPacket
import org.cloudburstmc.protocol.bedrock.packet.LevelSoundEventPacket
import org.cloudburstmc.protocol.bedrock.packet.StartGamePacket

class NoWeather : BaseModule(
    name        = "NoWeather",
    category    = ModuleCategory.VISUAL,
    description = "Blocks or forces a specific weather state"
) {
    enum class WeatherMode { Off, Clear, Rain, Storm }

    private val mode          = enum("Weather", WeatherMode.Clear)
    private val muteThunder   = bool("Mute Thunder Sound", true)
    private val enforceMs     = int ("Enforce Every (ms)", 4000, 1000, 15000)
    private val shortcut      = bool("Shortcut", false)

    private var job: kotlinx.coroutines.Job? = null

    override fun onEnable() {
        super.onEnable()
        job = launchTickLoop(enforceMs.value.toLong()) { enforce() }
    }

    override fun onDisable() {
        job?.cancel()
        job = null
        super.onDisable()
    }

    private fun enforce() {
        if (mode.value == WeatherMode.Off) return
        val session = PacketEventBus.currentSession ?: return

        when (mode.value) {
            WeatherMode.Clear -> {
                sendEvent(session, LevelEvent.STOP_RAINING)
                sendEvent(session, LevelEvent.STOP_THUNDERSTORM)
            }
            WeatherMode.Rain -> {
                sendEvent(session, LevelEvent.START_RAINING, 10000)
                sendEvent(session, LevelEvent.STOP_THUNDERSTORM)
            }
            WeatherMode.Storm -> {
                sendEvent(session, LevelEvent.START_RAINING, 10000)
                sendEvent(session, LevelEvent.START_THUNDERSTORM, 10000)
            }
            WeatherMode.Off -> {}
        }
    }

    private fun sendEvent(session: com.noxnoclient.core.relay.NoxNoRelaySession, type: LevelEvent, data: Int = 0) {
        session.clientBound(LevelEventPacket().apply {
            this.type = type
            this.data = data
            position = org.cloudburstmc.math.vector.Vector3f.from(0f, 0f, 0f)
        })
    }

    override fun onPacket(event: PacketEvent) {
        if (!isEnabled) return
        if (event.direction != PacketEvent.Direction.SERVER_TO_CLIENT) return

        when (val pkt = event.packet) {
            is StartGamePacket -> {
                when (mode.value) {
                    WeatherMode.Clear -> { pkt.rainLevel = 0f; pkt.lightningLevel = 0f; event.cancelAndReplace(pkt) }
                    WeatherMode.Rain -> { pkt.rainLevel = 1f; pkt.lightningLevel = 0f; event.cancelAndReplace(pkt) }
                    WeatherMode.Storm -> { pkt.rainLevel = 1f; pkt.lightningLevel = 1f; event.cancelAndReplace(pkt) }
                    WeatherMode.Off -> {}
                }
            }
            is LevelEventPacket -> {
                if (mode.value == WeatherMode.Off) return
                val isRain = pkt.type == LevelEvent.START_RAINING || pkt.type == LevelEvent.STOP_RAINING
                val isThunder = pkt.type == LevelEvent.START_THUNDERSTORM || pkt.type == LevelEvent.STOP_THUNDERSTORM
                if (isRain || isThunder) event.cancel()
            }
            is LevelSoundEventPacket -> {
                if (muteThunder.value && pkt.sound.name.contains("THUNDER", ignoreCase = true)) {
                    event.cancel()
                }
            }
            else -> {}
        }
    }
}
