package com.noxnoclient.module.misc

import com.noxnoclient.events.PacketEvent
import com.noxnoclient.module.BaseModule
import com.noxnoclient.module.ModuleCategory
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.cloudburstmc.protocol.bedrock.packet.StartGamePacket
import org.cloudburstmc.protocol.bedrock.packet.TextPacket

/**
 * AutoCommand — sunucuya bağlanıldığında otomatik olarak bir komut gönderir.
 */
class AutoCommand : BaseModule(
    name        = "AutoCommand",
    category    = ModuleCategory.MISC,
    description = "Sunucuya bağlandığında otomatik komut gönderir"
) {
    private val command    = string("Command",  "/spawn")
    private val delayTicks = int   ("Delay (ms)", 2000, 500, 10000)

    override fun onPacket(event: PacketEvent) {
        if (!isEnabled) return
        if (event.direction != PacketEvent.Direction.SERVER_TO_CLIENT) return
        if (event.packet !is StartGamePacket) return

        val session = event.session
        scope.launch {
            delay(delayTicks.value.toLong())
            if (!isEnabled) return@launch
            val pkt = TextPacket().apply {
                type               = TextPacket.Type.CHAT
                isNeedsTranslation = false
                sourceName         = InternalChat.MARKER
                xuid               = ""
                platformChatId     = ""
                setMessage(command.value)
                setFilteredMessage("")
            }
            runCatching { session.sendToServer(pkt) }
        }
    }
}
