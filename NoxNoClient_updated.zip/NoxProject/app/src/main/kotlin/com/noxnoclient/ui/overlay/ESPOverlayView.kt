package com.noxnoclient.ui.overlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.view.View
import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.module.ModuleManager
import com.noxnoclient.module.visual.ArrayListModule
import com.noxnoclient.module.combat.AnchorHelper
import com.noxnoclient.module.combat.CrystalHelper
import com.noxnoclient.module.visual.CoordsHud
import com.noxnoclient.module.visual.PingHud
import com.noxnoclient.module.visual.CpsHud
import com.noxnoclient.module.visual.FpsHud
import com.noxnoclient.module.visual.ArmorHud
import com.noxnoclient.module.visual.PlayerESP
import com.noxnoclient.module.visual.MobESP
import com.noxnoclient.module.visual.ItemESP
import com.noxnoclient.module.visual.StorageESP
import com.noxnoclient.module.visual.BedESP
import com.noxnoclient.module.visual.PortalESP
import com.noxnoclient.module.visual.NameTags
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.launch

class ESPOverlayView(context: Context) : View(context) {

    init {
        setBackgroundColor(Color.TRANSPARENT)
    }

    private val arrayListModule: ArrayListModule? by lazy { ModuleManager.byName("ArrayList") as? ArrayListModule }
    private val anchorHelperModule: AnchorHelper? by lazy { ModuleManager.byName("AnchorHelper") as? AnchorHelper }
    private val crystalHelperModule: CrystalHelper? by lazy { ModuleManager.byName("CrystalHelper") as? CrystalHelper }
    private val coordsHudModule: CoordsHud? by lazy { ModuleManager.byName("CoordsHUD") as? CoordsHud }
    private val pingHudModule: PingHud? by lazy { ModuleManager.byName("PingHud") as? PingHud }
    private val cpsHudModule: CpsHud? by lazy { ModuleManager.byName("CpsHud") as? CpsHud }
    private val fpsHudModule: FpsHud? by lazy { ModuleManager.byName("FpsHud") as? FpsHud }
    private val armorHudModule: ArmorHud? by lazy { ModuleManager.byName("ArmorHud") as? ArmorHud }
    private val playerEspModule: PlayerESP? by lazy { ModuleManager.byName("PlayerESP") as? PlayerESP }
    private val mobEspModule: MobESP? by lazy { ModuleManager.byName("MobESP") as? MobESP }
    private val itemEspModule: ItemESP? by lazy { ModuleManager.byName("ItemESP") as? ItemESP }
    private val storageEspModule: StorageESP? by lazy { ModuleManager.byName("StorageESP") as? StorageESP }
    private val bedEspModule: BedESP? by lazy { ModuleManager.byName("BedESP") as? BedESP }
    private val portalEspModule: PortalESP? by lazy { ModuleManager.byName("PortalESP") as? PortalESP }
    private val nameTagsModule: NameTags? by lazy { ModuleManager.byName("NameTags") as? NameTags }

    private var fpsWindowStartMs = System.currentTimeMillis()
    private var fpsFrameCount = 0

    private val renderScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var activeJob: Job? = null

    @Volatile private var hasActiveVisualModule = false
    @Volatile private var isLoopRunning = false

    private val idlePoller = Handler(Looper.getMainLooper())
    private val idleCheckRunnable = object : Runnable {
        override fun run() {
            if (!isLoopRunning && hasActiveVisualModule) {
                resumeLoop()
            }
            if (!isLoopRunning) {
                idlePoller.postDelayed(this, 400L)
            }
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        activeJob?.cancel()
        activeJob = renderScope.launch {
            val flows = listOf(
                arrayListModule?.enabledFlow ?: flowOf(false),
                anchorHelperModule?.enabledFlow ?: flowOf(false),
                crystalHelperModule?.enabledFlow ?: flowOf(false),
                coordsHudModule?.enabledFlow ?: flowOf(false),
                pingHudModule?.enabledFlow ?: flowOf(false),
                cpsHudModule?.enabledFlow ?: flowOf(false),
                fpsHudModule?.enabledFlow ?: flowOf(false),
                armorHudModule?.enabledFlow ?: flowOf(false),
                playerEspModule?.enabledFlow ?: flowOf(false),
                mobEspModule?.enabledFlow ?: flowOf(false),
                itemEspModule?.enabledFlow ?: flowOf(false),
                storageEspModule?.enabledFlow ?: flowOf(false),
                bedEspModule?.enabledFlow ?: flowOf(false),
                portalEspModule?.enabledFlow ?: flowOf(false),
                nameTagsModule?.enabledFlow ?: flowOf(false)
            )

            combine(flows) { states -> states.any { it } }
                .collect { anyActive ->
                    hasActiveVisualModule = anyActive
                    if (anyActive && !isLoopRunning) resumeLoop()
                }
        }
        idlePoller.removeCallbacks(idleCheckRunnable)
        idlePoller.post(idleCheckRunnable)
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        activeJob?.cancel()
        idlePoller.removeCallbacks(idleCheckRunnable)
        isLoopRunning = false
    }

    private fun resumeLoop() {
        if (isLoopRunning) return
        isLoopRunning = true
        postInvalidateOnAnimation()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val arrayList = arrayListModule
        if (arrayList != null && arrayList.isEnabled) {
            try { arrayList.render(canvas, width, height) } catch (_: Exception) {}
        }

        val anchorHelper = anchorHelperModule
        if (anchorHelper != null && anchorHelper.isEnabled) {
            try { anchorHelper.render(canvas, width, height) } catch (_: Exception) {}
        }

        val crystalHelper = crystalHelperModule
        if (crystalHelper != null && crystalHelper.isEnabled) {
            try { crystalHelper.render(canvas, width, height) } catch (_: Exception) {}
        }

        val coordsHud = coordsHudModule
        if (coordsHud != null && coordsHud.isEnabled) {
            try { coordsHud.render(canvas, width, height) } catch (_: Exception) {}
        }

        val pingHud = pingHudModule
        if (pingHud != null && pingHud.isEnabled) {
            try { pingHud.render(canvas, width, height) } catch (_: Exception) {}
        }

        val cpsHud = cpsHudModule
        if (cpsHud != null && cpsHud.isEnabled) {
            try { cpsHud.render(canvas, width, height) } catch (_: Exception) {}
        }

        val fpsHud = fpsHudModule
        if (fpsHud != null && fpsHud.isEnabled) {
            try { fpsHud.render(canvas, width, height) } catch (_: Exception) {}
        }

        val armorHud = armorHudModule
        if (armorHud != null && armorHud.isEnabled) {
            try { armorHud.render(canvas, width, height) } catch (_: Exception) {}
        }

        val storageEsp = storageEspModule
        if (storageEsp != null && storageEsp.isEnabled) {
            try { storageEsp.render(canvas, width, height) } catch (_: Exception) {}
        }

        val itemEsp = itemEspModule
        if (itemEsp != null && itemEsp.isEnabled) {
            try { itemEsp.render(canvas, width, height) } catch (_: Exception) {}
        }

        val mobEsp = mobEspModule
        if (mobEsp != null && mobEsp.isEnabled) {
            try { mobEsp.render(canvas, width, height) } catch (_: Exception) {}
        }

        val playerEsp = playerEspModule
        if (playerEsp != null && playerEsp.isEnabled) {
            try { playerEsp.render(canvas, width, height) } catch (_: Exception) {}
        }

        val bedEsp = bedEspModule
        if (bedEsp != null && bedEsp.isEnabled) {
            try { bedEsp.render(canvas, width, height) } catch (_: Exception) {}
        }

        val portalEsp = portalEspModule
        if (portalEsp != null && portalEsp.isEnabled) {
            try { portalEsp.render(canvas, width, height) } catch (_: Exception) {}
        }

        val nameTags = nameTagsModule
        if (nameTags != null && nameTags.isEnabled) {
            try { nameTags.render(canvas, width, height) } catch (_: Exception) {}
        }

        updateFpsWindow()

        if (hasActiveVisualModule) {
            postInvalidateOnAnimation()
        } else {
            isLoopRunning = false
            idlePoller.removeCallbacks(idleCheckRunnable)
            idlePoller.post(idleCheckRunnable)
        }
    }

    private fun updateFpsWindow() {
        fpsFrameCount++
        val now = System.currentTimeMillis()
        val elapsed = now - fpsWindowStartMs
        if (elapsed >= 500L) {
            val fps = ((fpsFrameCount * 1000L) / elapsed).toInt()
            OverlayState.updatePerformanceStats(fps, EntityTracker.selfPingMs)
            fpsFrameCount = 0
            fpsWindowStartMs = now
        }
    }

    fun startRenderLoop() {
        resumeLoop()
    }
}
