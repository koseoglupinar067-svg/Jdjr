package com.noxnoclient.module.visual

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.events.PacketEvent
import com.noxnoclient.module.BaseModule
import com.noxnoclient.module.ModuleCategory
import com.noxnoclient.utils.MathUtil
import com.noxnoclient.utils.UiUtil
import org.cloudburstmc.protocol.bedrock.packet.UpdateBlockPacket
import java.util.concurrent.ConcurrentHashMap

class PortalESP : BaseModule(
    name        = "PortalESP",
    category    = ModuleCategory.VISUAL,
    description = "Nether ve End portallarını vurgular"
) {
    private val range     = float("Range",     128f, 8f, 256f)
    private val fill      = bool ("Fill",      true)
    private val showLabel = bool ("Label",     true)
    private val showDist  = bool ("Distance",  true)

    private data class PortalEntry(val x: Int, val y: Int, val z: Int, val isEnd: Boolean)

    private val portals = ConcurrentHashMap<Long, PortalEntry>()

    private val netherPaint = Paint().apply { style = Paint.Style.STROKE; strokeWidth = 3f; isAntiAlias = true; color = Color.rgb(160, 0, 255) }
    private val endPaint    = Paint().apply { style = Paint.Style.STROKE; strokeWidth = 3f; isAntiAlias = true; color = Color.rgb(30, 200, 150) }
    private val fillPaint   = Paint().apply { style = Paint.Style.FILL; isAntiAlias = true }
    private val textPaint   = Paint().apply {
        isAntiAlias = true; textSize = 26f; textAlign = Paint.Align.CENTER
        setShadowLayer(3f, 0f, 0f, Color.BLACK); color = Color.WHITE
    }

    override fun onEnable() { super.onEnable(); portals.clear() }
    override fun onDisable() { portals.clear(); super.onDisable() }

    override fun onPacket(event: PacketEvent) {
        if (!isEnabled) return
        if (event.direction != PacketEvent.Direction.SERVER_TO_CLIENT) return
        val pkt = event.packet as? UpdateBlockPacket ?: return
        val blockDef = pkt.definition ?: return
        val identifier = runCatching { blockDef.identifier ?: "" }.getOrElse { "" }
        val pos = pkt.blockPosition ?: return
        val key = (pos.x.toLong() shl 40) or (pos.y.toLong() shl 20) or pos.z.toLong()

        when {
            identifier.contains("portal", ignoreCase = true) && identifier.contains("nether", ignoreCase = true) ->
                portals[key] = PortalEntry(pos.x, pos.y, pos.z, isEnd = false)
            identifier.contains("portal", ignoreCase = true) && identifier.contains("end", ignoreCase = true) ->
                portals[key] = PortalEntry(pos.x, pos.y, pos.z, isEnd = true)
            identifier.contains("nether_portal", ignoreCase = true) ->
                portals[key] = PortalEntry(pos.x, pos.y, pos.z, isEnd = false)
            identifier.contains("end_portal", ignoreCase = true) ->
                portals[key] = PortalEntry(pos.x, pos.y, pos.z, isEnd = true)
            else -> portals.remove(key)
        }
    }

    fun render(canvas: Canvas, screenW: Int, screenH: Int) {
        if (!isEnabled || portals.isEmpty()) return
        val selfX = EntityTracker.selfX; val selfY = EntityTracker.selfY; val selfZ = EntityTracker.selfZ
        val yaw = EntityTracker.selfYaw; val pitch = EntityTracker.selfPitch
        val fov = UiUtil.currentFov
        val r = range.value

        for (entry in portals.values) {
            val cx = entry.x + 0.5f; val cy = entry.y.toFloat(); val cz = entry.z + 0.5f
            val dist = MathUtil.dist3(cx, cy, cz, selfX, selfY, selfZ)
            if (dist > r) continue

            val screenPt = MathUtil.worldToScreen(cx, cy + 0.5f, cz, selfX, selfY, selfZ, yaw, pitch, screenW, screenH, fov) ?: continue

            val boxSize = (80f / (dist + 1f)).coerceIn(8f, 80f)
            val paint = if (entry.isEnd) endPaint else netherPaint
            val fillColor = if (entry.isEnd) Color.argb(50, 30, 200, 150) else Color.argb(50, 160, 0, 255)
            val label = if (entry.isEnd) "EndPortal" else "NetherPortal"

            val left   = screenPt.first - boxSize
            val top    = screenPt.second - boxSize
            val right  = screenPt.first + boxSize
            val bottom = screenPt.second + boxSize

            if (fill.value) {
                fillPaint.color = fillColor
                canvas.drawRect(left, top, right, bottom, fillPaint)
            }
            canvas.drawRect(left, top, right, bottom, paint)

            if (showLabel.value) {
                val lbl = if (showDist.value) "$label (${dist.toInt()}m)" else label
                canvas.drawText(lbl, screenPt.first, top - 6f, textPaint)
            }
        }
    }
}
