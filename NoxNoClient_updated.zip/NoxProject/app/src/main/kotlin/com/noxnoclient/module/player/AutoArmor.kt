package com.noxnoclient.module.player

import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.events.PacketEvent
import com.noxnoclient.events.PacketEventBus
import com.noxnoclient.module.BaseModule
import com.noxnoclient.module.ModuleCategory
import com.noxnoclient.utils.InventoryUtil
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import org.cloudburstmc.protocol.bedrock.data.inventory.ContainerId
import org.cloudburstmc.protocol.bedrock.data.inventory.ContainerSlotType
import org.cloudburstmc.protocol.bedrock.data.inventory.ItemData
import org.cloudburstmc.protocol.bedrock.packet.InventoryContentPacket
import org.cloudburstmc.protocol.bedrock.packet.InventorySlotPacket

class AutoArmor : BaseModule(
    name        = "AutoArmor",
    category    = ModuleCategory.PLAYER,
    description = "Automatically equips the best armor from inventory"
) {
    private val delay     = int   ("Equip Delay (ms)", 100, 0, 1000)
    private val shortcut  = bool  ("Shortcut", false)

    // Armor protection values: (material -> protection points per piece)
    private val ARMOR_PROTECTION = mapOf(
        "netherite" to intArrayOf(3, 8, 6, 3),   // helm, chest, legs, boots
        "diamond"   to intArrayOf(3, 8, 6, 3),
        "iron"      to intArrayOf(2, 6, 5, 2),
        "chainmail" to intArrayOf(2, 5, 4, 1),
        "golden"    to intArrayOf(2, 5, 3, 1),
        "leather"   to intArrayOf(1, 3, 2, 1),
        "turtle"    to intArrayOf(2, 0, 0, 0)
    )

    // Armor material tier (higher = better, same protection -> prefer higher)
    private val ARMOR_TIER = mapOf(
        "netherite" to 6, "diamond" to 5, "iron" to 4,
        "chainmail" to 3, "golden" to 2, "leather" to 1, "turtle" to 2
    )

    private var tickJob: Job? = null

    override fun onEnable() {
        super.onEnable()
        tickJob = launchTickLoop(500L) { checkAndEquip() }
    }

    override fun onDisable() {
        tickJob?.cancel(); tickJob = null
        super.onDisable()
    }

    override fun onPacket(event: PacketEvent) {
        if (!isEnabled) return
        when (event.packet) {
            is InventoryContentPacket, is InventorySlotPacket -> scope.launch { checkAndEquip() }
        }
    }

    private suspend fun checkAndEquip() {
        val session = PacketEventBus.currentSession ?: return

        // For each armor slot: find best candidate in inventory/hotbar, equip if better
        for (armorSlot in 0..3) {
            val currentArmor = EntityTracker.getArmorItem(armorSlot)
            val currentScore = scoreArmor(currentArmor, armorSlot)

            var bestScore = currentScore
            var bestItem: ItemData? = null
            var bestInvSlot = -1

            for (invSlot in 0..35) {
                val item = EntityTracker.getInventoryItem(invSlot) ?: continue
                if (item.count <= 0) continue
                val slotType = InventoryUtil.resolveArmorSlotType(item) ?: continue
                if (slotType.slotIndex != armorSlot) continue

                val score = scoreArmor(item, armorSlot)
                if (score > bestScore) {
                    bestScore = score
                    bestItem = item
                    bestInvSlot = invSlot
                }
            }

            if (bestItem != null && bestInvSlot >= 0) {
                val armorItem = currentArmor ?: ItemData.AIR
                val destSlotType = when (armorSlot) {
                    0 -> ContainerSlotType.ARMOR
                    1 -> ContainerSlotType.ARMOR
                    2 -> ContainerSlotType.ARMOR
                    3 -> ContainerSlotType.ARMOR
                    else -> continue
                }
                InventoryUtil.sendInventoryMove(
                    session           = session,
                    sourceContainer   = ContainerSlotType.HOTBAR_AND_INVENTORY,
                    sourceContainerId = ContainerId.INVENTORY,
                    sourceSlot        = bestInvSlot,
                    sourceItem        = bestItem,
                    destContainer     = destSlotType,
                    destContainerId   = ContainerId.ARMOR,
                    destSlot          = armorSlot,
                    destItem          = armorItem
                )
                delay(delay.value.toLong())
            }
        }
    }

    private fun scoreArmor(item: ItemData?, slotIndex: Int): Int {
        if (item == null || item.count <= 0) return -1
        val identifier = InventoryUtil.resolveIdentifier(item) ?: return 0
        val normalised = identifier.removePrefix("minecraft:")
        val material = when {
            normalised.startsWith("netherite") -> "netherite"
            normalised.startsWith("diamond")   -> "diamond"
            normalised.startsWith("iron")      -> "iron"
            normalised.startsWith("chainmail") -> "chainmail"
            normalised.startsWith("golden")    -> "golden"
            normalised.startsWith("leather")   -> "leather"
            normalised.startsWith("turtle")    -> "turtle"
            else -> return 0
        }
        val protection = ARMOR_PROTECTION[material]?.getOrNull(slotIndex) ?: 0
        val tier = ARMOR_TIER[material] ?: 0
        return protection * 1000 + tier
    }
}
