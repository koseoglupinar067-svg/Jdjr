package com.noxnoclient

import android.app.Application
import android.content.ContentValues
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import java.io.File
import com.noxnoclient.auth.AccountManager
import com.noxnoclient.auth.MicrosoftAuthManager
import com.noxnoclient.config.Config
import com.noxnoclient.config.ServerConfig
import com.noxnoclient.core.relay.Definitions
import com.noxnoclient.module.ModuleManager
import com.noxnoclient.module.social.FriendManager
import com.noxnoclient.session.SessionManager

import com.noxnoclient.module.combat.AnchorAura
import com.noxnoclient.module.combat.AnchorHelper
import com.noxnoclient.module.combat.AntiSurround
import com.noxnoclient.module.combat.AutoTotem
import com.noxnoclient.module.combat.AutoTrap
import com.noxnoclient.module.combat.BedAura
import com.noxnoclient.module.combat.CrystalAura
import com.noxnoclient.module.combat.CrystalHelper
import com.noxnoclient.module.combat.SelfTrap
import com.noxnoclient.module.combat.Surround
import com.noxnoclient.module.misc.AntiAFK
import com.noxnoclient.module.misc.AutoCommand
import com.noxnoclient.module.misc.ChatSpammer
import com.noxnoclient.module.misc.ChatSuffixModule
import com.noxnoclient.module.misc.PopCounter
import com.noxnoclient.module.misc.Spammer
import com.noxnoclient.module.movement.AntiKnockback
import com.noxnoclient.module.movement.AntiVoid
import com.noxnoclient.module.movement.FreeCam
import com.noxnoclient.module.movement.HighJump
import com.noxnoclient.module.movement.MultiTimer
import com.noxnoclient.module.movement.Scaffold
import com.noxnoclient.module.movement.TestFly
import com.noxnoclient.module.movement.Timer
import com.noxnoclient.module.player.AntiBlind
import com.noxnoclient.module.player.AntiHunger
import com.noxnoclient.module.player.AntiMiningFatigue
import com.noxnoclient.module.player.AntiPoison
import com.noxnoclient.module.player.AntiWeakness
import com.noxnoclient.module.player.AutoArmor
import com.noxnoclient.module.player.NoFallDamage
import com.noxnoclient.module.player.NoSlowdown
import com.noxnoclient.module.visual.ArmorHud
import com.noxnoclient.module.visual.ArrayListModule
import com.noxnoclient.module.visual.BedESP
import com.noxnoclient.module.visual.ClearNether
import com.noxnoclient.module.visual.CoordsHud
import com.noxnoclient.module.visual.CpsHud
import com.noxnoclient.module.visual.FpsHud
import com.noxnoclient.module.visual.FullBright
import com.noxnoclient.module.visual.ItemESP
import com.noxnoclient.module.visual.MobESP
import com.noxnoclient.module.visual.NameTags
import com.noxnoclient.module.visual.NoFog
import com.noxnoclient.module.visual.NoHurtCam
import com.noxnoclient.module.visual.NoWeather
import com.noxnoclient.module.visual.PingHud
import com.noxnoclient.module.visual.PlayerESP
import com.noxnoclient.module.visual.PortalESP
import com.noxnoclient.module.visual.StorageESP
import com.noxnoclient.module.world.AutoSign

import com.noxnoclient.utils.UiUtil
import com.noxnoclient.utils.WorldBlockTracker

class NoxNoClientApp : Application() {

    companion object {
        private const val TAG = "NoxNoClientApp"
        lateinit var instance: NoxNoClientApp
            private set
    }

    override fun onCreate() {
        super.onCreate()
        instance = this

        installCrashHandler()

        ServerConfig.init(applicationContext)
        Config.init(applicationContext)
        AccountManager.init(applicationContext)
        MicrosoftAuthManager.init(applicationContext)
        FriendManager.init(applicationContext)

        Thread({
            try {
                Definitions.init(applicationContext)
            } catch (e: Exception) {
                Log.e(TAG, "Definitions load error: ${e.message}", e)
            }
        }, "NoxNoDefinitionsLoader").apply {
            isDaemon = true
            start()
        }

        WorldBlockTracker.init()
        UiUtil.initIcons(applicationContext)
        registerModules()
    }

    private fun installCrashHandler() {
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                safeStopRelay()
            } catch (_: Throwable) {}
            try {
                val stamp   = java.text.SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", java.util.Locale.US)
                    .format(java.util.Date())
                val content = buildString {
                    appendLine("NoxNo Crash Report — $stamp")
                    appendLine("Thread: ${thread.name}")
                    appendLine()
                    appendLine(Log.getStackTraceString(throwable))
                }
                writeCrashLog("noxno_crash_$stamp.txt", content)
            } catch (_: Throwable) {}
            defaultHandler?.uncaughtException(thread, throwable)
        }
    }

    private fun safeStopRelay() {
        try { SessionManager.stop() } catch (_: Throwable) {}
        try { ModuleManager.disableAll() } catch (_: Throwable) {}
    }

    private fun writeCrashLog(filename: String, content: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = applicationContext.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, filename)
                put(MediaStore.Downloads.MIME_TYPE, "text/plain")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return
            resolver.openOutputStream(uri)?.use { it.write(content.toByteArray()) }
            values.clear()
            values.put(MediaStore.Downloads.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
        } else {
            @Suppress("DEPRECATION")
            val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            try { File(dir, filename).writeText(content) } catch (_: Throwable) {}
        }
    }

    private fun registerModules() {
        ModuleManager.registerAll(
            // Combat
            AnchorAura(),
            AnchorHelper(),
            AntiSurround(),
            AutoTotem(),
            AutoTrap(),
            BedAura(),
            CrystalAura(),
            CrystalHelper(),
            SelfTrap(),
            Surround(),

            // Movement
            AntiKnockback(),
            AntiVoid(),
            FreeCam(),
            HighJump(),
            MultiTimer(),
            Scaffold(),
            TestFly(),
            Timer(),

            // Visual
            ArmorHud(),
            ArrayListModule(),
            BedESP(),
            ClearNether(),
            CoordsHud(),
            CpsHud(),
            FpsHud(),
            FullBright(),
            ItemESP(),
            MobESP(),
            NameTags(),
            NoFog(),
            NoHurtCam(),
            NoWeather(),
            PingHud(),
            PlayerESP(),
            PortalESP(),
            StorageESP(),

            // Player
            AntiBlind(),
            AntiHunger(),
            AntiMiningFatigue(),
            AntiPoison(),
            AntiWeakness(),
            AutoArmor(),
            NoFallDamage(),
            NoSlowdown(),

            // World
            AutoSign(),

            // Misc
            AntiAFK(),
            AutoCommand(),
            ChatSpammer(),
            ChatSuffixModule(),
            PopCounter(),
            Spammer()
        )
    }
}
