package com.noxnoclient.module.visual

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.module.BaseModule
import com.noxnoclient.module.ModuleCategory
import com.noxnoclient.utils.HudAnchor
import com.noxnoclient.utils.HudPosition
import com.noxnoclient.utils.InventoryUtil
import com.noxnoclient.utils.UiUtil
import org.cloudburstmc.protocol.bedrock.data.inventory.ItemData

class ArmorHud : BaseModule(
    name        = "ArmorHud",
    category    = ModuleCategory.VISUAL,
    description = "Shows your currently worn armor pieces using their real item icons"
) {
    private val anchor    = enum ("Anchor",     HudAnchor.BottomLeft)
    private val offsetX   = float("Offset X",   12f, 0f, 800f)
    private val offsetY   = float("Offset Y",   12f, 0f, 800f)
    private val iconSize  = float("Icon Size",  40f, 24f, 96f)
    private val vertical  = bool ("Vertical Layout", false)
    private val shortcut  = bool ("Shortcut", false)

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(120, 0, 0, 0) }
    private val placeholderFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val placeholderStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2f }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 20f; textAlign = Paint.Align.CENTER
        typeface = android.graphics.Typeface.DEFAULT_BOLD
    }
    private val rect = RectF()

    companion object {
        // Bedrock armor container: 0=helmet, 1=chestplate, 2=leggings, 3=boots
        private val SLOTS = intArrayOf(0, 1, 2, 3)
        private val SLOT_LETTER = mapOf(0 to "H", 1 to "C", 2 to "L", 3 to "B")
    }

    private fun placeholderColor(identifier: String?): Int {
        if (identifier.isNullOrBlank()) return Color.argb(60, 255, 255, 255)
        val material = identifier.removePrefix("minecraft:").substringBefore("_")
        return when (material) {
            "leather"    -> Color.rgb(150, 100, 60)
            "golden"     -> Color.rgb(255, 215, 0)
            "chainmail"  -> Color.rgb(150, 150, 160)
            "iron"       -> Color.rgb(210, 210, 210)
            "diamond"    -> Color.rgb(80, 220, 220)
            "netherite"  -> Color.rgb(90, 70, 70)
            "turtle"     -> Color.rgb(60, 180, 90)
            else         -> Color.argb(60, 255, 255, 255)
        }
    }

    fun render(canvas: Canvas, screenW: Int, screenH: Int) {
        if (!isEnabled) return

        val size = iconSize.value
        val gap = 6f
        val count = SLOTS.size
        val totalW = if (vertical.value) size else size * count + gap * (count - 1)
        val totalH = if (vertical.value) size * count + gap * (count - 1) else size

        val (px, py) = HudPosition.resolve(anchor.value, offsetX.value, offsetY.value, totalW, totalH, screenW, screenH)

        rect.set(px - 6f, py - 6f, px + totalW + 6f, py + totalH + 6f)
        canvas.drawRoundRect(rect, 8f, 8f, bgPaint)

        for ((i, slot) in SLOTS.withIndex()) {
            val cx = if (vertical.value) px else px + i * (size + gap)
            val cy = if (vertical.value) py + i * (size + gap) else py

            val item: ItemData? = EntityTracker.getArmorItem(slot)
            val identifier = item?.let { InventoryUtil.resolveIdentifier(it) }
            val icon = UiUtil.getIcon(identifier)

            rect.set(cx, cy, cx + size, cy + size)

            if (icon != null) {
                val src = Rect(0, 0, icon.width, icon.height)
                canvas.drawBitmap(icon, src, rect, null)
            } else {
                placeholderFill.color = placeholderColor(identifier)
                placeholderStroke.color = Color.argb(200, 255, 255, 255)
                canvas.drawRoundRect(rect, 4f, 4f, placeholderFill)
                canvas.drawRoundRect(rect, 4f, 4f, placeholderStroke)
                canvas.drawText(SLOT_LETTER[slot] ?: "?", cx + size / 2f, cy + size / 2f + 7f, labelPaint)
            }
        }
    }
}
