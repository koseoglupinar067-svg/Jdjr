package com.noxnoclient.module.player

import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.events.PacketEvent
import com.noxnoclient.module.BaseModule
import com.noxnoclient.module.ModuleCategory
import org.cloudburstmc.protocol.bedrock.packet.MobEffectPacket

class AntiPoison : BaseModule(
    name        = "AntiPoison",
    category    = ModuleCategory.PLAYER,
    description = "Zehir efektini (Poison) engeller"
) {
    companion object { private const val EFFECT_POISON = 19 }

    override fun onPacket(event: PacketEvent) {
        if (!isEnabled) return
        if (event.direction != PacketEvent.Direction.SERVER_TO_CLIENT) return
        val pkt = event.packet as? MobEffectPacket ?: return
        if (pkt.runtimeEntityId != EntityTracker.selfRuntimeId) return
        if (pkt.effectId != EFFECT_POISON) return
        if (pkt.event == MobEffectPacket.Event.ADD || pkt.event == MobEffectPacket.Event.MODIFY) {
            event.cancel()
        }
    }
}
