package com.noxnoclient.module.visual

import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.events.PacketEventBus
import com.noxnoclient.module.BaseModule
import com.noxnoclient.module.ModuleCategory
import org.cloudburstmc.protocol.bedrock.packet.MobEffectPacket

class FullBright : BaseModule(
    name        = "FullBright",
    category    = ModuleCategory.VISUAL,
    description = "Client-side night vision so everything looks fully lit"
) {
    companion object {
        private const val EFFECT_NIGHT_VISION = 16
        private const val REFRESH_MS = 3000L
        private const val DURATION_TICKS = 999999
    }

    private val amplifier = int ("Amplifier", 0, 0, 1)
    private val shortcut  = bool("Shortcut", false)

    private var job: kotlinx.coroutines.Job? = null

    override fun onEnable() {
        super.onEnable()
        job = launchTickLoop(REFRESH_MS) { applyNightVision() }
    }

    override fun onDisable() {
        job?.cancel()
        job = null
        removeNightVision()
        super.onDisable()
    }

    private fun applyNightVision() {
        val session = PacketEventBus.currentSession ?: return
        session.clientBound(MobEffectPacket().apply {
            runtimeEntityId = EntityTracker.selfRuntimeId
            event           = MobEffectPacket.Event.ADD
            effectId        = EFFECT_NIGHT_VISION
            amplifier       = this@FullBright.amplifier.value
            isParticles     = false
            duration        = DURATION_TICKS
        })
    }

    private fun removeNightVision() {
        val session = PacketEventBus.currentSession ?: return
        session.clientBound(MobEffectPacket().apply {
            runtimeEntityId = EntityTracker.selfRuntimeId
            event           = MobEffectPacket.Event.REMOVE
            effectId        = EFFECT_NIGHT_VISION
        })
    }
}
