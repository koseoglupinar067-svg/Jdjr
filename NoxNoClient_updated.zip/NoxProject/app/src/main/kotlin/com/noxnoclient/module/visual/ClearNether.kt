package com.noxnoclient.module.visual

import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.events.PacketEventBus
import com.noxnoclient.module.BaseModule
import com.noxnoclient.module.ModuleCategory
import org.cloudburstmc.protocol.bedrock.packet.PlayerFogPacket

class ClearNether : BaseModule(
    name        = "ClearNether",
    category    = ModuleCategory.VISUAL,
    description = "Continuously strips the Nether's fog/haze while you're in it"
) {

    private val refreshMs = int ("Refresh (ms)", 500, 100, 3000)
    private val shortcut  = bool("Shortcut", false)

    private var job: kotlinx.coroutines.Job? = null

    override fun onEnable() {
        super.onEnable()
        job = launchTickLoop(refreshMs.value.toLong()) { tick() }
    }

    override fun onDisable() {
        job?.cancel()
        job = null
        super.onDisable()
    }

    private fun tick() {
        if (EntityTracker.selfDimension != 1) return
        val session = PacketEventBus.currentSession ?: return
        session.clientBound(PlayerFogPacket())
    }
}
