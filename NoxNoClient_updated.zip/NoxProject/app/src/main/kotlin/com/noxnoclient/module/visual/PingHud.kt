package com.noxnoclient.module.visual

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.module.BaseModule
import com.noxnoclient.module.ModuleCategory
import com.noxnoclient.utils.HudAnchor
import com.noxnoclient.utils.HudPosition

class PingHud : BaseModule(
    name        = "PingHud",
    category    = ModuleCategory.VISUAL,
    description = "Shows your current ping with no background"
) {
    private val anchor   = enum ("Anchor",   HudAnchor.TopRight)
    private val offsetX  = float("Offset X", 12f, 0f, 800f)
    private val offsetY  = float("Offset Y", 12f, 0f, 800f)
    private val colorize = bool ("Colorize", true)
    private val shortcut = bool ("Shortcut", false)

    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 26f
        typeface = android.graphics.Typeface.DEFAULT_BOLD
        setShadowLayer(3f, 1f, 1f, Color.BLACK)
    }

    private fun colorFor(ping: Int): Int = when {
        ping <= 80  -> Color.rgb(80, 230, 100)
        ping <= 150 -> Color.rgb(255, 200, 40)
        else        -> Color.rgb(255, 70, 70)
    }

    fun render(canvas: Canvas, screenW: Int, screenH: Int) {
        if (!isEnabled) return
        val ping = EntityTracker.selfPingMs
        val text = "$ping ms"
        val w = textPaint.measureText(text)
        val h = textPaint.textSize

        val (px, py) = HudPosition.resolve(anchor.value, offsetX.value, offsetY.value, w, h, screenW, screenH)

        textPaint.color = if (colorize.value) colorFor(ping) else Color.WHITE
        canvas.drawText(text, px, py + h, textPaint)
    }
}
