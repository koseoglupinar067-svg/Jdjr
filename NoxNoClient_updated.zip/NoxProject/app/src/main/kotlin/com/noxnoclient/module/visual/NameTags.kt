package com.noxnoclient.module.visual

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.events.PacketEvent
import com.noxnoclient.module.BaseModule
import com.noxnoclient.module.ModuleCategory
import com.noxnoclient.module.social.isFriendEntity
import com.noxnoclient.utils.MathUtil
import com.noxnoclient.utils.UiUtil

/**
 * NameTags — tüm oyuncuların üzerinde isim etiketi gösterir.
 * PlayerESP'in isim kısmından bağımsız olarak çalışır.
 */
class NameTags : BaseModule(
    name        = "NameTags",
    category    = ModuleCategory.VISUAL,
    description = "Tüm oyuncuların üzerinde isim etiketi gösterir"
) {
    private val range       = float("Range",      128f, 8f, 256f)
    private val showHealth  = bool ("Health",     true)
    private val showDist    = bool ("Distance",   true)
    private val showPing    = bool ("Ping",        false)
    private val bgOpacity   = int  ("BG Opacity",  160, 0, 255)

    private val bgPaint   = Paint().apply { style = Paint.Style.FILL; isAntiAlias = true }
    private val textPaint = Paint().apply {
        isAntiAlias = true; textSize = 28f; textAlign = Paint.Align.CENTER; isFakeBoldText = true
        setShadowLayer(3f, 0f, 0f, Color.BLACK)
    }
    private val healthPaint = Paint().apply {
        isAntiAlias = true; textSize = 22f; textAlign = Paint.Align.CENTER
        setShadowLayer(2f, 0f, 0f, Color.BLACK)
    }

    override fun onPacket(event: PacketEvent) {}

    fun render(canvas: Canvas, screenW: Int, screenH: Int) {
        if (!isEnabled) return
        val selfX = EntityTracker.selfX; val selfY = EntityTracker.selfY; val selfZ = EntityTracker.selfZ
        val yaw = EntityTracker.selfYaw; val pitch = EntityTracker.selfPitch
        val fov = UiUtil.currentFov
        val r = range.value

        val targets = EntityTracker.getEntitiesInRange(r) {
            it.isPlayer && it.runtimeId != EntityTracker.selfRuntimeId && !it.isInvisible
        }

        for (t in targets) {
            val dist = MathUtil.dist3(t.x, t.y, t.z, selfX, selfY, selfZ)
            // Project above head
            val screenPt = MathUtil.worldToScreen(t.x, t.y + 2.1f, t.z, selfX, selfY, selfZ, yaw, pitch, screenW, screenH, fov) ?: continue

            val isFriend = t.isFriendEntity
            val nameColor = if (isFriend) Color.rgb(80, 240, 120) else Color.WHITE

            // Build label
            val name = t.name.ifBlank { "Player" }
            val sb = StringBuilder(name)
            if (showDist.value)   sb.append(" §7${dist.toInt()}m")
            if (showPing.value)   sb.append(" §b${t.pingMs}ms")

            val label = sb.toString()
            val textW = textPaint.measureText(label)
            val pad = 8f

            // Background rect
            val bgOpA = bgOpacity.value
            bgPaint.color = Color.argb(bgOpA, 20, 20, 20)
            canvas.drawRoundRect(
                RectF(screenPt.first - textW / 2f - pad, screenPt.second - textPaint.textSize - pad * 0.5f,
                      screenPt.first + textW / 2f + pad, screenPt.second + pad * 0.5f),
                6f, 6f, bgPaint
            )

            // Name text
            textPaint.color = nameColor
            canvas.drawText(label, screenPt.first, screenPt.second, textPaint)

            // Health bar
            if (showHealth.value) {
                val hp = t.healthPercent.coerceIn(0f, 1f)
                val hpColor = when {
                    hp > 0.6f -> Color.rgb(80, 220, 80)
                    hp > 0.3f -> Color.rgb(240, 200, 60)
                    else      -> Color.rgb(220, 60, 60)
                }
                healthPaint.color = hpColor
                canvas.drawText("%.1f♥".format(t.health), screenPt.first, screenPt.second + textPaint.textSize + 2f, healthPaint)
            }
        }
    }
}
