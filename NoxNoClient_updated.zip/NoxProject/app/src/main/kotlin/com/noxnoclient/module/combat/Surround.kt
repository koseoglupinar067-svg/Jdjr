package com.noxnoclient.module.combat

import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.events.PacketEvent
import com.noxnoclient.events.PacketEventBus
import com.noxnoclient.module.BaseModule
import com.noxnoclient.module.ModuleCategory
import com.noxnoclient.utils.InventoryUtil
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.cloudburstmc.math.vector.Vector3i

/** Surround — places obsidian on all 4 horizontal sides of the player extremely fast. */
class Surround : BaseModule(
    name        = "Surround",
    category    = ModuleCategory.COMBAT,
    description = "Places obsidian on all 4 sides of yourself quickly"
) {
    private val blockDelay = int  ("Block Delay (ms)", 20, 0, 150)
    private val shortcut   = bool ("Shortcut", false)

    private val BLOCK_ID = "minecraft:obsidian"

    // Just the 4 horizontal faces at feet level
    private val SIDE_OFFSETS = listOf(
        Triple( 0, 0, -1),
        Triple( 0, 0,  1),
        Triple( 1, 0,  0),
        Triple(-1, 0,  0)
    )

    private var surroundJob: Job? = null

    override fun onEnable() {
        super.onEnable()
        surroundJob = scope.launch { runSurround() }
    }

    override fun onDisable() {
        surroundJob?.cancel(); surroundJob = null
        super.onDisable()
    }

    override fun onPacket(event: PacketEvent) {}

    private suspend fun runSurround() {
        val session = PacketEventBus.currentSession ?: return
        val obsidianSlot = findObsidianInHotbar() ?: run { setEnabled(false); return }
        val originalSlot = EntityTracker.selfHotbarSlot

        InventoryUtil.sendHotbarSelect(session, obsidianSlot)
        EntityTracker.selfHotbarSlot = obsidianSlot

        val sx = EntityTracker.selfX.toInt()
        val sy = EntityTracker.selfY.toInt()
        val sz = EntityTracker.selfZ.toInt()

        for ((dx, dy, dz) in SIDE_OFFSETS) {
            val bx = sx + dx; val by = sy + dy; val bz = sz + dz

            val neighbor = InventoryUtil.findClickableNeighbor(bx, by, bz) ?: continue
            val (_, adjId, face) = neighbor
            val item = EntityTracker.getInventoryItem(obsidianSlot) ?: break
            if (item.count <= 0) break

            val prepared = InventoryUtil.PreparedItem(obsidianSlot, item, null)
            InventoryUtil.sendPlacementUseRaw(
                session, prepared,
                Vector3i.from(bx, by, bz), adjId, face
            )
            delay(blockDelay.value.toLong())
        }

        InventoryUtil.sendHotbarSelect(session, originalSlot)
        EntityTracker.selfHotbarSlot = originalSlot
        setEnabled(false)
    }

    private fun findObsidianInHotbar(): Int? {
        for (slot in 0..8) {
            val item = EntityTracker.getInventoryItem(slot) ?: continue
            if (item.count <= 0) continue
            val id = InventoryUtil.resolveIdentifier(item) ?: continue
            if (id == BLOCK_ID) return slot
        }
        return null
    }
}
