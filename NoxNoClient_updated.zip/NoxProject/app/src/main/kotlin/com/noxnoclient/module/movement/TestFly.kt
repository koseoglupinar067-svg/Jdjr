package com.noxnoclient.module.movement

import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.events.PacketEvent
import com.noxnoclient.module.BaseModule
import com.noxnoclient.module.ModuleCategory
import org.cloudburstmc.math.vector.Vector3f
import org.cloudburstmc.protocol.bedrock.data.PlayerAuthInputData
import org.cloudburstmc.protocol.bedrock.packet.PlayerAuthInputPacket
import kotlin.math.cos
import kotlin.math.sin

/**
 * TestFly — HvH anarchy için geliştirilmiş fly modülü.
 * PlayerAuthInput paketlerini yakalar ve pozisyonu tutar.
 */
class TestFly : BaseModule(
    name        = "TestFly",
    category    = ModuleCategory.MOVEMENT,
    description = "HvH anarchy için geliştirilen güçlü fly modülü"
) {
    private val speed      = float("Speed",   1.0f, 0.1f, 10.0f)
    private val vertSpeed  = float("VSpeed",  0.5f, 0.1f, 5.0f)
    private val glide      = bool ("Glide",   false)
    private val noClip     = bool ("NoClip",  false)

    @Volatile private var flyY = 0f
    @Volatile private var initialized = false

    override fun onEnable() {
        super.onEnable()
        flyY = EntityTracker.selfY
        initialized = true
    }

    override fun onDisable() {
        initialized = false
        super.onDisable()
    }

    override fun onPacket(event: PacketEvent) {
        if (!isEnabled || !initialized) return
        if (event.direction != PacketEvent.Direction.CLIENT_TO_SERVER) return
        val pkt = event.packet as? PlayerAuthInputPacket ?: return

        val yaw  = Math.toRadians(EntityTracker.selfYaw.toDouble())
        val s    = speed.value
        val vs   = vertSpeed.value

        val forward = pkt.inputData.contains(PlayerAuthInputData.UP)
        val back    = pkt.inputData.contains(PlayerAuthInputData.DOWN)
        val left    = pkt.inputData.contains(PlayerAuthInputData.LEFT)
        val right   = pkt.inputData.contains(PlayerAuthInputData.RIGHT)
        val jump    = pkt.inputData.contains(PlayerAuthInputData.JUMPING) ||
                      pkt.inputData.contains(PlayerAuthInputData.JUMP_DOWN)
        val sneak   = pkt.inputData.contains(PlayerAuthInputData.SNEAKING)

        var newX = pkt.position.x
        var newZ = pkt.position.z

        if (forward) { newX -= (sin(yaw) * s).toFloat(); newZ += (cos(yaw) * s).toFloat() }
        if (back)    { newX += (sin(yaw) * s).toFloat(); newZ -= (cos(yaw) * s).toFloat() }
        if (left)    { newX -= (cos(yaw) * s).toFloat(); newZ -= (sin(yaw) * s).toFloat() }
        if (right)   { newX += (cos(yaw) * s).toFloat(); newZ += (sin(yaw) * s).toFloat() }

        if (jump)    flyY += vs
        if (sneak)   flyY -= vs
        if (!jump && !sneak && glide.value) flyY -= 0.02f // hafif glide

        val finalY = if (noClip.value) flyY else flyY.coerceAtLeast(-64f)

        val newPkt = PlayerAuthInputPacket().apply {
            position           = Vector3f.from(newX, finalY, newZ)
            rotation           = pkt.rotation
            yHeadRotation      = pkt.yHeadRotation
            inputData          = pkt.inputData
            inputMode          = pkt.inputMode
            playMode           = pkt.playMode
            interactRotation   = pkt.interactRotation
            tick               = pkt.tick
            delta              = pkt.delta
            motionPredictionHints = pkt.motionPredictionHints
        }
        event.cancelAndReplace(newPkt)
    }
}
