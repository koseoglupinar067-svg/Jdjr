package com.noxnoclient.module.visual

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import com.noxnoclient.module.BaseModule
import com.noxnoclient.module.ModuleCategory
import com.noxnoclient.utils.HudAnchor
import com.noxnoclient.utils.HudPosition

class FpsHud : BaseModule(
    name        = "FpsHud",
    category    = ModuleCategory.VISUAL,
    description = "Shows the overlay's observed frame rate (device compositor rate)"
) {
    private val anchor   = enum ("Anchor",   HudAnchor.TopRight)
    private val offsetX  = float("Offset X", 12f, 0f, 800f)
    private val offsetY  = float("Offset Y", 80f, 0f, 800f)
    private val shortcut = bool ("Shortcut", false)

    private var frameCount = 0
    private var windowStartMs = 0L
    @Volatile private var lastFps = 0

    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 26f
        typeface = android.graphics.Typeface.DEFAULT_BOLD
        setShadowLayer(3f, 1f, 1f, Color.BLACK)
    }

    fun render(canvas: Canvas, screenW: Int, screenH: Int) {
        if (!isEnabled) return

        val now = System.currentTimeMillis()
        if (windowStartMs == 0L) windowStartMs = now
        frameCount++
        if (now - windowStartMs >= 1000L) {
            lastFps = frameCount
            frameCount = 0
            windowStartMs = now
        }

        val text = "$lastFps FPS"
        val w = textPaint.measureText(text)
        val h = textPaint.textSize
        val (px, py) = HudPosition.resolve(anchor.value, offsetX.value, offsetY.value, w, h, screenW, screenH)
        canvas.drawText(text, px, py + h, textPaint)
    }
}
