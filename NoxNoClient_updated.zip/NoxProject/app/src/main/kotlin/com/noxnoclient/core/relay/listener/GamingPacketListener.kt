package com.noxnoclient.core.relay.listener

import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.core.relay.ConnectionManager
import com.noxnoclient.core.relay.Definitions
import com.noxnoclient.core.relay.NoxNoRelaySession
import com.noxnoclient.utils.WorldBlockTracker
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancelChildren
import kotlinx.coroutines.launch
import org.cloudburstmc.protocol.bedrock.data.definitions.ItemDefinition
import org.cloudburstmc.protocol.bedrock.data.definitions.SimpleNamedDefinition
import org.cloudburstmc.protocol.bedrock.data.inventory.ItemData
import org.cloudburstmc.protocol.bedrock.packet.*
import org.cloudburstmc.protocol.common.NamedDefinition
import org.cloudburstmc.protocol.common.SimpleDefinitionRegistry

class GamingPacketListener : NoxNoPacketListener {

    companion object {
        private const val TAG = "GamingPacketListener"
    }

    override val priority: Int = 100

    @Volatile private var active = false

    private val itemDefMap = LinkedHashMap<Int, ItemDefinition>()
    private val itemDefSource = HashMap<Int, Int>()

    private fun mergeItemDefs(defs: Collection<ItemDefinition>, session: NoxNoRelaySession, priority: Int) {
        var changed = false
        for (def in defs) {
            val existingPriority = itemDefSource[def.runtimeId]
            if (existingPriority == null || priority >= existingPriority) {
                itemDefMap[def.runtimeId] = def
                itemDefSource[def.runtimeId] = priority
                changed = true
            }
        }
        if (!changed) return
        val registry = SimpleDefinitionRegistry.builder<ItemDefinition>()
            .addAll(itemDefMap.values)
            .build()
        session.clientSession.peer.codecHelper.itemDefinitions = registry
        session.serverSession?.peer?.codecHelper?.itemDefinitions = registry
    }

    private val parserScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onSessionStart(session: NoxNoRelaySession) {
        active = true
        itemDefMap.clear()
        itemDefSource.clear()
        WorldBlockTracker.reset()
        WorldBlockTracker.init()
    }

    override fun onSessionEnd(session: NoxNoRelaySession) {
        active = false
        EntityTracker.reset()
        WorldBlockTracker.reset()
        parserScope.coroutineContext[Job]?.cancelChildren()
    }

    override fun onClientPacket(packet: BedrockPacket, session: NoxNoRelaySession): Boolean {
        if (!active) return true
        when (packet) {
            is ClientCacheStatusPacket -> {
                packet.isSupported = false
                return true
            }
            is MovePlayerPacket          -> { }
            is PlayerAuthInputPacket     -> { }
            is PlayerActionPacket        -> { }
            is InteractPacket            -> { }
            is InventoryTransactionPacket-> { }
            is CommandRequestPacket      -> { }
            is TextPacket                -> { }
            is AnimatePacket             -> { }
            is DisconnectPacket          -> { }
        }
        return true
    }

    override fun onServerPacket(packet: BedrockPacket, session: NoxNoRelaySession): Boolean {
        if (!active) return true
        when (packet) {

            is StartGamePacket -> {
                applyStartGameDefinitions(packet, session)
                ConnectionManager.onGameStarted()
            }

            is UpdateBlockPacket -> { }
            is BlockEntityDataPacket -> { }
            is LevelChunkPacket -> handleChunk(packet)

            is CameraPresetsPacket -> {
                applyCameraDefinitions(packet, session)
            }

            is ItemComponentPacket -> {
                applyItemComponents(packet, session)
            }

            is CreativeContentPacket -> {
                applyCreativeItemDefinitions(packet, session)
            }

            is AddPlayerPacket          -> { }
            is AddEntityPacket          -> { }
            is RemoveEntityPacket       -> { }
            is MoveEntityAbsolutePacket -> { }
            is MovePlayerPacket         -> { }

            is RespawnPacket          -> { }
            is SetHealthPacket        -> { }
            is UpdateAttributesPacket -> { }
            is PlayerListPacket       -> { }
            is ChangeDimensionPacket  -> { }
            is TextPacket             -> { }
            is DisconnectPacket       -> { }

            is TransferPacket -> {
                val newHost = packet.address
                val newPort = packet.port

                try {
                    session.relay.updateRemoteTarget(newHost, newPort)

                    val clientReconnectHost = (session.clientSession.peer.channel.localAddress()
                        as? java.net.InetSocketAddress)?.address?.hostAddress
                        ?: "127.0.0.1"

                    session.sendToClient(TransferPacket().apply {
                        address = clientReconnectHost
                        port    = session.relay.boundLocalPort
                    })
                } catch (e: Exception) {
                }

                return false
            }
        }
        return true
    }

    private fun handleChunk(pkt: LevelChunkPacket) {
        WorldBlockTracker.handleLevelChunkPacket(pkt)
    }

    private fun applyStartGameDefinitions(packet: StartGamePacket, session: NoxNoRelaySession) {
        try {
            if (packet.itemDefinitions.isNotEmpty()) {
                mergeItemDefs(packet.itemDefinitions, session, priority = 0)
            }
        } catch (e: Exception) {
        }

        try {
            val protocolVersion = session.activeCodec.protocolVersion
            val defs = Definitions.getClosestDefinitions(protocolVersion)

            val correctRegistry = if (packet.isBlockNetworkIdsHashed) {
                defs.blockDefinitionsHashed
            } else {
                defs.blockDefinitions
            }

            session.clientSession.peer.codecHelper.blockDefinitions = correctRegistry
            session.serverSession?.peer?.codecHelper?.blockDefinitions = correctRegistry
        } catch (e: Exception) {
        }
    }

    private fun applyItemComponents(packet: ItemComponentPacket, session: NoxNoRelaySession) {
        try {
            val items = packet.items
            if (items.isEmpty()) {
                return
            }

            mergeItemDefs(items, session, priority = 2)
        } catch (e: Exception) {
        }
    }

    private fun applyCreativeItemDefinitions(packet: CreativeContentPacket, session: NoxNoRelaySession) {
        try {
            val contents = packet.contents
            if (contents.isEmpty()) {
                return
            }

            val byRuntimeId = LinkedHashMap<Int, ItemDefinition>()
            for (creativeItem in contents) {
                val itemData = creativeItem.item
                val def = runCatching { itemData.definition }.getOrNull()
                if (def == null) continue
                val identifier = def.identifier
                if (identifier.isNullOrBlank()) continue
                if (identifier == "minecraft:air") continue
                byRuntimeId.putIfAbsent(def.runtimeId, def)
            }

            if (byRuntimeId.isEmpty()) {
                return
            }

            mergeItemDefs(byRuntimeId.values, session, priority = 1)
        } catch (e: Exception) {
        }
    }

    private fun applyCameraDefinitions(packet: CameraPresetsPacket, session: NoxNoRelaySession) {
        try {
            val cameraDefs = SimpleDefinitionRegistry.builder<NamedDefinition>()
                .addAll(
                    packet.presets.mapIndexed { i, preset ->
                        SimpleNamedDefinition(preset.identifier, i)
                    }
                )
                .build()

            session.clientSession.peer.codecHelper.cameraPresetDefinitions = cameraDefs
            session.serverSession?.peer?.codecHelper?.cameraPresetDefinitions = cameraDefs
        } catch (e: Exception) {
        }
    }
}
