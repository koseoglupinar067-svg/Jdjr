package com.noxnoclient.module.misc

object InternalChat {
    const val MARKER = "__noxno_internal__"
}
