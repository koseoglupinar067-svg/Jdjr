package com.noxnoclient.module.visual

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.module.BaseModule
import com.noxnoclient.module.ModuleCategory
import com.noxnoclient.utils.MathUtil
import com.noxnoclient.utils.UiUtil

/**
 * ESP for non-player mobs: hostiles (zombies, skeletons, creepers, etc.) are colour-coded
 * separately from passive/animal mobs so you can tell threats apart from farmable mobs at
 * a glance. Uses the same perspective-correct 8-corner box projection as PlayerESP.
 */
class MobESP : BaseModule(
    name        = "MobESP",
    category    = ModuleCategory.VISUAL,
    description = "Canavarlar ve hayvanlar için kutu, can barı ve mesafe gösterir"
) {
    private val range          = float("Range",         96f, 8f, 256f)
    private val box            = bool ("Box",            true)
    private val fill           = bool ("Fill",           true)
    private val healthBar      = bool ("Health Bar",     true)
    private val nameTag        = bool ("Name",           true)
    private val distanceTag    = bool ("Distance",       true)
    private val hostileOnly    = bool ("Hostile Only",   false)
    private val distanceFade   = bool ("Distance Fade",  true)

    companion object {
        private const val HALF_WIDTH = 0.4f
        private const val HEIGHT     = 1.4f
        private val HOSTILE_COLOR = Color.rgb(230, 60, 60)
        private val PASSIVE_COLOR = Color.rgb(90, 200, 110)
    }

    private val boxPaint = Paint().apply { style = Paint.Style.STROKE; strokeWidth = 3f; isAntiAlias = true }
    private val fillPaint = Paint().apply { style = Paint.Style.FILL; isAntiAlias = true }
    private val textPaint = Paint().apply {
        isAntiAlias = true; textSize = 26f; textAlign = Paint.Align.CENTER
        setShadowLayer(3f, 0f, 0f, Color.BLACK)
    }
    private val hpBg = Paint().apply { color = Color.argb(180, 20, 20, 20); style = Paint.Style.FILL }
    private val hpFg = Paint().apply { style = Paint.Style.FILL }

    fun render(canvas: Canvas, screenW: Int, screenH: Int) {
        val selfX = EntityTracker.selfX; val selfY = EntityTracker.selfY; val selfZ = EntityTracker.selfZ
        val yaw = EntityTracker.selfYaw; val pitch = EntityTracker.selfPitch
        val fov = UiUtil.currentFov

        val targets = EntityTracker.getEntitiesInRange(range.value) {
            (it.type == EntityTracker.EntityType.MONSTER ||
             it.type == EntityTracker.EntityType.ANIMAL ||
             it.type == EntityTracker.EntityType.PASSIVE) && !it.isInvisible
        }
        if (targets.isEmpty()) return

        for (t in targets) {
            val hostile = t.type == EntityTracker.EntityType.MONSTER
            if (hostileOnly.value && !hostile) continue

            val dist = MathUtil.dist3(t.x, t.y, t.z, selfX, selfY, selfZ)
            val alpha = if (distanceFade.value) fadeAlpha(dist, range.value) else 255

            val rect = projectBox(t, selfX, selfY, selfZ, yaw, pitch, screenW, screenH, fov) ?: continue
            val color = if (hostile) HOSTILE_COLOR else PASSIVE_COLOR

            if (box.value) {
                if (fill.value) {
                    fillPaint.color = Color.argb((alpha * 0.14f).toInt(), Color.red(color), Color.green(color), Color.blue(color))
                    canvas.drawRect(rect, fillPaint)
                }
                boxPaint.color = Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color))
                canvas.drawRect(rect, boxPaint)
            }

            if (healthBar.value) drawHealthBar(canvas, rect, t.healthPercent, alpha)

            if (nameTag.value || distanceTag.value) {
                val mobName = t.identifier.removePrefix("minecraft:").replace('_', ' ')
                    .replaceFirstChar { it.uppercase() }
                val label = when {
                    nameTag.value && distanceTag.value -> "$mobName (${dist.toInt()}m)"
                    nameTag.value -> mobName
                    else -> "${dist.toInt()}m"
                }
                textPaint.color = Color.argb(alpha, 255, 255, 255)
                canvas.drawText(label, rect.centerX(), rect.top - 8f, textPaint)
            }
        }
    }

    private fun fadeAlpha(dist: Float, range: Float): Int {
        val t = (1f - (dist / range)).coerceIn(0.35f, 1f)
        return (255 * t).toInt()
    }

    private fun drawHealthBar(canvas: Canvas, rect: RectF, pct: Float, alpha: Int) {
        val barW = 5f
        val barX = rect.left - barW - 4f
        hpBg.alpha = (alpha * 0.7f).toInt()
        canvas.drawRect(barX, rect.top, barX + barW, rect.bottom, hpBg)
        val fillTop = rect.bottom - (rect.height() * pct.coerceIn(0f, 1f))
        hpFg.color = Color.rgb((255 * (1f - pct)).toInt(), (200 * pct).toInt(), 40)
        hpFg.alpha = alpha
        canvas.drawRect(barX, fillTop, barX + barW, rect.bottom, hpFg)
    }

    private fun projectBox(
        t: EntityTracker.TrackedEntity,
        selfX: Float, selfY: Float, selfZ: Float,
        yaw: Float, pitch: Float,
        screenW: Int, screenH: Int, fov: Float
    ): RectF? {
        val hw = HALF_WIDTH
        val h  = HEIGHT
        val corners = arrayOf(
            floatArrayOf(t.x - hw, t.y,     t.z - hw), floatArrayOf(t.x + hw, t.y,     t.z - hw),
            floatArrayOf(t.x - hw, t.y,     t.z + hw), floatArrayOf(t.x + hw, t.y,     t.z + hw),
            floatArrayOf(t.x - hw, t.y + h, t.z - hw), floatArrayOf(t.x + hw, t.y + h, t.z - hw),
            floatArrayOf(t.x - hw, t.y + h, t.z + hw), floatArrayOf(t.x + hw, t.y + h, t.z + hw)
        )

        var minX = Float.MAX_VALUE; var maxX = -Float.MAX_VALUE
        var minY = Float.MAX_VALUE; var maxY = -Float.MAX_VALUE
        var hits = 0

        for (c in corners) {
            val s = MathUtil.worldToScreen(c[0], c[1], c[2], selfX, selfY, selfZ, yaw, pitch, screenW, screenH, fov) ?: continue
            hits++
            if (s.first < minX) minX = s.first
            if (s.first > maxX) maxX = s.first
            if (s.second < minY) minY = s.second
            if (s.second > maxY) maxY = s.second
        }

        if (hits < 4) return null
        if (maxX < -50 || minX > screenW + 50 || maxY < -50 || minY > screenH + 50) return null
        return RectF(minX, minY, maxX, maxY)
    }
}
