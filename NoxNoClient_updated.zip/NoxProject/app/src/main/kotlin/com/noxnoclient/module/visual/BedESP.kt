package com.noxnoclient.module.visual

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.events.PacketEvent
import com.noxnoclient.module.BaseModule
import com.noxnoclient.module.ModuleCategory
import com.noxnoclient.utils.MathUtil
import com.noxnoclient.utils.UiUtil
import org.cloudburstmc.protocol.bedrock.packet.UpdateBlockPacket
import java.util.concurrent.ConcurrentHashMap

class BedESP : BaseModule(
    name        = "BedESP",
    category    = ModuleCategory.VISUAL,
    description = "Krovatlı bloklarını vurgular — HvH için yatak konumlarını gösterir"
) {
    private val range     = float("Range",     96f, 8f, 256f)
    private val fill      = bool ("Fill",      true)
    private val showLabel = bool ("Label",     true)
    private val showDist  = bool ("Distance",  true)

    companion object {
        private val BED_IDENTIFIERS = setOf(
            "minecraft:red_bed", "minecraft:white_bed", "minecraft:orange_bed",
            "minecraft:magenta_bed", "minecraft:light_blue_bed", "minecraft:yellow_bed",
            "minecraft:lime_bed", "minecraft:pink_bed", "minecraft:gray_bed",
            "minecraft:light_gray_bed", "minecraft:cyan_bed", "minecraft:purple_bed",
            "minecraft:blue_bed", "minecraft:brown_bed", "minecraft:green_bed",
            "minecraft:black_bed", "minecraft:bed"
        )
    }

    private data class BedEntry(val x: Int, val y: Int, val z: Int)

    private val beds = ConcurrentHashMap<Long, BedEntry>()

    private val boxPaint  = Paint().apply { style = Paint.Style.STROKE; strokeWidth = 3f; isAntiAlias = true; color = Color.rgb(255, 80, 80) }
    private val fillPaint = Paint().apply { style = Paint.Style.FILL;   isAntiAlias = true }
    private val textPaint = Paint().apply {
        isAntiAlias = true; textSize = 26f; textAlign = Paint.Align.CENTER
        setShadowLayer(3f, 0f, 0f, Color.BLACK); color = Color.WHITE
    }

    override fun onEnable() { super.onEnable(); beds.clear() }
    override fun onDisable() { beds.clear(); super.onDisable() }

    override fun onPacket(event: PacketEvent) {
        if (!isEnabled) return
        if (event.direction != PacketEvent.Direction.SERVER_TO_CLIENT) return
        val pkt = event.packet as? UpdateBlockPacket ?: return
        val blockDef = pkt.definition ?: return
        val identifier = runCatching { blockDef.identifier ?: "" }.getOrElse { "" }
        val pos = pkt.blockPosition ?: return
        val key = (pos.x.toLong() shl 40) or (pos.y.toLong() shl 20) or pos.z.toLong()
        if (BED_IDENTIFIERS.any { identifier.contains(it.removePrefix("minecraft:"), ignoreCase = true) } ||
            identifier.contains("bed", ignoreCase = true)) {
            beds[key] = BedEntry(pos.x, pos.y, pos.z)
        } else {
            beds.remove(key)
        }
    }

    fun render(canvas: Canvas, screenW: Int, screenH: Int) {
        if (!isEnabled || beds.isEmpty()) return
        val selfX = EntityTracker.selfX; val selfY = EntityTracker.selfY; val selfZ = EntityTracker.selfZ
        val yaw = EntityTracker.selfYaw; val pitch = EntityTracker.selfPitch
        val fov = UiUtil.currentFov
        val r = range.value

        for (entry in beds.values) {
            val cx = entry.x + 0.5f; val cy = entry.y.toFloat(); val cz = entry.z + 0.5f
            val dist = MathUtil.dist3(cx, cy, cz, selfX, selfY, selfZ)
            if (dist > r) continue

            val screenPt = MathUtil.worldToScreen(cx, cy + 0.5f, cz, selfX, selfY, selfZ, yaw, pitch, screenW, screenH, fov) ?: continue

            val boxSize = (80f / (dist + 1f)).coerceIn(8f, 80f)
            val left   = screenPt.first - boxSize
            val top    = screenPt.second - boxSize
            val right  = screenPt.first + boxSize
            val bottom = screenPt.second + boxSize

            if (fill.value) {
                fillPaint.color = Color.argb(50, 255, 80, 80)
                canvas.drawRect(left, top, right, bottom, fillPaint)
            }
            canvas.drawRect(left, top, right, bottom, boxPaint)

            if (showLabel.value) {
                val label = if (showDist.value) "Bed (${dist.toInt()}m)" else "Bed"
                canvas.drawText(label, screenPt.first, top - 6f, textPaint)
            }
        }
    }
}
