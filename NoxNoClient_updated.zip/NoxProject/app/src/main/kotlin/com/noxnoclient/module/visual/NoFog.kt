package com.noxnoclient.module.visual

import com.noxnoclient.events.PacketEventBus
import com.noxnoclient.module.BaseModule
import com.noxnoclient.module.ModuleCategory
import org.cloudburstmc.protocol.bedrock.packet.PlayerFogPacket

class NoFog : BaseModule(
    name        = "NoFog",
    category    = ModuleCategory.VISUAL,
    description = "Clears all fog effects sent by the server"
) {
    private val refreshMs = int ("Refresh (ms)", 1000, 200, 5000)
    private val shortcut  = bool("Shortcut", false)

    private var job: kotlinx.coroutines.Job? = null

    override fun onEnable() {
        super.onEnable()
        job = launchTickLoop(refreshMs.value.toLong()) { clearFog() }
    }

    override fun onDisable() {
        job?.cancel()
        job = null
        super.onDisable()
    }

    private fun clearFog() {
        val session = PacketEventBus.currentSession ?: return
        session.clientBound(PlayerFogPacket())
    }
}
