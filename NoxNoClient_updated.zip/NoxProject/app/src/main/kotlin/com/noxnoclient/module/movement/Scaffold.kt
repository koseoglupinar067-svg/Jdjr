package com.noxnoclient.module.movement

import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.events.PacketEvent
import com.noxnoclient.events.PacketEventBus
import com.noxnoclient.module.BaseModule
import com.noxnoclient.module.ModuleCategory
import com.noxnoclient.utils.InventoryUtil
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.cloudburstmc.math.vector.Vector3f
import org.cloudburstmc.math.vector.Vector3i
import org.cloudburstmc.protocol.bedrock.packet.MovePlayerPacket
import org.cloudburstmc.protocol.bedrock.packet.PlayerAuthInputPacket

/**
 * Scaffold — continuously places the held block directly under the player.
 * Uses the item in hand; falls back to scanning hotbar for any placeable block.
 */
class Scaffold : BaseModule(
    name        = "Scaffold",
    category    = ModuleCategory.MOVEMENT,
    description = "Places block under you as you move (scaffold)"
) {
    private val delay    = int  ("Place Delay (ms)", 50, 0, 300)
    private val shortcut = bool ("Shortcut", false)

    private val NON_PLACEABLE = setOf(
        "minecraft:air", "minecraft:water", "minecraft:flowing_water",
        "minecraft:lava", "minecraft:flowing_lava",
        "minecraft:sword", "minecraft:pickaxe", "minecraft:axe",
        "minecraft:shovel", "minecraft:hoe", "minecraft:bow",
        "minecraft:crossbow", "minecraft:trident", "minecraft:shield"
    )

    private var scaffoldJob: Job? = null
    @Volatile private var lastX = 0f
    @Volatile private var lastZ = 0f

    override fun onEnable() {
        super.onEnable()
        lastX = EntityTracker.selfX; lastZ = EntityTracker.selfZ
        scaffoldJob = scope.launch { scaffoldLoop() }
    }

    override fun onDisable() {
        scaffoldJob?.cancel(); scaffoldJob = null
        super.onDisable()
    }

    override fun onPacket(event: PacketEvent) {
        if (!isEnabled) return
        // Update position from movement packets
        when (val pkt = event.packet) {
            is MovePlayerPacket ->
                if (pkt.runtimeEntityId == EntityTracker.selfRuntimeId &&
                    event.direction == PacketEvent.Direction.CLIENT_TO_SERVER) {
                    lastX = pkt.position.x; lastZ = pkt.position.z
                }
            is PlayerAuthInputPacket ->
                if (event.direction == PacketEvent.Direction.CLIENT_TO_SERVER) {
                    lastX = pkt.position.x; lastZ = pkt.position.z
                }
        }
    }

    private suspend fun scaffoldLoop() {
        while (isEnabled) {
            placeBlockUnder()
            delay(delay.value.toLong())
        }
    }

    private fun placeBlockUnder() {
        val session = PacketEventBus.currentSession ?: return

        val px = EntityTracker.selfX.toInt()
        val py = EntityTracker.selfY.toInt() - 1  // one below feet
        val pz = EntityTracker.selfZ.toInt()

        val heldItem = EntityTracker.getHeldItem()
        val heldId = if (heldItem != null && heldItem.count > 0)
            InventoryUtil.resolveIdentifier(heldItem) else null

        val isUsable = heldId != null && NON_PLACEABLE.none { heldId.contains(it.removePrefix("minecraft:")) }

        val (useSlot, useItem) = if (isUsable && heldItem != null) {
            EntityTracker.selfHotbarSlot to heldItem
        } else {
            // Scan hotbar for any placeable block
            var found: Pair<Int, org.cloudburstmc.protocol.bedrock.data.inventory.ItemData>? = null
            for (slot in 0..8) {
                val item = EntityTracker.getInventoryItem(slot) ?: continue
                if (item.count <= 0) continue
                val id = InventoryUtil.resolveIdentifier(item) ?: continue
                if (NON_PLACEABLE.none { id.contains(it.removePrefix("minecraft:")) }) {
                    found = slot to item; break
                }
            }
            found ?: return
        }

        // Find a solid neighbor to place against (look for block below-below or adjacent)
        val neighbor = InventoryUtil.findClickableNeighbor(px, py, pz) ?: return
        val (_, adjId, face) = neighbor

        val prepared = InventoryUtil.PreparedItem(useSlot, useItem, null)
        InventoryUtil.sendPlacementUseRaw(
            session, prepared,
            Vector3i.from(px, py, pz), adjId, face,
            clickPosition = Vector3f.from(0.5f, 1.0f, 0.5f)
        )
    }
}
