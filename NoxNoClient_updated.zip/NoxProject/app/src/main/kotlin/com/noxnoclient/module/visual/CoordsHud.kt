package com.noxnoclient.module.visual

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.module.BaseModule
import com.noxnoclient.module.ModuleCategory
import com.noxnoclient.utils.HudAnchor
import com.noxnoclient.utils.HudPosition
import kotlin.math.floor

class CoordsHud : BaseModule(
    name        = "CoordsHUD",
    category    = ModuleCategory.VISUAL,
    description = "Shows your current coordinates, position configurable"
) {
    private val anchor    = enum ("Anchor",     HudAnchor.TopLeft)
    private val offsetX   = float("Offset X",   12f, 0f, 800f)
    private val offsetY   = float("Offset Y",   12f, 0f, 800f)
    private val showY     = bool ("Show Y",     true)
    private val shortcut  = bool ("Shortcut",   false)

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(150, 0, 0, 0) }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 26f; typeface = android.graphics.Typeface.DEFAULT_BOLD
    }
    private val rect = RectF()

    fun render(canvas: Canvas, screenW: Int, screenH: Int) {
        if (!isEnabled) return
        val x = floor(EntityTracker.selfX).toInt()
        val y = floor(EntityTracker.selfY).toInt()
        val z = floor(EntityTracker.selfZ).toInt()

        val text = if (showY.value) "X: $x  Y: $y  Z: $z" else "X: $x  Z: $z"
        val textW = textPaint.measureText(text)
        val padding = 10f
        val w = textW + padding * 2
        val h = textPaint.textSize + padding * 2

        val (px, py) = HudPosition.resolve(anchor.value, offsetX.value, offsetY.value, w, h, screenW, screenH)

        rect.set(px, py, px + w, py + h)
        canvas.drawRoundRect(rect, 6f, 6f, bgPaint)
        canvas.drawText(text, px + padding, py + h - padding - 6f, textPaint)
    }
}
