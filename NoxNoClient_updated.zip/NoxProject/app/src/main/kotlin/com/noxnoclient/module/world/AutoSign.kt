package com.noxnoclient.module.world

import com.noxnoclient.events.PacketEvent
import com.noxnoclient.module.BaseModule
import com.noxnoclient.module.ModuleCategory
import org.cloudburstmc.nbt.NbtMap
import org.cloudburstmc.nbt.NbtMapBuilder
import org.cloudburstmc.protocol.bedrock.packet.BlockEntityDataPacket
import org.cloudburstmc.protocol.bedrock.packet.OpenSignPacket
import java.util.concurrent.atomic.AtomicReference

/**
 * AutoSign — bir levha açıldığında otomatik olarak yapılandırılan metni yazar.
 */
class AutoSign : BaseModule(
    name        = "AutoSign",
    category    = ModuleCategory.WORLD,
    description = "Levhaya tıkladığında otomatik olarak metin yazar"
) {
    private val line1 = string("Line 1", "NoxNo")
    private val line2 = string("Line 2", "HvH Client")
    private val line3 = string("Line 3", "")
    private val line4 = string("Line 4", "")

    private val pendingSign = AtomicReference<org.cloudburstmc.math.vector.Vector3i?>(null)

    override fun onPacket(event: PacketEvent) {
        if (!isEnabled) return

        when (event.direction) {
            PacketEvent.Direction.SERVER_TO_CLIENT -> {
                // Sunucu levhayı açtığında konumu sakla
                if (event.packet is OpenSignPacket) {
                    val pkt = event.packet as OpenSignPacket
                    pendingSign.set(pkt.position)
                    return
                }
            }
            PacketEvent.Direction.CLIENT_TO_SERVER -> {
                // Oyuncu levhayı kapatırken (BlockEntityDataPacket gönderirken) içeriği değiştir
                if (event.packet is BlockEntityDataPacket) {
                    val signPos = pendingSign.getAndSet(null) ?: return
                    val pkt = event.packet as BlockEntityDataPacket
                    val pos = pkt.blockPosition ?: return
                    if (pos != signPos) return

                    // Orijinal NBT'yi al veya yeni yap
                    val originalTag = pkt.data
                    val builder: NbtMapBuilder = if (originalTag != null) originalTag.toBuilder() else NbtMap.builder()

                    builder.putString("Text1", line1.value)
                    builder.putString("Text2", line2.value)
                    builder.putString("Text3", line3.value)
                    builder.putString("Text4", line4.value)
                    builder.putString("id", "Sign")
                    builder.putInt("x", pos.x)
                    builder.putInt("y", pos.y)
                    builder.putInt("z", pos.z)

                    val newPkt = BlockEntityDataPacket().apply {
                        blockPosition = pos
                        data = builder.build()
                    }
                    event.cancelAndReplace(newPkt)
                }
            }
        }
    }
}
