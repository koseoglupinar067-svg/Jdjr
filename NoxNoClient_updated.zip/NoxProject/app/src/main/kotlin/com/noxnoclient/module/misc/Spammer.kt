package com.noxnoclient.module.misc

import com.noxnoclient.core.relay.NoxNoRelaySession
import com.noxnoclient.events.PacketEvent
import com.noxnoclient.events.PacketEventBus
import com.noxnoclient.module.BaseModule
import com.noxnoclient.module.ModuleCategory
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.cloudburstmc.protocol.bedrock.packet.TextPacket

/**
 * Spammer — yapılandırılabilir mesaj ve interval ile periyodik chat mesajı gönderir.
 */
class Spammer : BaseModule(
    name        = "Spammer",
    category    = ModuleCategory.MISC,
    description = "Belirlenen aralıkla chat'e mesaj gönderir"
) {
    private val message      = string("Message",      "NoxNo Client | HvH Anarchy")
    private val intervalSec  = float ("Interval (s)",  5f, 1f, 60f)
    private val randomSuffix = bool  ("Random Suffix", false)

    @Volatile private var activeSession: NoxNoRelaySession? = null
    private var spamJob: Job? = null

    override fun onEnable() {
        super.onEnable()
        spamJob = scope.launch {
            while (currentCoroutineContext().isActive) {
                val session = activeSession ?: PacketEventBus.currentSession
                if (session != null && session.isServerReady) {
                    runCatching { session.sendToServer(buildTextPacket()) }
                }
                delay((intervalSec.value * 1000f).toLong().coerceAtLeast(1000L))
            }
        }
    }

    override fun onDisable() {
        spamJob?.cancel(); spamJob = null
        super.onDisable()
    }

    override fun onPacket(event: PacketEvent) {
        if (!isEnabled) return
        activeSession = event.session
    }

    private fun buildTextPacket(): TextPacket {
        val msg = if (randomSuffix.value) "${message.value} ${(100..9999).random()}" else message.value
        return TextPacket().apply {
            type               = TextPacket.Type.CHAT
            isNeedsTranslation = false
            sourceName         = InternalChat.MARKER
            xuid               = ""
            platformChatId     = ""
            setMessage(msg)
            setFilteredMessage("")
        }
    }
}
