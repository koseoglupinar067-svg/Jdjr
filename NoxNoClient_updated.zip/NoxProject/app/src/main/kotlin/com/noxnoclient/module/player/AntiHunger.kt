package com.noxnoclient.module.player

import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.events.PacketEvent
import com.noxnoclient.module.BaseModule
import com.noxnoclient.module.ModuleCategory
import org.cloudburstmc.protocol.bedrock.packet.UpdateAttributesPacket

class AntiHunger : BaseModule(
    name        = "AntiHunger",
    category    = ModuleCategory.PLAYER,
    description = "Açlık azalmasını engeller — sunucudan gelen açlık attribute güncellemelerini filtreler"
) {
    companion object {
        private val HUNGER_ATTRIBUTES = setOf(
            "minecraft:player.hunger",
            "minecraft:player.saturation",
            "minecraft:player.exhaustion"
        )
    }

    override fun onPacket(event: PacketEvent) {
        if (!isEnabled) return
        if (event.direction != PacketEvent.Direction.SERVER_TO_CLIENT) return
        val pkt = event.packet as? UpdateAttributesPacket ?: return
        if (pkt.runtimeEntityId != EntityTracker.selfRuntimeId) return

        val filtered = pkt.attributes.filter { attr ->
            attr.name !in HUNGER_ATTRIBUTES || attr.value >= attr.currentValue
        }

        if (filtered.size == pkt.attributes.size) return

        if (filtered.isEmpty()) {
            event.cancel()
            return
        }

        val newPkt = UpdateAttributesPacket().apply {
            runtimeEntityId = pkt.runtimeEntityId
            attributes.addAll(filtered)
            tick = pkt.tick
        }
        event.cancelAndReplace(newPkt)
    }
}
