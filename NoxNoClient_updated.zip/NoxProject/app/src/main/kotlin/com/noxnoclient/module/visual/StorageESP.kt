package com.noxnoclient.module.visual

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.events.PacketEvent
import com.noxnoclient.module.BaseModule
import com.noxnoclient.module.ModuleCategory
import com.noxnoclient.utils.ChunkParser
import com.noxnoclient.utils.MathUtil
import com.noxnoclient.utils.UiUtil
import com.noxnoclient.utils.WorldBlockTracker
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.cloudburstmc.protocol.bedrock.packet.BlockEntityDataPacket
import org.cloudburstmc.protocol.bedrock.packet.LevelChunkPacket
import org.cloudburstmc.protocol.bedrock.packet.UpdateBlockPacket
import java.util.concurrent.ConcurrentHashMap

class StorageESP : BaseModule(
    name        = "StorageESP",
    category    = ModuleCategory.VISUAL,
    description = "Sandık, shulker, ender sandığı, varil, büyü masası ve fırın ailesini gösterir"
) {
    enum class ContainerType(val label: String, val color: Int) {
        CHEST             ("Chest",           Color.rgb(210, 160,  60)),
        SHULKER           ("Shulker",         Color.rgb(190,  80, 220)),
        ENDER_CHEST       ("Ender Chest",     Color.rgb( 60, 210, 190)),
        BARREL            ("Barrel",          Color.rgb(150, 110,  60)),
        HOPPER            ("Hopper",          Color.rgb(140, 140, 150)),
        DISPENSER         ("Dispenser",       Color.rgb(130, 130, 130)),
        DROPPER           ("Dropper",         Color.rgb(110, 110, 110)),
        BREWING_STAND     ("Brewing Stand",   Color.rgb(200,  60, 200)),
        FURNACE           ("Furnace",         Color.rgb(200, 100,  40)),
        ENCHANTING_TABLE  ("Enchant Table",   Color.rgb( 80, 160, 255)),
    }

    private data class Entry(val x: Int, val y: Int, val z: Int, val type: ContainerType)

    private val range           = float("Range",            48f, 8f, 128f)
    private val showChest       = bool ("Chests",            true)
    private val showShulker     = bool ("Shulkers",          true)
    private val showEnder       = bool ("Ender Chests",      true)
    private val showFurnace     = bool ("Furnace Family",    true)
    private val showEnchanting  = bool ("Enchanting Tables", true)
    private val showUtility     = bool ("Hopper/Dispenser/Dropper/Brewing", false)
    private val showLabel       = bool ("Label",             true)
    private val showDistance    = bool ("Distance",          true)
    private val fill            = bool ("Fill",              true)

    private val containers = ConcurrentHashMap<Long, Entry>()
    private val scanScope  = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private val boxPaint  = Paint().apply { style = Paint.Style.STROKE; strokeWidth = 3f; isAntiAlias = true }
    private val fillPaint = Paint().apply { style = Paint.Style.FILL;   isAntiAlias = true }
    private val textPaint = Paint().apply {
        isAntiAlias = true; textSize = 26f; textAlign = Paint.Align.CENTER
        setShadowLayer(3f, 0f, 0f, Color.BLACK)
    }

    override fun onEnable() {
        super.onEnable()
        containers.clear()
    }

    override fun onDisable() {
        containers.clear()
        super.onDisable()
    }

    override fun onPacket(event: PacketEvent) {
        if (!isEnabled) return
        try {
            when (val p = event.packet) {
                is BlockEntityDataPacket -> {
                    val pos = p.blockPosition ?: return
                    val tag = p.data ?: return
                    val id  = tag.getString("id") ?: return
                    val type = resolveType(id) ?: run {
                        containers.remove(key(pos.x, pos.y, pos.z))
                        return
                    }
                    containers[key(pos.x, pos.y, pos.z)] = Entry(pos.x, pos.y, pos.z, type)
                }

                is LevelChunkPacket -> scanChunk(p)

                is UpdateBlockPacket -> {
                    val pos = p.blockPosition ?: return
                    val k   = key(pos.x, pos.y, pos.z)
                    if (containers.containsKey(k)) {
                        val id           = WorldBlockTracker.getBlockIdentifier(pos.x, pos.y, pos.z)
                        val stillContainer = id != null && resolveType(id) != null
                        if (!stillContainer) containers.remove(k)
                    }
                }

                else -> {}
            }
        } catch (_: Throwable) {}
    }

    private fun scanChunk(pkt: LevelChunkPacket) {
        val buf = try { pkt.data } catch (_: Throwable) { null } ?: return
        buf.retain()
        scanScope.launch {
            try {
                val entities = try {
                    ChunkParser.extractBlockEntities(pkt)
                } catch (_: Exception) {
                    emptyList()
                }
                for (be in entities) {
                    val id   = be.tag.getString("id") ?: continue
                    val type = resolveType(id) ?: continue
                    containers[key(be.x, be.y, be.z)] = Entry(be.x, be.y, be.z, type)
                }
            } catch (_: Throwable) {
            } finally {
                buf.release()
            }
        }
    }

    private fun resolveType(nbtId: String): ContainerType? = when (nbtId) {
        "Chest"                          -> ContainerType.CHEST
        "ShulkerBox"                     -> ContainerType.SHULKER
        "EnderChest"                     -> ContainerType.ENDER_CHEST
        "Barrel"                         -> ContainerType.BARREL
        "Hopper"                         -> ContainerType.HOPPER
        "Dispenser"                      -> ContainerType.DISPENSER
        "Dropper"                        -> ContainerType.DROPPER
        "BrewingStand"                   -> ContainerType.BREWING_STAND
        "Furnace", "BlastFurnace",
        "Smoker"                         -> ContainerType.FURNACE
        "EnchantTable"                   -> ContainerType.ENCHANTING_TABLE
        else                             -> null
    }

    private fun typeEnabled(type: ContainerType): Boolean = when (type) {
        ContainerType.CHEST, ContainerType.BARREL            -> showChest.value
        ContainerType.SHULKER                                 -> showShulker.value
        ContainerType.ENDER_CHEST                             -> showEnder.value
        ContainerType.FURNACE                                 -> showFurnace.value
        ContainerType.ENCHANTING_TABLE                        -> showEnchanting.value
        ContainerType.HOPPER, ContainerType.DISPENSER,
        ContainerType.DROPPER, ContainerType.BREWING_STAND   -> showUtility.value
    }

    private fun key(x: Int, y: Int, z: Int): Long =
        ((x.toLong() and 0x3FFFFFF) shl 38) or ((y.toLong() and 0xFFF) shl 26) or (z.toLong() and 0x3FFFFFF)

    fun render(canvas: Canvas, screenW: Int, screenH: Int) {
        if (containers.isEmpty()) return

        val selfX  = EntityTracker.selfX
        val selfY  = EntityTracker.selfY
        val selfZ  = EntityTracker.selfZ
        val yaw    = EntityTracker.selfYaw
        val pitch  = EntityTracker.selfPitch
        val fov    = UiUtil.currentFov
        val r      = range.value

        for (entry in containers.values) {
            try {
                if (!typeEnabled(entry.type)) continue
                val cx   = entry.x + 0.5f
                val cy   = entry.y + 0.5f
                val cz   = entry.z + 0.5f
                val dist = MathUtil.dist3(cx, cy, cz, selfX, selfY, selfZ)
                if (dist > r) continue

                val rect = projectBox(entry, selfX, selfY, selfZ, yaw, pitch, screenW, screenH, fov) ?: continue
                val color = entry.type.color

                if (fill.value) {
                    fillPaint.color = Color.argb(70, Color.red(color), Color.green(color), Color.blue(color))
                    canvas.drawRect(rect, fillPaint)
                }
                boxPaint.color = color
                canvas.drawRect(rect, boxPaint)

                if (showLabel.value || showDistance.value) {
                    val label = buildString {
                        if (showLabel.value) append(entry.type.label)
                        if (showDistance.value) { if (isNotEmpty()) append(" "); append("(${dist.toInt()}m)") }
                    }
                    textPaint.color = color
                    canvas.drawText(label, rect.centerX(), rect.top - 8f, textPaint)
                }
            } catch (_: Throwable) {}
        }
    }

    private fun projectBox(
        e: Entry,
        selfX: Float, selfY: Float, selfZ: Float,
        yaw: Float, pitch: Float,
        screenW: Int, screenH: Int, fov: Float
    ): android.graphics.RectF? {
        val x0 = e.x.toFloat(); val y0 = e.y.toFloat(); val z0 = e.z.toFloat()
        val corners = arrayOf(
            floatArrayOf(x0,     y0,     z0    ), floatArrayOf(x0 + 1, y0,     z0    ),
            floatArrayOf(x0,     y0,     z0 + 1), floatArrayOf(x0 + 1, y0,     z0 + 1),
            floatArrayOf(x0,     y0 + 1, z0    ), floatArrayOf(x0 + 1, y0 + 1, z0    ),
            floatArrayOf(x0,     y0 + 1, z0 + 1), floatArrayOf(x0 + 1, y0 + 1, z0 + 1)
        )
        var minX = Float.MAX_VALUE; var maxX = -Float.MAX_VALUE
        var minY = Float.MAX_VALUE; var maxY = -Float.MAX_VALUE
        var hits = 0
        for (c in corners) {
            val s = try {
                MathUtil.worldToScreen(c[0], c[1], c[2], selfX, selfY, selfZ, yaw, pitch, screenW, screenH, fov)
            } catch (_: Throwable) { null } ?: continue
            hits++
            if (s.first  < minX) minX = s.first
            if (s.first  > maxX) maxX = s.first
            if (s.second < minY) minY = s.second
            if (s.second > maxY) maxY = s.second
        }
        if (hits < 4) return null
        if (maxX < -50 || minX > screenW + 50 || maxY < -50 || minY > screenH + 50) return null
        return android.graphics.RectF(minX, minY, maxX, maxY)
    }
}
